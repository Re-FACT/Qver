//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Memories used in FPGA
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Wed Sep 30 09:18:18 2026
//-------------------------------------------
//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size10_mem -----
module mux_tree_tapbuf_size10_mem(prog_clk,
                                  ccff_head,
                                  ccff_tail,
                                  mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size10_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size4_mem -----
module mux_tree_tapbuf_size4_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:2] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[2];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size4_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size6_mem -----
module mux_tree_tapbuf_size6_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:2] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[2];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size6_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size5_mem -----
module mux_tree_tapbuf_size5_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:2] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[2];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size5_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size7_mem -----
module mux_tree_tapbuf_size7_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:2] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[2];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size7_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size8_mem -----
module mux_tree_tapbuf_size8_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size8_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size3_mem -----
module mux_tree_tapbuf_size3_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:1] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[1];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size3_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size2_mem -----
module mux_tree_tapbuf_size2_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:1] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[1];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size2_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size9_mem -----
module mux_tree_tapbuf_size9_mem(prog_clk,
                                 ccff_head,
                                 ccff_tail,
                                 mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size9_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size13_mem -----
module mux_tree_tapbuf_size13_mem(prog_clk,
                                  ccff_head,
                                  ccff_tail,
                                  mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size13_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size12_mem -----
module mux_tree_tapbuf_size12_mem(prog_clk,
                                  ccff_head,
                                  ccff_tail,
                                  mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size12_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_tapbuf_size11_mem -----
module mux_tree_tapbuf_size11_mem(prog_clk,
                                  ccff_head,
                                  ccff_tail,
                                  mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:3] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[3];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

endmodule
// ----- END Verilog module for mux_tree_tapbuf_size11_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for mux_tree_size2_mem -----
module mux_tree_size2_mem(prog_clk,
                          ccff_head,
                          ccff_tail,
                          mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:1] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[1];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

endmodule
// ----- END Verilog module for mux_tree_size2_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for frac_lut4_DFFQ_mem -----
module frac_lut4_DFFQ_mem(prog_clk,
                          ccff_head,
                          ccff_tail,
                          mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:16] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[16];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out[0]));

	DFFQ DFFQ_1_ (
		.CK(prog_clk),
		.D(mem_out[0]),
		.Q(mem_out[1]));

	DFFQ DFFQ_2_ (
		.CK(prog_clk),
		.D(mem_out[1]),
		.Q(mem_out[2]));

	DFFQ DFFQ_3_ (
		.CK(prog_clk),
		.D(mem_out[2]),
		.Q(mem_out[3]));

	DFFQ DFFQ_4_ (
		.CK(prog_clk),
		.D(mem_out[3]),
		.Q(mem_out[4]));

	DFFQ DFFQ_5_ (
		.CK(prog_clk),
		.D(mem_out[4]),
		.Q(mem_out[5]));

	DFFQ DFFQ_6_ (
		.CK(prog_clk),
		.D(mem_out[5]),
		.Q(mem_out[6]));

	DFFQ DFFQ_7_ (
		.CK(prog_clk),
		.D(mem_out[6]),
		.Q(mem_out[7]));

	DFFQ DFFQ_8_ (
		.CK(prog_clk),
		.D(mem_out[7]),
		.Q(mem_out[8]));

	DFFQ DFFQ_9_ (
		.CK(prog_clk),
		.D(mem_out[8]),
		.Q(mem_out[9]));

	DFFQ DFFQ_10_ (
		.CK(prog_clk),
		.D(mem_out[9]),
		.Q(mem_out[10]));

	DFFQ DFFQ_11_ (
		.CK(prog_clk),
		.D(mem_out[10]),
		.Q(mem_out[11]));

	DFFQ DFFQ_12_ (
		.CK(prog_clk),
		.D(mem_out[11]),
		.Q(mem_out[12]));

	DFFQ DFFQ_13_ (
		.CK(prog_clk),
		.D(mem_out[12]),
		.Q(mem_out[13]));

	DFFQ DFFQ_14_ (
		.CK(prog_clk),
		.D(mem_out[13]),
		.Q(mem_out[14]));

	DFFQ DFFQ_15_ (
		.CK(prog_clk),
		.D(mem_out[14]),
		.Q(mem_out[15]));

	DFFQ DFFQ_16_ (
		.CK(prog_clk),
		.D(mem_out[15]),
		.Q(mem_out[16]));

endmodule
// ----- END Verilog module for frac_lut4_DFFQ_mem -----

//----- Default net type -----
`default_nettype wire




//----- Default net type -----
`default_nettype none

// ----- Verilog module for EMBEDDED_IO_DFFQ_mem -----
module EMBEDDED_IO_DFFQ_mem(prog_clk,
                            ccff_head,
                            ccff_tail,
                            mem_out);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;
//----- OUTPUT PORTS -----
output [0:0] mem_out;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----



// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
	assign ccff_tail[0] = mem_out[0];
// ----- END Local output short connections -----

	DFFQ DFFQ_0_ (
		.CK(prog_clk),
		.D(ccff_head),
		.Q(mem_out));

endmodule
// ----- END Verilog module for EMBEDDED_IO_DFFQ_mem -----

//----- Default net type -----
`default_nettype wire




