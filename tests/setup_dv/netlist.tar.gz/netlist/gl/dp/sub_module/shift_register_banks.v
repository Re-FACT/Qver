//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Shift register banks used in FPGA
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Wed Sep 30 09:18:18 2026
//-------------------------------------------
