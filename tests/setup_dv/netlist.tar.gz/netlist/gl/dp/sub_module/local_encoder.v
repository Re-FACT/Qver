//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Local Decoders for Multiplexers
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Wed Sep 30 09:18:18 2026
//-------------------------------------------
