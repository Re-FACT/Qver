//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Template for user-defined Verilog modules
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Wed Sep 30 09:18:18 2026
//-------------------------------------------
// ----- Template Verilog module for SDFFSRQ -----
//----- Default net type -----
`default_nettype none

// ----- Verilog module for SDFFSRQ -----
module SDFFSRQ(SE,
               RST,
               SET,
               CK,
               D,
               SI,
               Q);
//----- GLOBAL PORTS -----
input [0:0] SE;
//----- GLOBAL PORTS -----
input [0:0] RST;
//----- GLOBAL PORTS -----
input [0:0] SET;
//----- GLOBAL PORTS -----
input [0:0] CK;
//----- INPUT PORTS -----
input [0:0] D;
//----- INPUT PORTS -----
input [0:0] SI;
//----- OUTPUT PORTS -----
output [0:0] Q;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----

// ----- Internal logic should start here -----


// ----- Internal logic should end here -----
endmodule
// ----- END Verilog module for SDFFSRQ -----

//----- Default net type -----
`default_nettype wire


// ----- Template Verilog module for DFFQ -----
//----- Default net type -----
`default_nettype none

// ----- Verilog module for DFFQ -----
module DFFQ(CK,
            D,
            Q);
//----- GLOBAL PORTS -----
input [0:0] CK;
//----- INPUT PORTS -----
input [0:0] D;
//----- OUTPUT PORTS -----
output [0:0] Q;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----

// ----- Internal logic should start here -----


// ----- Internal logic should end here -----
endmodule
// ----- END Verilog module for DFFQ -----

//----- Default net type -----
`default_nettype wire


// ----- Template Verilog module for EMBEDDED_IO -----
//----- Default net type -----
`default_nettype none

// ----- Verilog module for EMBEDDED_IO -----
module EMBEDDED_IO(SOC_IN,
                   SOC_OUT,
                   SOC_DIR,
                   FPGA_OUT,
                   FPGA_DIR,
                   FPGA_IN);
//----- GPIN PORTS -----
input [0:0] SOC_IN;
//----- GPOUT PORTS -----
output [0:0] SOC_OUT;
//----- GPOUT PORTS -----
output [0:0] SOC_DIR;
//----- INPUT PORTS -----
input [0:0] FPGA_OUT;
//----- INPUT PORTS -----
input [0:0] FPGA_DIR;
//----- OUTPUT PORTS -----
output [0:0] FPGA_IN;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----

// ----- Internal logic should start here -----


// ----- Internal logic should end here -----
endmodule
// ----- END Verilog module for EMBEDDED_IO -----

//----- Default net type -----
`default_nettype wire


