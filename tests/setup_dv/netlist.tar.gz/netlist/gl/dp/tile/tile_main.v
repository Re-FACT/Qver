//Generated from netlist by SpyDrNet
//netlist name: SDN_VERILOG_NETLIST_const0
module tile_main
(
    config_enable,
    prog_reset,
    prog_clk,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_12_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_13_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_14_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_15_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_16_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_17_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_18_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_19_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_20_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_21_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_22_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_23_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_,
    sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_,
    sb_0__chanx_right_in,
    sb_0__chany_bottom_in,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_0_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_1_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_2_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_3_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_4_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_5_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_6_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_7_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_8_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_9_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_10_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_11_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_12_,
    grid_clb_top_width_0_height_0_subtile_0__pin_I_13_,
    grid_clb_top_width_0_height_0_subtile_0__pin_cin_0_,
    grid_clb_top_width_0_height_0_subtile_0__pin_lclk_0_,
    grid_clb_top_width_0_height_0_subtile_0__pin_lreset_0_,
    grid_clb_left_width_0_height_0_subtile_0__pin_reset_0_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_0_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_1_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_2_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_3_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_4_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_5_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_6_,
    grid_clb_left_width_0_height_0_subtile_0__pin_clk_7_,
    cbx_0__chanx_left_in,
    cby_0__chany_top_in,
    ccff_head,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_,
    cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_,
    sb_0__chanx_right_out,
    sb_0__chany_bottom_out,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_0_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_1_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_2_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_3_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_4_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_5_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_6_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_7_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_8_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_9_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_10_,
    grid_clb_top_width_0_height_0_subtile_0__pin_O_11_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_12_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_13_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_14_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_15_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_16_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_17_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_18_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_19_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_20_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_21_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_22_,
    grid_clb_right_width_0_height_0_subtile_0__pin_O_23_,
    grid_clb_bottom_width_0_height_0_subtile_0__pin_cout_0_,
    cbx_0__chanx_left_out,
    cby_0__chany_top_out,
    ccff_tail,
    prog_reset_fto,
    prog_clk_fto,
    config_enable_fto
);

    input config_enable;
    input prog_reset;
    input prog_clk;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_12_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_13_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_14_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_15_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_16_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_17_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_18_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_19_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_20_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_21_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_22_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_23_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    input sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    input [0:31]sb_0__chanx_right_in;
    input [0:31]sb_0__chany_bottom_in;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_0_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_1_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_2_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_3_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_4_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_5_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_6_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_7_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_8_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_9_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_10_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_11_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_12_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_I_13_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_cin_0_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_lclk_0_;
    input grid_clb_top_width_0_height_0_subtile_0__pin_lreset_0_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_reset_0_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_0_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_1_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_2_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_3_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_4_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_5_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_6_;
    input grid_clb_left_width_0_height_0_subtile_0__pin_clk_7_;
    input [0:31]cbx_0__chanx_left_in;
    input [0:31]cby_0__chany_top_in;
    input ccff_head;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_;
    output cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_;
    output [0:31]sb_0__chanx_right_out;
    output [0:31]sb_0__chany_bottom_out;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_0_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_1_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_2_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_3_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_4_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_5_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_6_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_7_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_8_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_9_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_10_;
    output grid_clb_top_width_0_height_0_subtile_0__pin_O_11_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_12_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_13_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_14_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_15_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_16_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_17_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_18_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_19_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_20_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_21_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_22_;
    output grid_clb_right_width_0_height_0_subtile_0__pin_O_23_;
    output grid_clb_bottom_width_0_height_0_subtile_0__pin_cout_0_;
    output [0:31]cbx_0__chanx_left_out;
    output [0:31]cby_0__chany_top_out;
    output ccff_tail;
    output prog_reset_fto;
    output prog_clk_fto;
    output config_enable_fto;

    wire config_enable;
    wire prog_reset;
    wire prog_clk;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_12_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_13_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_14_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_15_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_16_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_17_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_18_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_19_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_20_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_21_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_22_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_23_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    wire sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    wire [0:31]sb_0__chanx_right_in;
    wire [0:31]sb_0__chany_bottom_in;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_0_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_1_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_2_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_3_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_4_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_5_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_6_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_7_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_8_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_9_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_10_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_11_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_12_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_I_13_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_cin_0_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_lclk_0_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_lreset_0_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_reset_0_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_0_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_1_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_2_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_3_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_4_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_5_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_6_;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_7_;
    wire [0:31]cbx_0__chanx_left_in;
    wire [0:31]cby_0__chany_top_in;
    wire ccff_head;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_;
    wire cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_;
    wire [0:31]sb_0__chanx_right_out;
    wire [0:31]sb_0__chany_bottom_out;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_0_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_1_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_2_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_3_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_4_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_5_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_6_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_7_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_8_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_9_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_10_;
    wire grid_clb_top_width_0_height_0_subtile_0__pin_O_11_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_12_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_13_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_14_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_15_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_16_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_17_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_18_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_19_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_20_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_21_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_22_;
    wire grid_clb_right_width_0_height_0_subtile_0__pin_O_23_;
    wire grid_clb_bottom_width_0_height_0_subtile_0__pin_cout_0_;
    wire [0:31]cbx_0__chanx_left_out;
    wire [0:31]cby_0__chany_top_out;
    wire ccff_tail;
    wire [0:31]cbx_1__0_chanx_right_out;
    wire [0:31]cby_1__0_chany_bottom_out;
    wire [0:31]sb_4__0_chanx_left_out;
    wire [0:31]sb_4__0_chany_top_out;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_14_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_15_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_16_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_17_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_18_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_19_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_20_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_21_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_22_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_23_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_24_;
    wire cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_25_;
    wire grid_clb_0_ccff_tail;
    wire cbx_1__0_ccff_tail;
    wire cby_1__0_ccff_tail;
    wire prog_clk_mkbuf_out;
    wire prog_reset_mkbuf_out;
    wire prog_reset_fto;
    wire prog_clk_fto;
    wire config_enable_fto;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out;
    wire grid_clb_left_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out;

    grid_clb grid_clb_1__2_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_I_0_(grid_clb_top_width_0_height_0_subtile_0__pin_I_0_),
        .top_width_0_height_0_subtile_0__pin_I_1_(grid_clb_top_width_0_height_0_subtile_0__pin_I_1_),
        .top_width_0_height_0_subtile_0__pin_I_2_(grid_clb_top_width_0_height_0_subtile_0__pin_I_2_),
        .top_width_0_height_0_subtile_0__pin_I_3_(grid_clb_top_width_0_height_0_subtile_0__pin_I_3_),
        .top_width_0_height_0_subtile_0__pin_I_4_(grid_clb_top_width_0_height_0_subtile_0__pin_I_4_),
        .top_width_0_height_0_subtile_0__pin_I_5_(grid_clb_top_width_0_height_0_subtile_0__pin_I_5_),
        .top_width_0_height_0_subtile_0__pin_I_6_(grid_clb_top_width_0_height_0_subtile_0__pin_I_6_),
        .top_width_0_height_0_subtile_0__pin_I_7_(grid_clb_top_width_0_height_0_subtile_0__pin_I_7_),
        .top_width_0_height_0_subtile_0__pin_I_8_(grid_clb_top_width_0_height_0_subtile_0__pin_I_8_),
        .top_width_0_height_0_subtile_0__pin_I_9_(grid_clb_top_width_0_height_0_subtile_0__pin_I_9_),
        .top_width_0_height_0_subtile_0__pin_I_10_(grid_clb_top_width_0_height_0_subtile_0__pin_I_10_),
        .top_width_0_height_0_subtile_0__pin_I_11_(grid_clb_top_width_0_height_0_subtile_0__pin_I_11_),
        .top_width_0_height_0_subtile_0__pin_I_12_(grid_clb_top_width_0_height_0_subtile_0__pin_I_12_),
        .top_width_0_height_0_subtile_0__pin_I_13_(grid_clb_top_width_0_height_0_subtile_0__pin_I_13_),
        .top_width_0_height_0_subtile_0__pin_cin_0_(grid_clb_top_width_0_height_0_subtile_0__pin_cin_0_),
        .top_width_0_height_0_subtile_0__pin_lclk_0_(grid_clb_top_width_0_height_0_subtile_0__pin_lclk_0_),
        .top_width_0_height_0_subtile_0__pin_lreset_0_(grid_clb_top_width_0_height_0_subtile_0__pin_lreset_0_),
        .right_width_0_height_0_subtile_0__pin_I_14_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_14_),
        .right_width_0_height_0_subtile_0__pin_I_15_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_15_),
        .right_width_0_height_0_subtile_0__pin_I_16_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_16_),
        .right_width_0_height_0_subtile_0__pin_I_17_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_17_),
        .right_width_0_height_0_subtile_0__pin_I_18_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_18_),
        .right_width_0_height_0_subtile_0__pin_I_19_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_19_),
        .right_width_0_height_0_subtile_0__pin_I_20_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_20_),
        .right_width_0_height_0_subtile_0__pin_I_21_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_21_),
        .right_width_0_height_0_subtile_0__pin_I_22_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_22_),
        .right_width_0_height_0_subtile_0__pin_I_23_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_23_),
        .right_width_0_height_0_subtile_0__pin_I_24_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_24_),
        .right_width_0_height_0_subtile_0__pin_I_25_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_25_),
        .left_width_0_height_0_subtile_0__pin_reset_0_(grid_clb_left_width_0_height_0_subtile_0__pin_reset_0_),
        .left_width_0_height_0_subtile_0__pin_clk_0_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_1_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_2_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_3_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_4_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_5_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_6_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out),
        .left_width_0_height_0_subtile_0__pin_clk_7_(grid_clb_left_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out),
        .ccff_head(ccff_head),
        .top_width_0_height_0_subtile_0__pin_O_0_(grid_clb_top_width_0_height_0_subtile_0__pin_O_0_),
        .top_width_0_height_0_subtile_0__pin_O_1_(grid_clb_top_width_0_height_0_subtile_0__pin_O_1_),
        .top_width_0_height_0_subtile_0__pin_O_2_(grid_clb_top_width_0_height_0_subtile_0__pin_O_2_),
        .top_width_0_height_0_subtile_0__pin_O_3_(grid_clb_top_width_0_height_0_subtile_0__pin_O_3_),
        .top_width_0_height_0_subtile_0__pin_O_4_(grid_clb_top_width_0_height_0_subtile_0__pin_O_4_),
        .top_width_0_height_0_subtile_0__pin_O_5_(grid_clb_top_width_0_height_0_subtile_0__pin_O_5_),
        .top_width_0_height_0_subtile_0__pin_O_6_(grid_clb_top_width_0_height_0_subtile_0__pin_O_6_),
        .top_width_0_height_0_subtile_0__pin_O_7_(grid_clb_top_width_0_height_0_subtile_0__pin_O_7_),
        .top_width_0_height_0_subtile_0__pin_O_8_(grid_clb_top_width_0_height_0_subtile_0__pin_O_8_),
        .top_width_0_height_0_subtile_0__pin_O_9_(grid_clb_top_width_0_height_0_subtile_0__pin_O_9_),
        .top_width_0_height_0_subtile_0__pin_O_10_(grid_clb_top_width_0_height_0_subtile_0__pin_O_10_),
        .top_width_0_height_0_subtile_0__pin_O_11_(grid_clb_top_width_0_height_0_subtile_0__pin_O_11_),
        .right_width_0_height_0_subtile_0__pin_O_12_(grid_clb_right_width_0_height_0_subtile_0__pin_O_12_),
        .right_width_0_height_0_subtile_0__pin_O_13_(grid_clb_right_width_0_height_0_subtile_0__pin_O_13_),
        .right_width_0_height_0_subtile_0__pin_O_14_(grid_clb_right_width_0_height_0_subtile_0__pin_O_14_),
        .right_width_0_height_0_subtile_0__pin_O_15_(grid_clb_right_width_0_height_0_subtile_0__pin_O_15_),
        .right_width_0_height_0_subtile_0__pin_O_16_(grid_clb_right_width_0_height_0_subtile_0__pin_O_16_),
        .right_width_0_height_0_subtile_0__pin_O_17_(grid_clb_right_width_0_height_0_subtile_0__pin_O_17_),
        .right_width_0_height_0_subtile_0__pin_O_18_(grid_clb_right_width_0_height_0_subtile_0__pin_O_18_),
        .right_width_0_height_0_subtile_0__pin_O_19_(grid_clb_right_width_0_height_0_subtile_0__pin_O_19_),
        .right_width_0_height_0_subtile_0__pin_O_20_(grid_clb_right_width_0_height_0_subtile_0__pin_O_20_),
        .right_width_0_height_0_subtile_0__pin_O_21_(grid_clb_right_width_0_height_0_subtile_0__pin_O_21_),
        .right_width_0_height_0_subtile_0__pin_O_22_(grid_clb_right_width_0_height_0_subtile_0__pin_O_22_),
        .right_width_0_height_0_subtile_0__pin_O_23_(grid_clb_right_width_0_height_0_subtile_0__pin_O_23_),
        .bottom_width_0_height_0_subtile_0__pin_cout_0_(grid_clb_bottom_width_0_height_0_subtile_0__pin_cout_0_),
        .ccff_tail(grid_clb_0_ccff_tail)
    );
    cbx_1_ cbx_1__1_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chanx_left_in(cbx_0__chanx_left_in),
        .chanx_right_in(sb_4__0_chanx_left_out),
        .ccff_head(grid_clb_0_ccff_tail),
        .chanx_left_out(cbx_0__chanx_left_out),
        .chanx_right_out(cbx_1__0_chanx_right_out),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_),
        .bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_(cbx_0__bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_),
        .ccff_tail(cbx_1__0_ccff_tail)
    );
    cby_1_ cby_1__2_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chany_bottom_in(sb_4__0_chany_top_out),
        .chany_top_in(cby_0__chany_top_in),
        .ccff_head(cbx_1__0_ccff_tail),
        .chany_bottom_out(cby_1__0_chany_bottom_out),
        .chany_top_out(cby_0__chany_top_out),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_14_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_14_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_15_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_15_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_16_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_16_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_17_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_17_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_18_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_18_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_19_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_19_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_20_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_20_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_21_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_21_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_22_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_22_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_23_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_23_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_24_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_24_),
        .left_grid_right_width_0_height_0_subtile_0__pin_I_25_(cby_1__0_left_grid_right_width_0_height_0_subtile_0__pin_I_25_),
        .ccff_tail(cby_1__0_ccff_tail)
    );
    sb_4_ sb_1__1_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chany_top_in(cby_1__0_chany_bottom_out),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_(grid_clb_right_width_0_height_0_subtile_0__pin_O_12_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_(grid_clb_right_width_0_height_0_subtile_0__pin_O_13_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_(grid_clb_right_width_0_height_0_subtile_0__pin_O_14_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_(grid_clb_right_width_0_height_0_subtile_0__pin_O_15_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_(grid_clb_right_width_0_height_0_subtile_0__pin_O_16_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_(grid_clb_right_width_0_height_0_subtile_0__pin_O_17_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_(grid_clb_right_width_0_height_0_subtile_0__pin_O_18_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_(grid_clb_right_width_0_height_0_subtile_0__pin_O_19_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_(grid_clb_right_width_0_height_0_subtile_0__pin_O_20_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_(grid_clb_right_width_0_height_0_subtile_0__pin_O_21_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_(grid_clb_right_width_0_height_0_subtile_0__pin_O_22_),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_(grid_clb_right_width_0_height_0_subtile_0__pin_O_23_),
        .chanx_right_in(sb_0__chanx_right_in),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_),
        .chany_bottom_in(sb_0__chany_bottom_in),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_12_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_12_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_13_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_13_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_14_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_14_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_15_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_15_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_16_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_16_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_17_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_17_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_18_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_18_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_19_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_19_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_20_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_20_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_21_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_21_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_22_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_22_),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_23_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_23_),
        .chanx_left_in(cbx_1__0_chanx_right_out),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_),
        .left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_(sb_0__left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_),
        .ccff_head(cby_1__0_ccff_tail),
        .chany_top_out(sb_4__0_chany_top_out),
        .chanx_right_out(sb_0__chanx_right_out),
        .chany_bottom_out(sb_0__chany_bottom_out),
        .chanx_left_out(sb_4__0_chanx_left_out),
        .ccff_tail(ccff_tail)
    );
    CKBD4BWP30P140HVT prog_clk_mkbuf_0
    (
        .I(prog_clk),
        .Z(prog_clk_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_mkbuf_0
    (
        .I(prog_reset),
        .Z(prog_reset_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_ftb
    (
        .I(prog_reset),
        .Z(prog_reset_fto)
    );
    CKBD4BWP30P140HVT prog_clk_ftb
    (
        .I(prog_clk),
        .Z(prog_clk_fto)
    );
    CKBD4BWP30P140HVT config_enable_ftb
    (
        .I(config_enable),
        .Z(config_enable_fto)
    );
    CKBD1BWP30P140HVT clk0_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_0_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk1_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_1_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk2_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_2_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk3_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_3_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk4_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_4_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk5_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_5_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk6_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_6_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk7_mkbuf_0
    (
        .I(grid_clb_left_width_0_height_0_subtile_0__pin_clk_7_),
        .Z(grid_clb_left_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out)
    );
endmodule

