//Generated from netlist by SpyDrNet
//netlist name: SDN_VERILOG_NETLIST_const0
module left_tile_sub
(
    SE0,
    SE1,
    SC0,
    SC1,
    SR,
    SE2,
    config_enable,
    prog_reset,
    prog_clk,
    gfpga_pad_pinput_A2F,
    gfpga_pad_poutput_F2A,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_,
    sb_0__chanx_right_in,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_reset_0_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6_,
    grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7_,
    cby_0__chany_top_in,
    ccff_head,
    sb_0__chanx_right_out,
    grid_io_leftL_left_right_width_0_height_0_subtile_0__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_1__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_2__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_3__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_4__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_5__pin_a2f_o_0_,
    grid_io_leftL_left_right_width_0_height_0_subtile_6__pin_a2f_o_0_,
    cby_0__chany_top_out,
    ccff_tail,
    prog_reset_fto,
    prog_clk_fto,
    config_enable_fto,
    SE0_fto,
    SE1_fto,
    SE2_fto,
    SC0_fto,
    SC1_fto,
    SR_fto,
    SI,
    SO
);

    input SE0;
    input SE1;
    input SC0;
    input SC1;
    input SR;
    input SE2;
    input config_enable;
    input prog_reset;
    input prog_clk;
    input [0:6]gfpga_pad_pinput_A2F;
    output [0:13]gfpga_pad_poutput_F2A;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_;
    input [0:31]sb_0__chanx_right_in;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_reset_0_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6_;
    input grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7_;
    input [0:31]cby_0__chany_top_in;
    input ccff_head;
    output [0:31]sb_0__chanx_right_out;
    output grid_io_leftL_left_right_width_0_height_0_subtile_0__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_1__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_2__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_3__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_4__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_5__pin_a2f_o_0_;
    output grid_io_leftL_left_right_width_0_height_0_subtile_6__pin_a2f_o_0_;
    output [0:31]cby_0__chany_top_out;
    output ccff_tail;
    output prog_reset_fto;
    output prog_clk_fto;
    output config_enable_fto;
    output SE0_fto;
    output SE1_fto;
    output SE2_fto;
    output SC0_fto;
    output SC1_fto;
    output SR_fto;
    input SI;
    output SO;

    wire SE0;
    wire SE1;
    wire SC0;
    wire SC1;
    wire SR;
    wire SE2;
    wire config_enable;
    wire prog_reset;
    wire prog_clk;
    wire [0:6]gfpga_pad_pinput_A2F;
    wire [0:13]gfpga_pad_poutput_F2A;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_;
    wire [0:31]sb_0__chanx_right_in;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_reset_0_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6_;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7_;
    wire [0:31]cby_0__chany_top_in;
    wire ccff_head;
    wire [0:31]sb_0__chanx_right_out;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_0__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_1__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_2__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_3__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_4__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_5__pin_a2f_o_0_;
    wire grid_io_leftL_left_right_width_0_height_0_subtile_6__pin_a2f_o_0_;
    wire [0:31]cby_0__chany_top_out;
    wire ccff_tail;
    wire [0:31]cby_0__0_chany_bottom_out;
    wire [0:31]sb_0__0_chany_top_out;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lreset_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_f2a_i_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lclk_0_;
    wire cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lreset_0_;
    wire grid_io_leftL_left_0_ccff_tail;
    wire cby_0__0_ccff_tail;
    wire prog_clk_mkbuf_out;
    wire prog_reset_mkbuf_out;
    wire prog_reset_fto;
    wire prog_clk_fto;
    wire config_enable_fto;
    wire SE0_fto;
    wire SE1_fto;
    wire SE2_fto;
    wire SC0_fto;
    wire SC1_fto;
    wire SR_fto;
    wire SI;
    wire SO;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out;
    wire grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out;

    grid_io_leftL_left grid_io_leftL_left_0__1_
    (
        .SE0(SE0),
        .SE1(SE1),
        .SC0(SC0),
        .SC1(SC1),
        .SR(SR),
        .SE2(SE2),
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .gfpga_pad_pinput_A2F(gfpga_pad_pinput_A2F),
        .gfpga_pad_poutput_F2A(gfpga_pad_poutput_F2A),
        .top_width_0_height_0_subtile_0__pin_reset_0_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_reset_0_),
        .right_width_0_height_0_subtile_0__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lclk_0_),
        .right_width_0_height_0_subtile_0__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lreset_0_),
        .top_width_0_height_0_subtile_0__pin_clk_0_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_1_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_2_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_3_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_4_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_5_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_6_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out),
        .top_width_0_height_0_subtile_0__pin_clk_7_(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out),
        .right_width_0_height_0_subtile_1__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lclk_0_),
        .right_width_0_height_0_subtile_1__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lreset_0_),
        .right_width_0_height_0_subtile_2__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lclk_0_),
        .right_width_0_height_0_subtile_2__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lreset_0_),
        .right_width_0_height_0_subtile_3__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lclk_0_),
        .right_width_0_height_0_subtile_3__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lreset_0_),
        .right_width_0_height_0_subtile_4__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lclk_0_),
        .right_width_0_height_0_subtile_4__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lreset_0_),
        .right_width_0_height_0_subtile_5__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lclk_0_),
        .right_width_0_height_0_subtile_5__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lreset_0_),
        .right_width_0_height_0_subtile_6__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lclk_0_),
        .right_width_0_height_0_subtile_6__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lreset_0_),
        .right_width_0_height_0_subtile_7__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_7__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lclk_0_),
        .right_width_0_height_0_subtile_7__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lreset_0_),
        .right_width_0_height_0_subtile_8__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_8__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lclk_0_),
        .right_width_0_height_0_subtile_8__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lreset_0_),
        .right_width_0_height_0_subtile_9__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_9__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lclk_0_),
        .right_width_0_height_0_subtile_9__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lreset_0_),
        .right_width_0_height_0_subtile_10__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_10__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lclk_0_),
        .right_width_0_height_0_subtile_10__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lreset_0_),
        .right_width_0_height_0_subtile_11__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_11__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lclk_0_),
        .right_width_0_height_0_subtile_11__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lreset_0_),
        .right_width_0_height_0_subtile_12__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_12__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lclk_0_),
        .right_width_0_height_0_subtile_12__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lreset_0_),
        .right_width_0_height_0_subtile_13__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_13__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lclk_0_),
        .right_width_0_height_0_subtile_13__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lreset_0_),
        .right_width_0_height_0_subtile_14__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_14__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lclk_0_),
        .right_width_0_height_0_subtile_14__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lreset_0_),
        .right_width_0_height_0_subtile_15__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_15__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lclk_0_),
        .right_width_0_height_0_subtile_15__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lreset_0_),
        .right_width_0_height_0_subtile_16__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_16__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lclk_0_),
        .right_width_0_height_0_subtile_16__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lreset_0_),
        .right_width_0_height_0_subtile_17__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_17__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lclk_0_),
        .right_width_0_height_0_subtile_17__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lreset_0_),
        .right_width_0_height_0_subtile_18__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_18__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lclk_0_),
        .right_width_0_height_0_subtile_18__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lreset_0_),
        .right_width_0_height_0_subtile_19__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_19__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lclk_0_),
        .right_width_0_height_0_subtile_19__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lreset_0_),
        .right_width_0_height_0_subtile_20__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_f2a_i_0_),
        .right_width_0_height_0_subtile_20__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lclk_0_),
        .right_width_0_height_0_subtile_20__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lreset_0_),
        .ccff_head(ccff_head),
        .right_width_0_height_0_subtile_0__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_0__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_1__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_1__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_2__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_2__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_3__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_3__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_4__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_4__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_5__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_5__pin_a2f_o_0_),
        .right_width_0_height_0_subtile_6__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_6__pin_a2f_o_0_),
        .ccff_tail(grid_io_leftL_left_0_ccff_tail),
        .SI(SI),
        .SO(SO)
    );
    cby_0_ cby_0__1_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chany_bottom_in(sb_0__0_chany_top_out),
        .chany_top_in(cby_0__chany_top_in),
        .ccff_head(grid_io_leftL_left_0_ccff_tail),
        .chany_bottom_out(cby_0__0_chany_bottom_out),
        .chany_top_out(cby_0__chany_top_out),
        .left_grid_right_width_0_height_0_subtile_0__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_0__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_0__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_1__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_1__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_1__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_2__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_2__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_2__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_3__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_3__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_3__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_4__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_4__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_4__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_5__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_5__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_5__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_6__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_6__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_6__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_7__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_7__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_7__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_7__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_8__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_8__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_8__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_8__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_9__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_9__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_9__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_9__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_10__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_10__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_10__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_10__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_11__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_11__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_11__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_11__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_12__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_12__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_12__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_12__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_13__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_13__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_13__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_13__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_14__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_14__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_14__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_14__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_15__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_15__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_15__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_15__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_16__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_16__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_16__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_16__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_17__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_17__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_17__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_17__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_18__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_18__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_18__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_18__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_19__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_19__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_19__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_19__pin_lreset_0_),
        .left_grid_right_width_0_height_0_subtile_20__pin_f2a_i_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_f2a_i_0_),
        .left_grid_right_width_0_height_0_subtile_20__pin_lclk_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lclk_0_),
        .left_grid_right_width_0_height_0_subtile_20__pin_lreset_0_(cby_0__0_left_grid_right_width_0_height_0_subtile_20__pin_lreset_0_),
        .ccff_tail(cby_0__0_ccff_tail)
    );
    sb_0_ sb_0__0_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chany_top_in(cby_0__0_chany_bottom_out),
        .top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_0__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_1__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_2__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_3__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_4__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_5__pin_a2f_o_0_),
        .top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_(grid_io_leftL_left_right_width_0_height_0_subtile_6__pin_a2f_o_0_),
        .chanx_right_in(sb_0__chanx_right_in),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_),
        .ccff_head(cby_0__0_ccff_tail),
        .chany_top_out(sb_0__0_chany_top_out),
        .chanx_right_out(sb_0__chanx_right_out),
        .ccff_tail(ccff_tail)
    );
    CKBD4BWP30P140HVT prog_clk_mkbuf_0
    (
        .I(prog_clk),
        .Z(prog_clk_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_mkbuf_0
    (
        .I(prog_reset),
        .Z(prog_reset_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_ftb
    (
        .I(prog_reset),
        .Z(prog_reset_fto)
    );
    CKBD4BWP30P140HVT prog_clk_ftb
    (
        .I(prog_clk),
        .Z(prog_clk_fto)
    );
    CKBD4BWP30P140HVT config_enable_ftb
    (
        .I(config_enable),
        .Z(config_enable_fto)
    );
    BUFFD4BWP30P140HVT SE0_ftb
    (
        .I(SE0),
        .Z(SE0_fto)
    );
    BUFFD4BWP30P140HVT SE1_ftb
    (
        .I(SE1),
        .Z(SE1_fto)
    );
    BUFFD4BWP30P140HVT SE2_ftb
    (
        .I(SE2),
        .Z(SE2_fto)
    );
    BUFFD4BWP30P140HVT SC0_ftb
    (
        .I(SC0),
        .Z(SC0_fto)
    );
    BUFFD4BWP30P140HVT SC1_ftb
    (
        .I(SC1),
        .Z(SC1_fto)
    );
    BUFFD4BWP30P140HVT SR_ftb
    (
        .I(SR),
        .Z(SR_fto)
    );
    CKBD1BWP30P140HVT clk0_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_0__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk1_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_1__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk2_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_2__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk3_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_3__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk4_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_4__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk5_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_5__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk6_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_6__mkbuf_out)
    );
    CKBD1BWP30P140HVT clk7_mkbuf_0
    (
        .I(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7_),
        .Z(grid_io_leftL_left_top_width_0_height_0_subtile_0__pin_clk_7__mkbuf_out)
    );
endmodule

