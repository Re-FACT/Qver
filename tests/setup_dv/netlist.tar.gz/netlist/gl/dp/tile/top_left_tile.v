//Generated from netlist by SpyDrNet
//netlist name: SDN_VERILOG_NETLIST_const0
module top_left_tile
(
    config_enable,
    prog_reset,
    prog_clk,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_0__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_1__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_2__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_3__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_4__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_5__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_6__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_7__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_8__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_9__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_10__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_11__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_12__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_13__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_14__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_15__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_16__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_17__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_18__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_19__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_20__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_21__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_22__pin_a2f_o_0_,
    sb_0__right_top_grid_bottom_width_0_height_0_subtile_23__pin_a2f_o_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_,
    sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_,
    sb_0__bottom_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_,
    sb_0__chanx_right_in,
    sb_0__chany_bottom_in,
    ccff_head,
    sb_0__chanx_right_out,
    sb_0__chany_bottom_out,
    ccff_tail,
    prog_reset_fto,
    prog_clk_fto,
    config_enable_fto
);

    input config_enable;
    input prog_reset;
    input prog_clk;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_0__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_1__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_2__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_3__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_4__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_5__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_6__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_7__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_8__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_9__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_10__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_11__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_12__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_13__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_14__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_15__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_16__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_17__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_18__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_19__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_20__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_21__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_22__pin_a2f_o_0_;
    input sb_0__right_top_grid_bottom_width_0_height_0_subtile_23__pin_a2f_o_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    input sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_;
    input sb_0__bottom_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_;
    input [0:31]sb_0__chanx_right_in;
    input [0:31]sb_0__chany_bottom_in;
    input ccff_head;
    output [0:31]sb_0__chanx_right_out;
    output [0:31]sb_0__chany_bottom_out;
    output ccff_tail;
    output prog_reset_fto;
    output prog_clk_fto;
    output config_enable_fto;

    wire config_enable;
    wire prog_reset;
    wire prog_clk;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_0__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_1__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_2__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_3__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_4__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_5__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_6__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_7__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_8__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_9__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_10__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_11__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_12__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_13__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_14__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_15__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_16__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_17__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_18__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_19__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_20__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_21__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_22__pin_a2f_o_0_;
    wire sb_0__right_top_grid_bottom_width_0_height_0_subtile_23__pin_a2f_o_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_;
    wire sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_;
    wire sb_0__bottom_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_;
    wire [0:31]sb_0__chanx_right_in;
    wire [0:31]sb_0__chany_bottom_in;
    wire ccff_head;
    wire [0:31]sb_0__chanx_right_out;
    wire [0:31]sb_0__chany_bottom_out;
    wire ccff_tail;
    wire prog_clk_mkbuf_out;
    wire prog_reset_mkbuf_out;
    wire prog_reset_fto;
    wire prog_clk_fto;
    wire config_enable_fto;

    sb_2_ sb_0__2_
    (
        .config_enable(config_enable),
        .prog_reset(prog_reset_mkbuf_out),
        .prog_clk(prog_clk_mkbuf_out),
        .chanx_right_in(sb_0__chanx_right_in),
        .right_top_grid_bottom_width_0_height_0_subtile_0__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_0__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_1__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_1__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_2__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_2__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_3__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_3__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_4__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_4__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_5__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_5__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_6__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_6__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_7__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_7__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_8__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_8__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_9__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_9__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_10__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_10__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_11__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_11__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_12__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_12__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_13__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_13__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_14__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_14__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_15__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_15__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_16__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_16__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_17__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_17__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_18__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_18__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_19__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_19__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_20__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_20__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_21__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_21__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_22__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_22__pin_a2f_o_0_),
        .right_top_grid_bottom_width_0_height_0_subtile_23__pin_a2f_o_0_(sb_0__right_top_grid_bottom_width_0_height_0_subtile_23__pin_a2f_o_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_0_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_1_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_2_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_3_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_8_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_9_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_10_),
        .right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_(sb_0__right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_11_),
        .chany_bottom_in(sb_0__chany_bottom_in),
        .bottom_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_),
        .bottom_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_(sb_0__bottom_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_),
        .ccff_head(ccff_head),
        .chanx_right_out(sb_0__chanx_right_out),
        .chany_bottom_out(sb_0__chany_bottom_out),
        .ccff_tail(ccff_tail)
    );
    CKBD4BWP30P140HVT prog_clk_mkbuf_0
    (
        .I(prog_clk),
        .Z(prog_clk_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_mkbuf_0
    (
        .I(prog_reset),
        .Z(prog_reset_mkbuf_out)
    );
    CKBD4BWP30P140HVT prog_reset_ftb
    (
        .I(prog_reset),
        .Z(prog_reset_fto)
    );
    CKBD4BWP30P140HVT prog_clk_ftb
    (
        .I(prog_clk),
        .Z(prog_clk_fto)
    );
    CKBD4BWP30P140HVT config_enable_ftb
    (
        .I(config_enable),
        .Z(config_enable_fto)
    );
endmodule

