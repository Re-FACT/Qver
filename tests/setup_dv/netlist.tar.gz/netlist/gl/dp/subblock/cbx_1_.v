/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : Q-2019.12-SP4

/////////////////////////////////////////////////////////////


module cbx_1__cb_mux_size8 ( in, sram, sram_inv, out );
  input [0:7] in;
  input [0:3] sram;
  input [0:3] sram_inv;
  output [0:0] out;
  wire   n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21;

  INVD1BWP30P140HVT U12 ( .I(sram[1]), .ZN(n16) );
  AOI22D1BWP30P140HVT U13 ( .A1(sram[1]), .A2(in[5]), .B1(in[6]), .B2(n16), 
        .ZN(n15) );
  INVD1BWP30P140HVT U14 ( .I(sram[0]), .ZN(n11) );
  AOI22D1BWP30P140HVT U15 ( .A1(sram[0]), .A2(in[0]), .B1(in[1]), .B2(n11), 
        .ZN(n12) );
  ND2D1BWP30P140HVT U16 ( .A1(sram[1]), .A2(n12), .ZN(n13) );
  OAI211D1BWP30P140HVT U17 ( .A1(sram[1]), .A2(in[2]), .B(n13), .C(sram[3]), 
        .ZN(n14) );
  OAI21D1BWP30P140HVT U18 ( .A1(sram[3]), .A2(n15), .B(n14), .ZN(n21) );
  AOI22D1BWP30P140HVT U19 ( .A1(sram[1]), .A2(in[3]), .B1(in[4]), .B2(n16), 
        .ZN(n19) );
  ND2D1BWP30P140HVT U20 ( .A1(sram[1]), .A2(in[7]), .ZN(n18) );
  INVD1BWP30P140HVT U21 ( .I(sram[3]), .ZN(n17) );
  AOI221D1BWP30P140HVT U22 ( .A1(n19), .A2(sram[3]), .B1(n18), .B2(n17), .C(
        sram[2]), .ZN(n20) );
  AO21D1BWP30P140HVT U23 ( .A1(sram[2]), .A2(n21), .B(n20), .Z(out[0]) );
endmodule


module cbx_1__cb_mux_size6 ( in, sram, sram_inv, out );
  input [0:5] in;
  input [0:2] sram;
  input [0:2] sram_inv;
  output [0:0] out;
  wire   n8, n9, n10, n11, n12, n13, n14;

  INVD1BWP30P140HVT U9 ( .I(sram[2]), .ZN(n14) );
  INVD1BWP30P140HVT U10 ( .I(sram[0]), .ZN(n8) );
  AOI22D1BWP30P140HVT U11 ( .A1(sram[0]), .A2(in[2]), .B1(in[3]), .B2(n8), 
        .ZN(n13) );
  AOI22D1BWP30P140HVT U12 ( .A1(sram[2]), .A2(in[0]), .B1(in[4]), .B2(n14), 
        .ZN(n10) );
  AOI22D1BWP30P140HVT U13 ( .A1(sram[2]), .A2(in[1]), .B1(in[5]), .B2(n14), 
        .ZN(n9) );
  AOI22D1BWP30P140HVT U14 ( .A1(sram[0]), .A2(n10), .B1(n9), .B2(n8), .ZN(n11)
         );
  ND2D1BWP30P140HVT U15 ( .A1(sram[1]), .A2(n11), .ZN(n12) );
  OAI31D1BWP30P140HVT U16 ( .A1(sram[1]), .A2(n14), .A3(n13), .B(n12), .ZN(
        out[0]) );
endmodule


module cbx_1__config_group_mem_size63 ( config_enable, prog_reset, prog_clk, 
        ccff_head, mem_out, mem_outb, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:0] ccff_head;
  output [0:62] mem_out;
  output [0:62] mem_outb;
  output [0:0] ccff_tail;
  wire   cb_mux_size8_mem_0_ccff_tail, cb_mux_size8_mem_1_ccff_tail,
         cb_mux_size8_mem_2_ccff_tail, cb_mux_size8_mem_3_ccff_tail,
         cb_mux_size8_mem_4_ccff_tail, cb_mux_size8_mem_5_ccff_tail,
         cb_mux_size8_mem_6_ccff_tail, cb_mux_size8_mem_7_ccff_tail,
         cb_mux_size8_mem_8_ccff_tail, cb_mux_size8_mem_9_ccff_tail,
         cb_mux_size8_mem_10_ccff_tail, cb_mux_size8_mem_11_ccff_tail,
         cb_mux_size8_mem_12_ccff_tail, cb_mux_size6_mem_0_ccff_tail,
         cb_mux_size8_mem_13_ccff_tail, mem_top_ipin_0_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_0_TSMC22ULP_CCFF_1_Q, mem_top_ipin_0_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_13_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_13_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_0_Q, mem_top_ipin_9_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_9_TSMC22ULP_CCFF_1_Q, mem_top_ipin_9_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_8_TSMC22ULP_CCFF_2_Q, mem_top_ipin_8_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_8_TSMC22ULP_CCFF_0_Q, mem_top_ipin_7_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_7_TSMC22ULP_CCFF_1_Q, mem_top_ipin_7_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_6_TSMC22ULP_CCFF_2_Q, mem_top_ipin_6_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_6_TSMC22ULP_CCFF_0_Q, mem_top_ipin_5_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_5_TSMC22ULP_CCFF_1_Q, mem_top_ipin_5_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_4_TSMC22ULP_CCFF_2_Q, mem_top_ipin_4_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_4_TSMC22ULP_CCFF_0_Q, mem_top_ipin_3_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_3_TSMC22ULP_CCFF_1_Q, mem_top_ipin_3_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_2_TSMC22ULP_CCFF_2_Q, mem_top_ipin_2_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_2_TSMC22ULP_CCFF_0_Q, mem_top_ipin_1_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_1_TSMC22ULP_CCFF_1_Q, mem_top_ipin_1_TSMC22ULP_CCFF_0_Q,
         eco_net, eco_net_0, eco_net_1_0, eco_net_2_0, eco_net_3_0,
         eco_net_4_0, eco_net_5_0, eco_net_6_0, eco_net_7_0, eco_net_8_0,
         eco_net_9_0, eco_net_10_0, eco_net_11_0, eco_net_12_0, eco_net_13_0,
         eco_net_14_0, eco_net_15_0, eco_net_16_0, eco_net_17_0, eco_net_18_0,
         eco_net_19_0, eco_net_20_0, eco_net_21_0, eco_net_22_0, eco_net_23_0,
         eco_net_24_0, eco_net_25_0, eco_net_26_0, eco_net_27_0, eco_net_28_0,
         eco_net_29_0, eco_net_30_0, eco_net_31_0, eco_net_32_0, eco_net_33_0,
         eco_net_34_0, eco_net_35_0, eco_net_36_0, eco_net_37_0, eco_net_38_0,
         eco_net_39_0, eco_net_40_0, eco_net_41_0, eco_net_42_0, eco_net_43_0,
         eco_net_44_0, eco_net_45_0, eco_net_46_0, eco_net_47_0, eco_net_48_0,
         eco_net_49_0, eco_net_50_0, eco_net_51_0, eco_net_52_0, eco_net_53_0,
         eco_net_54_0, eco_net_55_0, eco_net_56_0, eco_net_57_0, eco_net_58_0,
         eco_net_59_0, eco_net_60_0, eco_net_61_0, eco_net_62_0, eco_net_63_0,
         eco_net_64_0, eco_net_65_0, eco_net_66_0, eco_net_67_0, eco_net_68_0,
         eco_net_69_0, eco_net_70_0;

  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_8_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_62_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size6_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_61_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_60_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_70_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(ccff_tail[0])
         );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_69_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_68_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_67_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_66_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_13_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_65_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_64_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_63_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_59_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_12_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_58_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_57_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_56_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_55_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_11_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_54_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_53_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_52_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_51_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_50_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_49_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_48_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_47_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_46_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_45_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_44_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_43_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        cb_mux_size8_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_42_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_41_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_40_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_39_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_38_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_37_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_36_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_35_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_34_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_33_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_32_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_31_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_30_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_29_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_28_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_27_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_26_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_25_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_24_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_23_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_22_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_21_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_20_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_19_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_18_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_17_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_16_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_15_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_14_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_13_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_12_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_11_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        cb_mux_size8_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_10_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_9_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q) );
  ND2D1BWP30P140HVT U127 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[1]) );
  INVD1BWP30P140HVT U128 ( .I(mem_outb[1]), .ZN(mem_out[1]) );
  ND2D1BWP30P140HVT U129 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[2]) );
  INVD1BWP30P140HVT U130 ( .I(mem_outb[2]), .ZN(mem_out[2]) );
  ND2D1BWP30P140HVT U131 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_0_ccff_tail), .ZN(mem_outb[3]) );
  INVD1BWP30P140HVT U132 ( .I(mem_outb[3]), .ZN(mem_out[3]) );
  ND2D1BWP30P140HVT U133 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[4]) );
  INVD1BWP30P140HVT U134 ( .I(mem_outb[4]), .ZN(mem_out[4]) );
  ND2D1BWP30P140HVT U135 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[5]) );
  INVD1BWP30P140HVT U136 ( .I(mem_outb[5]), .ZN(mem_out[5]) );
  ND2D1BWP30P140HVT U137 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[6]) );
  INVD1BWP30P140HVT U138 ( .I(mem_outb[6]), .ZN(mem_out[6]) );
  ND2D1BWP30P140HVT U139 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_1_ccff_tail), .ZN(mem_outb[7]) );
  INVD1BWP30P140HVT U140 ( .I(mem_outb[7]), .ZN(mem_out[7]) );
  ND2D1BWP30P140HVT U141 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[8]) );
  INVD1BWP30P140HVT U142 ( .I(mem_outb[8]), .ZN(mem_out[8]) );
  ND2D1BWP30P140HVT U143 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[9]) );
  INVD1BWP30P140HVT U144 ( .I(mem_outb[9]), .ZN(mem_out[9]) );
  ND2D1BWP30P140HVT U145 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[10]) );
  INVD1BWP30P140HVT U146 ( .I(mem_outb[10]), .ZN(mem_out[10]) );
  ND2D1BWP30P140HVT U147 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_2_ccff_tail), .ZN(mem_outb[11]) );
  INVD1BWP30P140HVT U148 ( .I(mem_outb[11]), .ZN(mem_out[11]) );
  ND2D1BWP30P140HVT U149 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[12]) );
  INVD1BWP30P140HVT U150 ( .I(mem_outb[12]), .ZN(mem_out[12]) );
  ND2D1BWP30P140HVT U151 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[13]) );
  INVD1BWP30P140HVT U152 ( .I(mem_outb[13]), .ZN(mem_out[13]) );
  ND2D1BWP30P140HVT U153 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[14]) );
  INVD1BWP30P140HVT U154 ( .I(mem_outb[14]), .ZN(mem_out[14]) );
  ND2D1BWP30P140HVT U155 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_3_ccff_tail), .ZN(mem_outb[15]) );
  INVD1BWP30P140HVT U156 ( .I(mem_outb[15]), .ZN(mem_out[15]) );
  ND2D1BWP30P140HVT U157 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[16]) );
  INVD1BWP30P140HVT U158 ( .I(mem_outb[16]), .ZN(mem_out[16]) );
  ND2D1BWP30P140HVT U159 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[17]) );
  INVD1BWP30P140HVT U160 ( .I(mem_outb[17]), .ZN(mem_out[17]) );
  ND2D1BWP30P140HVT U161 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[18]) );
  INVD1BWP30P140HVT U162 ( .I(mem_outb[18]), .ZN(mem_out[18]) );
  ND2D1BWP30P140HVT U163 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_4_ccff_tail), .ZN(mem_outb[19]) );
  INVD1BWP30P140HVT U164 ( .I(mem_outb[19]), .ZN(mem_out[19]) );
  ND2D1BWP30P140HVT U165 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[20]) );
  INVD1BWP30P140HVT U166 ( .I(mem_outb[20]), .ZN(mem_out[20]) );
  ND2D1BWP30P140HVT U167 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[21]) );
  INVD1BWP30P140HVT U168 ( .I(mem_outb[21]), .ZN(mem_out[21]) );
  ND2D1BWP30P140HVT U169 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[22]) );
  INVD1BWP30P140HVT U170 ( .I(mem_outb[22]), .ZN(mem_out[22]) );
  ND2D1BWP30P140HVT U171 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_5_ccff_tail), .ZN(mem_outb[23]) );
  INVD1BWP30P140HVT U172 ( .I(mem_outb[23]), .ZN(mem_out[23]) );
  ND2D1BWP30P140HVT U173 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[24]) );
  INVD1BWP30P140HVT U174 ( .I(mem_outb[24]), .ZN(mem_out[24]) );
  ND2D1BWP30P140HVT U175 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[25]) );
  INVD1BWP30P140HVT U176 ( .I(mem_outb[25]), .ZN(mem_out[25]) );
  ND2D1BWP30P140HVT U177 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[26]) );
  INVD1BWP30P140HVT U178 ( .I(mem_outb[26]), .ZN(mem_out[26]) );
  ND2D1BWP30P140HVT U179 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_6_ccff_tail), .ZN(mem_outb[27]) );
  INVD1BWP30P140HVT U180 ( .I(mem_outb[27]), .ZN(mem_out[27]) );
  ND2D1BWP30P140HVT U181 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[28]) );
  INVD1BWP30P140HVT U182 ( .I(mem_outb[28]), .ZN(mem_out[28]) );
  ND2D1BWP30P140HVT U183 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[29]) );
  INVD1BWP30P140HVT U184 ( .I(mem_outb[29]), .ZN(mem_out[29]) );
  ND2D1BWP30P140HVT U185 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[30]) );
  INVD1BWP30P140HVT U186 ( .I(mem_outb[30]), .ZN(mem_out[30]) );
  ND2D1BWP30P140HVT U187 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_7_ccff_tail), .ZN(mem_outb[31]) );
  INVD1BWP30P140HVT U188 ( .I(mem_outb[31]), .ZN(mem_out[31]) );
  ND2D1BWP30P140HVT U189 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[32]) );
  INVD1BWP30P140HVT U190 ( .I(mem_outb[32]), .ZN(mem_out[32]) );
  ND2D1BWP30P140HVT U191 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[33]) );
  INVD1BWP30P140HVT U192 ( .I(mem_outb[33]), .ZN(mem_out[33]) );
  ND2D1BWP30P140HVT U193 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[34]) );
  INVD1BWP30P140HVT U194 ( .I(mem_outb[34]), .ZN(mem_out[34]) );
  ND2D1BWP30P140HVT U195 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_8_ccff_tail), .ZN(mem_outb[35]) );
  INVD1BWP30P140HVT U196 ( .I(mem_outb[35]), .ZN(mem_out[35]) );
  ND2D1BWP30P140HVT U197 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[36]) );
  INVD1BWP30P140HVT U198 ( .I(mem_outb[36]), .ZN(mem_out[36]) );
  ND2D1BWP30P140HVT U199 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[37]) );
  INVD1BWP30P140HVT U200 ( .I(mem_outb[37]), .ZN(mem_out[37]) );
  ND2D1BWP30P140HVT U201 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[38]) );
  INVD1BWP30P140HVT U202 ( .I(mem_outb[38]), .ZN(mem_out[38]) );
  ND2D1BWP30P140HVT U203 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_9_ccff_tail), .ZN(mem_outb[39]) );
  INVD1BWP30P140HVT U204 ( .I(mem_outb[39]), .ZN(mem_out[39]) );
  ND2D1BWP30P140HVT U205 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[40]) );
  INVD1BWP30P140HVT U206 ( .I(mem_outb[40]), .ZN(mem_out[40]) );
  ND2D1BWP30P140HVT U207 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[41]) );
  INVD1BWP30P140HVT U208 ( .I(mem_outb[41]), .ZN(mem_out[41]) );
  ND2D1BWP30P140HVT U209 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[42]) );
  INVD1BWP30P140HVT U210 ( .I(mem_outb[42]), .ZN(mem_out[42]) );
  ND2D1BWP30P140HVT U211 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_10_ccff_tail), .ZN(mem_outb[43]) );
  INVD1BWP30P140HVT U212 ( .I(mem_outb[43]), .ZN(mem_out[43]) );
  ND2D1BWP30P140HVT U213 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[44]) );
  INVD1BWP30P140HVT U214 ( .I(mem_outb[44]), .ZN(mem_out[44]) );
  ND2D1BWP30P140HVT U215 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[45]) );
  INVD1BWP30P140HVT U216 ( .I(mem_outb[45]), .ZN(mem_out[45]) );
  ND2D1BWP30P140HVT U217 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[46]) );
  INVD1BWP30P140HVT U218 ( .I(mem_outb[46]), .ZN(mem_out[46]) );
  ND2D1BWP30P140HVT U219 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_11_ccff_tail), .ZN(mem_outb[47]) );
  INVD1BWP30P140HVT U220 ( .I(mem_outb[47]), .ZN(mem_out[47]) );
  ND2D1BWP30P140HVT U221 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[48]) );
  INVD1BWP30P140HVT U222 ( .I(mem_outb[48]), .ZN(mem_out[48]) );
  ND2D1BWP30P140HVT U223 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[49]) );
  INVD1BWP30P140HVT U224 ( .I(mem_outb[49]), .ZN(mem_out[49]) );
  ND2D1BWP30P140HVT U225 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[50]) );
  INVD1BWP30P140HVT U226 ( .I(mem_outb[50]), .ZN(mem_out[50]) );
  ND2D1BWP30P140HVT U227 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_12_ccff_tail), .ZN(mem_outb[51]) );
  INVD1BWP30P140HVT U228 ( .I(mem_outb[51]), .ZN(mem_out[51]) );
  ND2D1BWP30P140HVT U229 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[52]) );
  INVD1BWP30P140HVT U230 ( .I(mem_outb[52]), .ZN(mem_out[52]) );
  ND2D1BWP30P140HVT U231 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[53]) );
  INVD1BWP30P140HVT U232 ( .I(mem_outb[53]), .ZN(mem_out[53]) );
  ND2D1BWP30P140HVT U233 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_0_ccff_tail), .ZN(mem_outb[54]) );
  INVD1BWP30P140HVT U234 ( .I(mem_outb[54]), .ZN(mem_out[54]) );
  ND2D1BWP30P140HVT U235 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[55]) );
  INVD1BWP30P140HVT U236 ( .I(mem_outb[55]), .ZN(mem_out[55]) );
  ND2D1BWP30P140HVT U237 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[56]) );
  INVD1BWP30P140HVT U238 ( .I(mem_outb[56]), .ZN(mem_out[56]) );
  ND2D1BWP30P140HVT U239 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[57]) );
  INVD1BWP30P140HVT U240 ( .I(mem_outb[57]), .ZN(mem_out[57]) );
  ND2D1BWP30P140HVT U241 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_13_ccff_tail), .ZN(mem_outb[58]) );
  INVD1BWP30P140HVT U242 ( .I(mem_outb[58]), .ZN(mem_out[58]) );
  ND2D1BWP30P140HVT U243 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[59]) );
  INVD1BWP30P140HVT U244 ( .I(mem_outb[59]), .ZN(mem_out[59]) );
  ND2D1BWP30P140HVT U245 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[60]) );
  INVD1BWP30P140HVT U246 ( .I(mem_outb[60]), .ZN(mem_out[60]) );
  ND2D1BWP30P140HVT U247 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[61]) );
  INVD1BWP30P140HVT U248 ( .I(mem_outb[61]), .ZN(mem_out[61]) );
  ND2D1BWP30P140HVT U249 ( .A1(config_enable[0]), .A2(ccff_tail[0]), .ZN(
        mem_outb[62]) );
  INVD1BWP30P140HVT U250 ( .I(mem_outb[62]), .ZN(mem_out[62]) );
  ND2D1BWP30P140HVT U251 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[0]) );
  INVD1BWP30P140HVT U252 ( .I(mem_outb[0]), .ZN(mem_out[0]) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_cp_buf2 ( .I(eco_net_1_0), .Z(eco_net) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cp_buf2 ( .I(eco_net_1_0), .Z(eco_net_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cp_buf1 ( .I(prog_clk[0]), .Z(eco_net_1_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_cdn_buf2 ( .I(eco_net_4_0), .Z(eco_net_2_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cdn_buf2 ( .I(eco_net_4_0), .Z(
        eco_net_3_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cdn_buf1 ( .I(prog_reset[0]), .Z(
        eco_net_4_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del1 ( .I(ccff_head[0]), .Z(eco_net_5_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del2 ( .I(eco_net_5_0), .Z(eco_net_6_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del2 ( .I(cb_mux_size8_mem_7_ccff_tail), 
        .Z(eco_net_7_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_0 ( .I(eco_net_6_0), .Z(eco_net_8_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_1 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_9_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_2 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q), .Z(eco_net_10_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_3 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q), .Z(eco_net_11_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_0 ( .I(cb_mux_size8_mem_0_ccff_tail), 
        .Z(eco_net_12_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_1 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q), .Z(eco_net_13_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_2 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q), .Z(eco_net_14_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_3 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q), .Z(eco_net_15_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_0 ( .I(cb_mux_size8_mem_1_ccff_tail), 
        .Z(eco_net_16_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_1 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_17_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_2 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q), .Z(eco_net_18_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_3 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q), .Z(eco_net_19_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_0 ( .I(cb_mux_size8_mem_2_ccff_tail), 
        .Z(eco_net_20_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_1 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q), .Z(eco_net_21_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_2 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q), .Z(eco_net_22_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_3 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q), .Z(eco_net_23_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_0 ( .I(cb_mux_size8_mem_3_ccff_tail), 
        .Z(eco_net_24_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_1 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_25_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_2 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q), .Z(eco_net_26_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_3 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q), .Z(eco_net_27_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_0 ( .I(cb_mux_size8_mem_4_ccff_tail), 
        .Z(eco_net_28_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_1 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q), .Z(eco_net_29_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_2 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q), .Z(eco_net_30_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_3 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q), .Z(eco_net_31_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_0 ( .I(cb_mux_size8_mem_5_ccff_tail), 
        .Z(eco_net_32_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_1 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_33_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_2 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q), .Z(eco_net_34_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_3 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q), .Z(eco_net_35_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_0 ( .I(cb_mux_size8_mem_6_ccff_tail), 
        .Z(eco_net_36_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_1 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q), .Z(eco_net_37_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_2 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q), .Z(eco_net_38_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_3 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q), .Z(eco_net_39_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_0 ( .I(eco_net_7_0), .Z(eco_net_40_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_1 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q), .Z(eco_net_41_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_2 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q), .Z(eco_net_42_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_3 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q), .Z(eco_net_43_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_0 ( .I(cb_mux_size8_mem_8_ccff_tail), 
        .Z(eco_net_44_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_1 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q), .Z(eco_net_45_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_2 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q), .Z(eco_net_46_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_3 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q), .Z(eco_net_47_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_0 ( .I(cb_mux_size8_mem_9_ccff_tail), 
        .Z(eco_net_48_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_1 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q), .Z(eco_net_49_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_2 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q), .Z(eco_net_50_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_3 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q), .Z(eco_net_51_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_0 ( .I(cb_mux_size8_mem_10_ccff_tail), .Z(eco_net_52_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_1 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q), .Z(eco_net_53_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_2 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q), .Z(eco_net_54_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_3 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q), .Z(eco_net_55_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_0 ( .I(cb_mux_size8_mem_11_ccff_tail), .Z(eco_net_56_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_1 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q), .Z(eco_net_57_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_2 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q), .Z(eco_net_58_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_3 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q), .Z(eco_net_59_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_0 ( .I(cb_mux_size8_mem_12_ccff_tail), .Z(eco_net_60_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_1 ( .I(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q), .Z(eco_net_61_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_2 ( .I(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q), .Z(eco_net_62_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_0 ( .I(cb_mux_size6_mem_0_ccff_tail), 
        .Z(eco_net_63_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_1 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q), .Z(eco_net_64_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_2 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q), .Z(eco_net_65_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_3 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q), .Z(eco_net_66_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_0 ( .I(cb_mux_size8_mem_13_ccff_tail), .Z(eco_net_67_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_1 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q), .Z(eco_net_68_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_2 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q), .Z(eco_net_69_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_3 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q), .Z(eco_net_70_0) );
endmodule


module cbx_1_ ( config_enable, prog_reset, prog_clk, chanx_left_in, 
        chanx_right_in, ccff_head, chanx_left_out, chanx_right_out, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_, ccff_tail
 );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:31] chanx_left_in;
  input [0:31] chanx_right_in;
  input [0:0] ccff_head;
  output [0:31] chanx_left_out;
  output [0:31] chanx_right_out;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_;
  output [0:0] ccff_tail;
  wire   n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35, n36, n37,
         n38, n39, n5;
  wire   [1:5] chanx_left_out0;
  wire   [0:3] cb_mux_size8_0_sram;
  wire   [0:3] cb_mux_size8_0_sram_inv;
  wire   [0:3] cb_mux_size8_1_sram;
  wire   [0:3] cb_mux_size8_1_sram_inv;
  wire   [0:3] cb_mux_size8_2_sram;
  wire   [0:3] cb_mux_size8_2_sram_inv;
  wire   [0:3] cb_mux_size8_3_sram;
  wire   [0:3] cb_mux_size8_3_sram_inv;
  wire   [0:3] cb_mux_size8_4_sram;
  wire   [0:3] cb_mux_size8_4_sram_inv;
  wire   [0:3] cb_mux_size8_5_sram;
  wire   [0:3] cb_mux_size8_5_sram_inv;
  wire   [0:3] cb_mux_size8_6_sram;
  wire   [0:3] cb_mux_size8_6_sram_inv;
  wire   [0:3] cb_mux_size8_7_sram;
  wire   [0:3] cb_mux_size8_7_sram_inv;
  wire   [0:3] cb_mux_size8_8_sram;
  wire   [0:3] cb_mux_size8_8_sram_inv;
  wire   [0:3] cb_mux_size8_9_sram;
  wire   [0:3] cb_mux_size8_9_sram_inv;
  wire   [0:3] cb_mux_size8_10_sram;
  wire   [0:3] cb_mux_size8_10_sram_inv;
  wire   [0:3] cb_mux_size8_11_sram;
  wire   [0:3] cb_mux_size8_11_sram_inv;
  wire   [0:3] cb_mux_size8_12_sram;
  wire   [0:3] cb_mux_size8_12_sram_inv;
  wire   [0:3] cb_mux_size8_13_sram;
  wire   [0:3] cb_mux_size8_13_sram_inv;
  wire   [0:3] cb_mux_size8_14_sram;
  wire   [0:3] cb_mux_size8_14_sram_inv;
  wire   [0:2] cb_mux_size6_0_sram;
  wire   [0:2] cb_mux_size6_0_sram_inv;
  assign chanx_left_out[6] = chanx_right_in[6];
  assign chanx_left_out[7] = chanx_right_in[7];
  assign chanx_left_out[8] = chanx_right_in[8];
  assign chanx_left_out[9] = chanx_right_in[9];
  assign chanx_left_out[10] = chanx_right_in[10];
  assign chanx_left_out[11] = chanx_right_in[11];
  assign chanx_left_out[12] = chanx_right_in[12];
  assign chanx_left_out[13] = chanx_right_in[13];
  assign chanx_left_out[14] = chanx_right_in[14];
  assign chanx_left_out[15] = chanx_right_in[15];
  assign chanx_left_out[16] = chanx_right_in[16];
  assign chanx_left_out[17] = chanx_right_in[17];
  assign chanx_left_out[18] = chanx_right_in[18];
  assign chanx_left_out[19] = chanx_right_in[19];
  assign chanx_left_out[20] = chanx_right_in[20];
  assign chanx_left_out[21] = chanx_right_in[21];
  assign chanx_left_out[22] = chanx_right_in[22];
  assign chanx_left_out[23] = chanx_right_in[23];
  assign chanx_left_out[24] = chanx_right_in[24];
  assign chanx_left_out[25] = chanx_right_in[25];
  assign chanx_left_out[26] = chanx_right_in[26];
  assign chanx_left_out[27] = chanx_right_in[27];
  assign chanx_left_out[28] = chanx_right_in[28];
  assign chanx_left_out[29] = chanx_right_in[29];
  assign chanx_left_out[30] = chanx_right_in[30];
  assign chanx_left_out[31] = chanx_right_in[31];
  assign chanx_left_out[3] = chanx_right_in[3];
  assign chanx_left_out[2] = chanx_right_in[2];
  assign chanx_left_out[0] = chanx_right_in[0];
  assign chanx_left_out[1] = chanx_right_in[1];
  assign chanx_left_out[5] = chanx_right_in[5];
  assign chanx_left_out[4] = chanx_right_in[4];
  assign chanx_right_out[0] = chanx_left_in[0];
  assign chanx_right_out[1] = chanx_left_in[1];
  assign chanx_right_out[2] = chanx_left_in[2];
  assign chanx_right_out[3] = chanx_left_in[3];
  assign chanx_right_out[4] = chanx_left_in[4];
  assign chanx_right_out[5] = chanx_left_in[5];
  assign chanx_right_out[6] = chanx_left_in[6];
  assign chanx_right_out[7] = chanx_left_in[7];
  assign chanx_right_out[8] = chanx_left_in[8];
  assign chanx_right_out[9] = chanx_left_in[9];
  assign chanx_right_out[10] = chanx_left_in[10];
  assign chanx_right_out[11] = chanx_left_in[11];
  assign chanx_right_out[12] = chanx_left_in[12];
  assign chanx_right_out[13] = chanx_left_in[13];
  assign chanx_right_out[14] = chanx_left_in[14];
  assign chanx_right_out[15] = chanx_left_in[15];
  assign chanx_right_out[16] = chanx_left_in[16];
  assign chanx_right_out[17] = chanx_left_in[17];
  assign chanx_right_out[18] = chanx_left_in[18];
  assign chanx_right_out[19] = chanx_left_in[19];
  assign chanx_right_out[20] = chanx_left_in[20];
  assign chanx_right_out[21] = chanx_left_in[21];
  assign chanx_right_out[22] = chanx_left_in[22];
  assign chanx_right_out[23] = chanx_left_in[23];
  assign chanx_right_out[24] = chanx_left_in[24];
  assign chanx_right_out[25] = chanx_left_in[25];
  assign chanx_right_out[26] = chanx_left_in[26];
  assign chanx_right_out[27] = chanx_left_in[27];
  assign chanx_right_out[28] = chanx_left_in[28];
  assign chanx_right_out[29] = chanx_left_in[29];
  assign chanx_right_out[30] = chanx_left_in[30];
  assign chanx_right_out[31] = chanx_left_in[31];

  cbx_1__cb_mux_size8 mux_top_ipin_0 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[25], 
        chanx_right_in[25]}), .sram(cb_mux_size8_0_sram), .sram_inv(
        cb_mux_size8_0_sram_inv), .out(n24) );
  cbx_1__cb_mux_size8 mux_top_ipin_1 ( .in({chanx_left_in[1], 
        chanx_left_out0[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[26], 
        chanx_right_in[26]}), .sram(cb_mux_size8_1_sram), .sram_inv(
        cb_mux_size8_1_sram_inv), .out(n25) );
  cbx_1__cb_mux_size8 mux_top_ipin_2 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[27], 
        chanx_right_in[27]}), .sram(cb_mux_size8_2_sram), .sram_inv(
        cb_mux_size8_2_sram_inv), .out(n26) );
  cbx_1__cb_mux_size8 mux_top_ipin_3 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[28], 
        chanx_right_in[28]}), .sram(cb_mux_size8_3_sram), .sram_inv(
        cb_mux_size8_3_sram_inv), .out(n27) );
  cbx_1__cb_mux_size8 mux_top_ipin_4 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[29], 
        chanx_right_in[29]}), .sram(cb_mux_size8_4_sram), .sram_inv(
        cb_mux_size8_4_sram_inv), .out(n28) );
  cbx_1__cb_mux_size8 mux_top_ipin_5 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[17], chanx_right_in[17], chanx_left_in[30], 
        chanx_right_in[30]}), .sram(cb_mux_size8_5_sram), .sram_inv(
        cb_mux_size8_5_sram_inv), .out(n29) );
  cbx_1__cb_mux_size8 mux_top_ipin_6 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[18], chanx_right_in[18], chanx_left_in[31], 
        chanx_right_in[31]}), .sram(cb_mux_size8_6_sram), .sram_inv(
        cb_mux_size8_6_sram_inv), .out(n30) );
  cbx_1__cb_mux_size8 mux_top_ipin_7 ( .in({chanx_left_in[1], 
        chanx_left_out0[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[19], 
        chanx_right_in[19]}), .sram(cb_mux_size8_7_sram), .sram_inv(
        cb_mux_size8_7_sram_inv), .out(n31) );
  cbx_1__cb_mux_size8 mux_top_ipin_8 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[20], 
        chanx_right_in[20]}), .sram(cb_mux_size8_8_sram), .sram_inv(
        cb_mux_size8_8_sram_inv), .out(n32) );
  cbx_1__cb_mux_size8 mux_top_ipin_9 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[21], 
        chanx_right_in[21]}), .sram(cb_mux_size8_9_sram), .sram_inv(
        cb_mux_size8_9_sram_inv), .out(n33) );
  cbx_1__cb_mux_size8 mux_top_ipin_10 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[22], 
        chanx_right_in[22]}), .sram(cb_mux_size8_10_sram), .sram_inv(
        cb_mux_size8_10_sram_inv), .out(n34) );
  cbx_1__cb_mux_size8 mux_top_ipin_11 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[23], 
        chanx_right_in[23]}), .sram(cb_mux_size8_11_sram), .sram_inv(
        cb_mux_size8_11_sram_inv), .out(n35) );
  cbx_1__cb_mux_size8 mux_top_ipin_12 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[17], chanx_right_in[17], chanx_left_in[24], 
        chanx_right_in[24]}), .sram(cb_mux_size8_12_sram), .sram_inv(
        cb_mux_size8_12_sram_inv), .out(n36) );
  cbx_1__cb_mux_size8 mux_top_ipin_14 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[19], chanx_right_in[19], chanx_left_in[26], 
        chanx_right_in[26]}), .sram(cb_mux_size8_13_sram), .sram_inv(
        cb_mux_size8_13_sram_inv), .out(n38) );
  cbx_1__cb_mux_size8 mux_top_ipin_15 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[20], chanx_right_in[20], chanx_left_in[27], 
        chanx_right_in[27]}), .sram(cb_mux_size8_14_sram), .sram_inv(
        cb_mux_size8_14_sram_inv), .out(n39) );
  cbx_1__cb_mux_size6 mux_top_ipin_13 ( .in({chanx_left_in[1], 
        chanx_left_out0[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[25], chanx_right_in[25]}), .sram(cb_mux_size6_0_sram), 
        .sram_inv(cb_mux_size6_0_sram_inv), .out(n37) );
  cbx_1__config_group_mem_size63 cbx_1__config_group_mem_size63 ( 
        .config_enable(config_enable[0]), .prog_reset(prog_reset[0]), 
        .prog_clk(prog_clk[0]), .ccff_head(ccff_head[0]), .mem_out({
        cb_mux_size8_0_sram, cb_mux_size8_1_sram, cb_mux_size8_2_sram, 
        cb_mux_size8_3_sram, cb_mux_size8_4_sram, cb_mux_size8_5_sram, 
        cb_mux_size8_6_sram, cb_mux_size8_7_sram, cb_mux_size8_8_sram, 
        cb_mux_size8_9_sram, cb_mux_size8_10_sram, cb_mux_size8_11_sram, 
        cb_mux_size8_12_sram, cb_mux_size6_0_sram, cb_mux_size8_13_sram, 
        cb_mux_size8_14_sram}), .mem_outb({cb_mux_size8_0_sram_inv, 
        cb_mux_size8_1_sram_inv, cb_mux_size8_2_sram_inv, 
        cb_mux_size8_3_sram_inv, cb_mux_size8_4_sram_inv, 
        cb_mux_size8_5_sram_inv, cb_mux_size8_6_sram_inv, 
        cb_mux_size8_7_sram_inv, cb_mux_size8_8_sram_inv, 
        cb_mux_size8_9_sram_inv, cb_mux_size8_10_sram_inv, 
        cb_mux_size8_11_sram_inv, cb_mux_size8_12_sram_inv, 
        cb_mux_size6_0_sram_inv, cb_mux_size8_13_sram_inv, 
        cb_mux_size8_14_sram_inv}), .ccff_tail(ccff_tail[0]) );
  BUFFD3BWP30P140HVT U1 ( .I(n37), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_13_[0]) );
  INVD2BWP30P140HVT U2 ( .I(n5), .ZN(chanx_left_out0[1]) );
  INVD12BWP30P140HVT U3 ( .I(chanx_right_in[1]), .ZN(n5) );
  BUFFD6BWP30P140HVT U4 ( .I(n31), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_7_[0]) );
  BUFFD6BWP30P140HVT U5 ( .I(n25), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_1_[0]) );
  BUFFD6BWP30P140HVT U6 ( .I(n39), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_[0]) );
  BUFFD6BWP30P140HVT U7 ( .I(n38), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_[0]) );
  BUFFD6BWP30P140HVT U8 ( .I(n36), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_12_[0]) );
  BUFFD6BWP30P140HVT U9 ( .I(n35), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_11_[0]) );
  BUFFD6BWP30P140HVT U10 ( .I(n34), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_10_[0]) );
  BUFFD6BWP30P140HVT U11 ( .I(n33), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_9_[0]) );
  BUFFD6BWP30P140HVT U12 ( .I(n32), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_8_[0]) );
  BUFFD6BWP30P140HVT U13 ( .I(n30), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_6_[0]) );
  BUFFD6BWP30P140HVT U14 ( .I(n29), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_5_[0]) );
  BUFFD6BWP30P140HVT U15 ( .I(n28), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_4_[0]) );
  BUFFD6BWP30P140HVT U16 ( .I(n27), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_3_[0]) );
  BUFFD6BWP30P140HVT U17 ( .I(n26), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_2_[0]) );
  BUFFD6BWP30P140HVT U18 ( .I(n24), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_I_0_[0]) );
endmodule

