/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : Q-2019.12-SP4

/////////////////////////////////////////////////////////////


module sb_6__sb_mux_size4 ( in, sram, sram_inv, out );
  input [0:3] in;
  input [0:2] sram;
  input [0:2] sram_inv;
  output [0:0] out;
  wire   n6, n7, n8, n9, n10;

  ND2D1BWP30P140HVT U7 ( .A1(in[3]), .A2(sram[1]), .ZN(n10) );
  INVD1BWP30P140HVT U8 ( .I(sram[0]), .ZN(n6) );
  AOI22D1BWP30P140HVT U9 ( .A1(sram[0]), .A2(in[0]), .B1(in[1]), .B2(n6), .ZN(
        n7) );
  ND2D1BWP30P140HVT U10 ( .A1(sram[1]), .A2(n7), .ZN(n8) );
  OAI211D1BWP30P140HVT U11 ( .A1(sram[1]), .A2(in[2]), .B(n8), .C(sram[2]), 
        .ZN(n9) );
  OAI21D1BWP30P140HVT U12 ( .A1(n10), .A2(sram[2]), .B(n9), .ZN(out[0]) );
endmodule


module sb_6__sb_mux_size2 ( in, sram, sram_inv, out );
  input [0:1] in;
  input [0:1] sram;
  input [0:1] sram_inv;
  output [0:0] out;
  wire   n3, n4;

  INVD1BWP30P140HVT U4 ( .I(in[0]), .ZN(n4) );
  OAI21D1BWP30P140HVT U5 ( .A1(in[1]), .A2(sram[0]), .B(sram[1]), .ZN(n3) );
  AOI21D1BWP30P140HVT U6 ( .A1(sram[0]), .A2(n4), .B(n3), .ZN(out[0]) );
endmodule


module sb_6__config_group_mem_size96 ( config_enable, prog_reset, prog_clk, 
        ccff_head, mem_out, mem_outb, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:0] ccff_head;
  output [0:95] mem_out;
  output [0:95] mem_outb;
  output [0:0] ccff_tail;
  wire   sb_mux_size4_mem_0_ccff_tail, sb_mux_size4_mem_1_ccff_tail,
         sb_mux_size4_mem_2_ccff_tail, sb_mux_size4_mem_3_ccff_tail,
         sb_mux_size4_mem_4_ccff_tail, sb_mux_size4_mem_5_ccff_tail,
         sb_mux_size4_mem_6_ccff_tail, sb_mux_size4_mem_7_ccff_tail,
         sb_mux_size4_mem_8_ccff_tail, sb_mux_size4_mem_9_ccff_tail,
         sb_mux_size4_mem_10_ccff_tail, sb_mux_size4_mem_11_ccff_tail,
         sb_mux_size2_mem_0_ccff_tail, sb_mux_size2_mem_1_ccff_tail,
         sb_mux_size2_mem_2_ccff_tail, sb_mux_size2_mem_3_ccff_tail,
         sb_mux_size2_mem_4_ccff_tail, sb_mux_size2_mem_5_ccff_tail,
         sb_mux_size2_mem_6_ccff_tail, sb_mux_size2_mem_7_ccff_tail,
         sb_mux_size2_mem_8_ccff_tail, sb_mux_size2_mem_9_ccff_tail,
         sb_mux_size2_mem_10_ccff_tail, sb_mux_size2_mem_11_ccff_tail,
         sb_mux_size2_mem_12_ccff_tail, sb_mux_size2_mem_13_ccff_tail,
         sb_mux_size2_mem_14_ccff_tail, sb_mux_size2_mem_15_ccff_tail,
         sb_mux_size2_mem_16_ccff_tail, sb_mux_size2_mem_17_ccff_tail,
         sb_mux_size2_mem_18_ccff_tail, sb_mux_size2_mem_19_ccff_tail,
         sb_mux_size2_mem_20_ccff_tail, sb_mux_size2_mem_21_ccff_tail,
         sb_mux_size2_mem_22_ccff_tail, sb_mux_size2_mem_23_ccff_tail,
         sb_mux_size2_mem_24_ccff_tail, sb_mux_size2_mem_25_ccff_tail,
         sb_mux_size2_mem_26_ccff_tail, sb_mux_size2_mem_27_ccff_tail,
         sb_mux_size2_mem_28_ccff_tail, mem_top_track_0_TSMC22ULP_CCFF_1_Q,
         mem_top_track_0_TSMC22ULP_CCFF_0_Q,
         mem_top_track_24_TSMC22ULP_CCFF_0_Q,
         mem_top_track_22_TSMC22ULP_CCFF_1_Q,
         mem_top_track_22_TSMC22ULP_CCFF_0_Q,
         mem_top_track_20_TSMC22ULP_CCFF_1_Q,
         mem_top_track_20_TSMC22ULP_CCFF_0_Q,
         mem_top_track_18_TSMC22ULP_CCFF_1_Q,
         mem_top_track_18_TSMC22ULP_CCFF_0_Q,
         mem_top_track_16_TSMC22ULP_CCFF_1_Q,
         mem_top_track_16_TSMC22ULP_CCFF_0_Q,
         mem_top_track_14_TSMC22ULP_CCFF_1_Q,
         mem_top_track_14_TSMC22ULP_CCFF_0_Q,
         mem_top_track_12_TSMC22ULP_CCFF_1_Q,
         mem_top_track_12_TSMC22ULP_CCFF_0_Q,
         mem_top_track_10_TSMC22ULP_CCFF_1_Q,
         mem_top_track_10_TSMC22ULP_CCFF_0_Q,
         mem_top_track_8_TSMC22ULP_CCFF_1_Q,
         mem_top_track_8_TSMC22ULP_CCFF_0_Q,
         mem_top_track_6_TSMC22ULP_CCFF_1_Q,
         mem_top_track_6_TSMC22ULP_CCFF_0_Q,
         mem_top_track_4_TSMC22ULP_CCFF_1_Q,
         mem_top_track_4_TSMC22ULP_CCFF_0_Q,
         mem_top_track_2_TSMC22ULP_CCFF_1_Q,
         mem_top_track_2_TSMC22ULP_CCFF_0_Q,
         mem_left_track_31_TSMC22ULP_CCFF_0_Q,
         mem_left_track_29_TSMC22ULP_CCFF_0_Q,
         mem_left_track_27_TSMC22ULP_CCFF_0_Q,
         mem_left_track_25_TSMC22ULP_CCFF_0_Q,
         mem_left_track_19_TSMC22ULP_CCFF_0_Q,
         mem_left_track_17_TSMC22ULP_CCFF_0_Q,
         mem_left_track_15_TSMC22ULP_CCFF_0_Q,
         mem_left_track_13_TSMC22ULP_CCFF_0_Q,
         mem_left_track_7_TSMC22ULP_CCFF_0_Q,
         mem_left_track_5_TSMC22ULP_CCFF_0_Q,
         mem_left_track_3_TSMC22ULP_CCFF_0_Q,
         mem_left_track_1_TSMC22ULP_CCFF_0_Q,
         mem_top_track_58_TSMC22ULP_CCFF_0_Q,
         mem_top_track_56_TSMC22ULP_CCFF_0_Q,
         mem_top_track_54_TSMC22ULP_CCFF_0_Q,
         mem_top_track_52_TSMC22ULP_CCFF_0_Q,
         mem_top_track_50_TSMC22ULP_CCFF_0_Q,
         mem_top_track_48_TSMC22ULP_CCFF_0_Q,
         mem_top_track_46_TSMC22ULP_CCFF_0_Q,
         mem_top_track_44_TSMC22ULP_CCFF_0_Q,
         mem_top_track_42_TSMC22ULP_CCFF_0_Q,
         mem_top_track_40_TSMC22ULP_CCFF_0_Q,
         mem_top_track_38_TSMC22ULP_CCFF_0_Q,
         mem_top_track_36_TSMC22ULP_CCFF_0_Q,
         mem_top_track_34_TSMC22ULP_CCFF_0_Q,
         mem_top_track_32_TSMC22ULP_CCFF_0_Q,
         mem_top_track_30_TSMC22ULP_CCFF_0_Q,
         mem_top_track_28_TSMC22ULP_CCFF_0_Q,
         mem_top_track_26_TSMC22ULP_CCFF_0_Q, eco_net, eco_net_0, eco_net_1_0,
         eco_net_2_0, eco_net_3_0, eco_net_4_0, eco_net_5_0, eco_net_6_0,
         eco_net_7_0, eco_net_8_0, eco_net_9_0, eco_net_10_0, eco_net_11_0,
         eco_net_12_0, eco_net_13_0, eco_net_14_0, eco_net_15_0, eco_net_16_0,
         eco_net_17_0, eco_net_18_0, eco_net_19_0, eco_net_20_0, eco_net_21_0,
         eco_net_22_0, eco_net_23_0, eco_net_24_0, eco_net_25_0, eco_net_26_0,
         eco_net_27_0, eco_net_28_0, eco_net_29_0, eco_net_30_0, eco_net_31_0,
         eco_net_32_0, eco_net_33_0, eco_net_34_0, eco_net_35_0, eco_net_36_0,
         eco_net_37_0, eco_net_38_0, eco_net_39_0, eco_net_40_0, eco_net_41_0,
         eco_net_42_0, eco_net_43_0, eco_net_44_0, eco_net_45_0, eco_net_46_0,
         eco_net_47_0, eco_net_48_0, eco_net_49_0, eco_net_50_0, eco_net_51_0,
         eco_net_52_0, eco_net_53_0, eco_net_54_0, eco_net_55_0, eco_net_56_0,
         eco_net_57_0, eco_net_58_0, eco_net_59_0, eco_net_60_0, eco_net_61_0,
         eco_net_62_0, eco_net_63_0, eco_net_64_0, eco_net_65_0, eco_net_66_0,
         eco_net_67_0, eco_net_68_0, eco_net_69_0, eco_net_70_0, eco_net_71_0,
         eco_net_72_0, eco_net_73_0, eco_net_74_0, eco_net_75_0, eco_net_76_0,
         eco_net_77_0, eco_net_78_0, eco_net_79_0, eco_net_80_0, eco_net_81_0,
         eco_net_82_0, eco_net_83_0, eco_net_84_0, eco_net_85_0, eco_net_86_0,
         eco_net_87_0, eco_net_88_0, eco_net_89_0, eco_net_90_0, eco_net_91_0,
         eco_net_92_0, eco_net_93_0, eco_net_94_0, eco_net_95_0, eco_net_96_0,
         eco_net_97_0, eco_net_98_0, eco_net_99_0, eco_net_100_0,
         eco_net_101_0, eco_net_102_0, eco_net_103_0, eco_net_104_0,
         eco_net_105_0, eco_net_106_0;

  DFCNQD1BWP30P140HVT mem_top_track_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_11_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_31_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_106_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        ccff_tail[0]) );
  DFCNQD1BWP30P140HVT mem_left_track_31_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_105_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_31_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_29_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_104_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_28_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_29_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_103_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_29_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_27_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_102_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_27_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_27_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_101_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_27_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_25_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_100_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_26_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_25_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_99_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_25_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_19_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_98_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_25_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_19_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_97_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_19_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_17_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_96_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_24_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_17_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_95_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_17_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_15_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_94_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_23_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_15_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_93_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_15_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_13_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_92_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_22_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_13_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_91_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_13_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_7_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_90_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_21_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_7_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_89_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_7_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_5_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_88_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_20_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_5_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_87_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_5_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_3_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_86_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_19_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_3_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_85_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_3_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_left_track_1_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_84_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_18_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_left_track_1_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_83_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_left_track_1_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_58_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_82_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_17_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_58_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_81_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_top_track_58_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_56_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_80_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_16_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_56_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_79_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_top_track_56_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_54_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_78_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_15_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_54_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_77_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_top_track_54_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_52_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_76_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        sb_mux_size2_mem_14_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_52_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_75_0), .CP(eco_net_1_0), .CDN(eco_net_5_0), .Q(
        mem_top_track_52_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_50_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_74_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_13_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_50_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_73_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_50_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_48_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_72_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_12_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_48_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_71_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_48_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_46_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_70_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_11_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_46_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_69_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_46_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_44_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_68_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_44_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_67_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_44_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_42_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_66_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_42_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_65_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_42_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_40_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_64_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_40_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_63_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_40_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_38_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_62_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_38_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_61_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_38_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_36_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_60_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_36_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_59_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_34_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_58_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_34_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_57_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_32_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_56_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_32_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_55_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_30_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_54_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_30_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_53_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_28_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_52_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_28_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_51_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_26_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_50_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_26_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_49_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_24_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_48_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size2_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_24_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_47_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_22_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_46_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        sb_mux_size4_mem_11_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_22_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_45_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_22_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_22_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_44_0), .CP(eco_net_0), .CDN(eco_net_4_0), .Q(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_20_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_43_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_20_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_42_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_20_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_20_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_41_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_18_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_40_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_18_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_39_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_18_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_18_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_38_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_16_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_37_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_16_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_36_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_16_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_16_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_35_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_14_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_34_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_14_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_33_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_14_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_14_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_32_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_12_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_31_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_12_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_30_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_12_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_12_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_29_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_10_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_28_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_10_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_27_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_10_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_10_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_26_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_8_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_25_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_8_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_24_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_8_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_8_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_23_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_6_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_22_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_21_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_6_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_20_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_4_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_19_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_18_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_4_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_17_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_2_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_16_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_15_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_2_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_14_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_0_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_13_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        sb_mux_size4_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_12_0), .CP(eco_net), .CDN(eco_net_3_0), .Q(
        mem_top_track_0_TSMC22ULP_CCFF_1_Q) );
  ND2D1BWP30P140HVT U193 ( .A1(config_enable[0]), .A2(
        mem_top_track_0_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[1]) );
  INVD1BWP30P140HVT U194 ( .I(mem_outb[1]), .ZN(mem_out[1]) );
  ND2D1BWP30P140HVT U195 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_0_ccff_tail), .ZN(mem_outb[2]) );
  INVD1BWP30P140HVT U196 ( .I(mem_outb[2]), .ZN(mem_out[2]) );
  ND2D1BWP30P140HVT U197 ( .A1(config_enable[0]), .A2(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[3]) );
  INVD1BWP30P140HVT U198 ( .I(mem_outb[3]), .ZN(mem_out[3]) );
  ND2D1BWP30P140HVT U199 ( .A1(config_enable[0]), .A2(
        mem_top_track_2_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[4]) );
  INVD1BWP30P140HVT U200 ( .I(mem_outb[4]), .ZN(mem_out[4]) );
  ND2D1BWP30P140HVT U201 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_1_ccff_tail), .ZN(mem_outb[5]) );
  INVD1BWP30P140HVT U202 ( .I(mem_outb[5]), .ZN(mem_out[5]) );
  ND2D1BWP30P140HVT U203 ( .A1(config_enable[0]), .A2(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[6]) );
  INVD1BWP30P140HVT U204 ( .I(mem_outb[6]), .ZN(mem_out[6]) );
  ND2D1BWP30P140HVT U205 ( .A1(config_enable[0]), .A2(
        mem_top_track_4_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[7]) );
  INVD1BWP30P140HVT U206 ( .I(mem_outb[7]), .ZN(mem_out[7]) );
  ND2D1BWP30P140HVT U207 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_2_ccff_tail), .ZN(mem_outb[8]) );
  INVD1BWP30P140HVT U208 ( .I(mem_outb[8]), .ZN(mem_out[8]) );
  ND2D1BWP30P140HVT U209 ( .A1(config_enable[0]), .A2(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[9]) );
  INVD1BWP30P140HVT U210 ( .I(mem_outb[9]), .ZN(mem_out[9]) );
  ND2D1BWP30P140HVT U211 ( .A1(config_enable[0]), .A2(
        mem_top_track_6_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[10]) );
  INVD1BWP30P140HVT U212 ( .I(mem_outb[10]), .ZN(mem_out[10]) );
  ND2D1BWP30P140HVT U213 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_3_ccff_tail), .ZN(mem_outb[11]) );
  INVD1BWP30P140HVT U214 ( .I(mem_outb[11]), .ZN(mem_out[11]) );
  ND2D1BWP30P140HVT U215 ( .A1(config_enable[0]), .A2(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[12]) );
  INVD1BWP30P140HVT U216 ( .I(mem_outb[12]), .ZN(mem_out[12]) );
  ND2D1BWP30P140HVT U217 ( .A1(config_enable[0]), .A2(
        mem_top_track_8_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[13]) );
  INVD1BWP30P140HVT U218 ( .I(mem_outb[13]), .ZN(mem_out[13]) );
  ND2D1BWP30P140HVT U219 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_4_ccff_tail), .ZN(mem_outb[14]) );
  INVD1BWP30P140HVT U220 ( .I(mem_outb[14]), .ZN(mem_out[14]) );
  ND2D1BWP30P140HVT U221 ( .A1(config_enable[0]), .A2(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[15]) );
  INVD1BWP30P140HVT U222 ( .I(mem_outb[15]), .ZN(mem_out[15]) );
  ND2D1BWP30P140HVT U223 ( .A1(config_enable[0]), .A2(
        mem_top_track_10_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[16]) );
  INVD1BWP30P140HVT U224 ( .I(mem_outb[16]), .ZN(mem_out[16]) );
  ND2D1BWP30P140HVT U225 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_5_ccff_tail), .ZN(mem_outb[17]) );
  INVD1BWP30P140HVT U226 ( .I(mem_outb[17]), .ZN(mem_out[17]) );
  ND2D1BWP30P140HVT U227 ( .A1(config_enable[0]), .A2(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[18]) );
  INVD1BWP30P140HVT U228 ( .I(mem_outb[18]), .ZN(mem_out[18]) );
  ND2D1BWP30P140HVT U229 ( .A1(config_enable[0]), .A2(
        mem_top_track_12_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[19]) );
  INVD1BWP30P140HVT U230 ( .I(mem_outb[19]), .ZN(mem_out[19]) );
  ND2D1BWP30P140HVT U231 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_6_ccff_tail), .ZN(mem_outb[20]) );
  INVD1BWP30P140HVT U232 ( .I(mem_outb[20]), .ZN(mem_out[20]) );
  ND2D1BWP30P140HVT U233 ( .A1(config_enable[0]), .A2(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[21]) );
  INVD1BWP30P140HVT U234 ( .I(mem_outb[21]), .ZN(mem_out[21]) );
  ND2D1BWP30P140HVT U235 ( .A1(config_enable[0]), .A2(
        mem_top_track_14_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[22]) );
  INVD1BWP30P140HVT U236 ( .I(mem_outb[22]), .ZN(mem_out[22]) );
  ND2D1BWP30P140HVT U237 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_7_ccff_tail), .ZN(mem_outb[23]) );
  INVD1BWP30P140HVT U238 ( .I(mem_outb[23]), .ZN(mem_out[23]) );
  ND2D1BWP30P140HVT U239 ( .A1(config_enable[0]), .A2(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[24]) );
  INVD1BWP30P140HVT U240 ( .I(mem_outb[24]), .ZN(mem_out[24]) );
  ND2D1BWP30P140HVT U241 ( .A1(config_enable[0]), .A2(
        mem_top_track_16_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[25]) );
  INVD1BWP30P140HVT U242 ( .I(mem_outb[25]), .ZN(mem_out[25]) );
  ND2D1BWP30P140HVT U243 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_8_ccff_tail), .ZN(mem_outb[26]) );
  INVD1BWP30P140HVT U244 ( .I(mem_outb[26]), .ZN(mem_out[26]) );
  ND2D1BWP30P140HVT U245 ( .A1(config_enable[0]), .A2(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[27]) );
  INVD1BWP30P140HVT U246 ( .I(mem_outb[27]), .ZN(mem_out[27]) );
  ND2D1BWP30P140HVT U247 ( .A1(config_enable[0]), .A2(
        mem_top_track_18_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[28]) );
  INVD1BWP30P140HVT U248 ( .I(mem_outb[28]), .ZN(mem_out[28]) );
  ND2D1BWP30P140HVT U249 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_9_ccff_tail), .ZN(mem_outb[29]) );
  INVD1BWP30P140HVT U250 ( .I(mem_outb[29]), .ZN(mem_out[29]) );
  ND2D1BWP30P140HVT U251 ( .A1(config_enable[0]), .A2(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[30]) );
  INVD1BWP30P140HVT U252 ( .I(mem_outb[30]), .ZN(mem_out[30]) );
  ND2D1BWP30P140HVT U253 ( .A1(config_enable[0]), .A2(
        mem_top_track_20_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[31]) );
  INVD1BWP30P140HVT U254 ( .I(mem_outb[31]), .ZN(mem_out[31]) );
  ND2D1BWP30P140HVT U255 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_10_ccff_tail), .ZN(mem_outb[32]) );
  INVD1BWP30P140HVT U256 ( .I(mem_outb[32]), .ZN(mem_out[32]) );
  ND2D1BWP30P140HVT U257 ( .A1(config_enable[0]), .A2(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[33]) );
  INVD1BWP30P140HVT U258 ( .I(mem_outb[33]), .ZN(mem_out[33]) );
  ND2D1BWP30P140HVT U259 ( .A1(config_enable[0]), .A2(
        mem_top_track_22_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[34]) );
  INVD1BWP30P140HVT U260 ( .I(mem_outb[34]), .ZN(mem_out[34]) );
  ND2D1BWP30P140HVT U261 ( .A1(config_enable[0]), .A2(
        sb_mux_size4_mem_11_ccff_tail), .ZN(mem_outb[35]) );
  INVD1BWP30P140HVT U262 ( .I(mem_outb[35]), .ZN(mem_out[35]) );
  ND2D1BWP30P140HVT U263 ( .A1(config_enable[0]), .A2(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[36]) );
  INVD1BWP30P140HVT U264 ( .I(mem_outb[36]), .ZN(mem_out[36]) );
  ND2D1BWP30P140HVT U265 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_0_ccff_tail), .ZN(mem_outb[37]) );
  INVD1BWP30P140HVT U266 ( .I(mem_outb[37]), .ZN(mem_out[37]) );
  ND2D1BWP30P140HVT U267 ( .A1(config_enable[0]), .A2(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[38]) );
  INVD1BWP30P140HVT U268 ( .I(mem_outb[38]), .ZN(mem_out[38]) );
  ND2D1BWP30P140HVT U269 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_1_ccff_tail), .ZN(mem_outb[39]) );
  INVD1BWP30P140HVT U270 ( .I(mem_outb[39]), .ZN(mem_out[39]) );
  ND2D1BWP30P140HVT U271 ( .A1(config_enable[0]), .A2(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[40]) );
  INVD1BWP30P140HVT U272 ( .I(mem_outb[40]), .ZN(mem_out[40]) );
  ND2D1BWP30P140HVT U273 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_2_ccff_tail), .ZN(mem_outb[41]) );
  INVD1BWP30P140HVT U274 ( .I(mem_outb[41]), .ZN(mem_out[41]) );
  ND2D1BWP30P140HVT U275 ( .A1(config_enable[0]), .A2(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[42]) );
  INVD1BWP30P140HVT U276 ( .I(mem_outb[42]), .ZN(mem_out[42]) );
  ND2D1BWP30P140HVT U277 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_3_ccff_tail), .ZN(mem_outb[43]) );
  INVD1BWP30P140HVT U278 ( .I(mem_outb[43]), .ZN(mem_out[43]) );
  ND2D1BWP30P140HVT U279 ( .A1(config_enable[0]), .A2(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[44]) );
  INVD1BWP30P140HVT U280 ( .I(mem_outb[44]), .ZN(mem_out[44]) );
  ND2D1BWP30P140HVT U281 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_4_ccff_tail), .ZN(mem_outb[45]) );
  INVD1BWP30P140HVT U282 ( .I(mem_outb[45]), .ZN(mem_out[45]) );
  ND2D1BWP30P140HVT U283 ( .A1(config_enable[0]), .A2(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[46]) );
  INVD1BWP30P140HVT U284 ( .I(mem_outb[46]), .ZN(mem_out[46]) );
  ND2D1BWP30P140HVT U285 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_5_ccff_tail), .ZN(mem_outb[47]) );
  INVD1BWP30P140HVT U286 ( .I(mem_outb[47]), .ZN(mem_out[47]) );
  ND2D1BWP30P140HVT U287 ( .A1(config_enable[0]), .A2(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[48]) );
  INVD1BWP30P140HVT U288 ( .I(mem_outb[48]), .ZN(mem_out[48]) );
  ND2D1BWP30P140HVT U289 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_6_ccff_tail), .ZN(mem_outb[49]) );
  INVD1BWP30P140HVT U290 ( .I(mem_outb[49]), .ZN(mem_out[49]) );
  ND2D1BWP30P140HVT U291 ( .A1(config_enable[0]), .A2(
        mem_top_track_38_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[50]) );
  INVD1BWP30P140HVT U292 ( .I(mem_outb[50]), .ZN(mem_out[50]) );
  ND2D1BWP30P140HVT U293 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_7_ccff_tail), .ZN(mem_outb[51]) );
  INVD1BWP30P140HVT U294 ( .I(mem_outb[51]), .ZN(mem_out[51]) );
  ND2D1BWP30P140HVT U295 ( .A1(config_enable[0]), .A2(
        mem_top_track_40_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[52]) );
  INVD1BWP30P140HVT U296 ( .I(mem_outb[52]), .ZN(mem_out[52]) );
  ND2D1BWP30P140HVT U297 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_8_ccff_tail), .ZN(mem_outb[53]) );
  INVD1BWP30P140HVT U298 ( .I(mem_outb[53]), .ZN(mem_out[53]) );
  ND2D1BWP30P140HVT U299 ( .A1(config_enable[0]), .A2(
        mem_top_track_42_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[54]) );
  INVD1BWP30P140HVT U300 ( .I(mem_outb[54]), .ZN(mem_out[54]) );
  ND2D1BWP30P140HVT U301 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_9_ccff_tail), .ZN(mem_outb[55]) );
  INVD1BWP30P140HVT U302 ( .I(mem_outb[55]), .ZN(mem_out[55]) );
  ND2D1BWP30P140HVT U303 ( .A1(config_enable[0]), .A2(
        mem_top_track_44_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[56]) );
  INVD1BWP30P140HVT U304 ( .I(mem_outb[56]), .ZN(mem_out[56]) );
  ND2D1BWP30P140HVT U305 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_10_ccff_tail), .ZN(mem_outb[57]) );
  INVD1BWP30P140HVT U306 ( .I(mem_outb[57]), .ZN(mem_out[57]) );
  ND2D1BWP30P140HVT U307 ( .A1(config_enable[0]), .A2(
        mem_top_track_46_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[58]) );
  INVD1BWP30P140HVT U308 ( .I(mem_outb[58]), .ZN(mem_out[58]) );
  ND2D1BWP30P140HVT U309 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_11_ccff_tail), .ZN(mem_outb[59]) );
  INVD1BWP30P140HVT U310 ( .I(mem_outb[59]), .ZN(mem_out[59]) );
  ND2D1BWP30P140HVT U311 ( .A1(config_enable[0]), .A2(
        mem_top_track_48_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[60]) );
  INVD1BWP30P140HVT U312 ( .I(mem_outb[60]), .ZN(mem_out[60]) );
  ND2D1BWP30P140HVT U313 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_12_ccff_tail), .ZN(mem_outb[61]) );
  INVD1BWP30P140HVT U314 ( .I(mem_outb[61]), .ZN(mem_out[61]) );
  ND2D1BWP30P140HVT U315 ( .A1(config_enable[0]), .A2(
        mem_top_track_50_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[62]) );
  INVD1BWP30P140HVT U316 ( .I(mem_outb[62]), .ZN(mem_out[62]) );
  ND2D1BWP30P140HVT U317 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_13_ccff_tail), .ZN(mem_outb[63]) );
  INVD1BWP30P140HVT U318 ( .I(mem_outb[63]), .ZN(mem_out[63]) );
  ND2D1BWP30P140HVT U319 ( .A1(config_enable[0]), .A2(
        mem_top_track_52_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[64]) );
  INVD1BWP30P140HVT U320 ( .I(mem_outb[64]), .ZN(mem_out[64]) );
  ND2D1BWP30P140HVT U321 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_14_ccff_tail), .ZN(mem_outb[65]) );
  INVD1BWP30P140HVT U322 ( .I(mem_outb[65]), .ZN(mem_out[65]) );
  ND2D1BWP30P140HVT U323 ( .A1(config_enable[0]), .A2(
        mem_top_track_54_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[66]) );
  INVD1BWP30P140HVT U324 ( .I(mem_outb[66]), .ZN(mem_out[66]) );
  ND2D1BWP30P140HVT U325 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_15_ccff_tail), .ZN(mem_outb[67]) );
  INVD1BWP30P140HVT U326 ( .I(mem_outb[67]), .ZN(mem_out[67]) );
  ND2D1BWP30P140HVT U327 ( .A1(config_enable[0]), .A2(
        mem_top_track_56_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[68]) );
  INVD1BWP30P140HVT U328 ( .I(mem_outb[68]), .ZN(mem_out[68]) );
  ND2D1BWP30P140HVT U329 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_16_ccff_tail), .ZN(mem_outb[69]) );
  INVD1BWP30P140HVT U330 ( .I(mem_outb[69]), .ZN(mem_out[69]) );
  ND2D1BWP30P140HVT U331 ( .A1(config_enable[0]), .A2(
        mem_top_track_58_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[70]) );
  INVD1BWP30P140HVT U332 ( .I(mem_outb[70]), .ZN(mem_out[70]) );
  ND2D1BWP30P140HVT U333 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_17_ccff_tail), .ZN(mem_outb[71]) );
  INVD1BWP30P140HVT U334 ( .I(mem_outb[71]), .ZN(mem_out[71]) );
  ND2D1BWP30P140HVT U335 ( .A1(config_enable[0]), .A2(
        mem_left_track_1_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[72]) );
  INVD1BWP30P140HVT U336 ( .I(mem_outb[72]), .ZN(mem_out[72]) );
  ND2D1BWP30P140HVT U337 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_18_ccff_tail), .ZN(mem_outb[73]) );
  INVD1BWP30P140HVT U338 ( .I(mem_outb[73]), .ZN(mem_out[73]) );
  ND2D1BWP30P140HVT U339 ( .A1(config_enable[0]), .A2(
        mem_left_track_3_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[74]) );
  INVD1BWP30P140HVT U340 ( .I(mem_outb[74]), .ZN(mem_out[74]) );
  ND2D1BWP30P140HVT U341 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_19_ccff_tail), .ZN(mem_outb[75]) );
  INVD1BWP30P140HVT U342 ( .I(mem_outb[75]), .ZN(mem_out[75]) );
  ND2D1BWP30P140HVT U343 ( .A1(config_enable[0]), .A2(
        mem_left_track_5_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[76]) );
  INVD1BWP30P140HVT U344 ( .I(mem_outb[76]), .ZN(mem_out[76]) );
  ND2D1BWP30P140HVT U345 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_20_ccff_tail), .ZN(mem_outb[77]) );
  INVD1BWP30P140HVT U346 ( .I(mem_outb[77]), .ZN(mem_out[77]) );
  ND2D1BWP30P140HVT U347 ( .A1(config_enable[0]), .A2(
        mem_left_track_7_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[78]) );
  INVD1BWP30P140HVT U348 ( .I(mem_outb[78]), .ZN(mem_out[78]) );
  ND2D1BWP30P140HVT U349 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_21_ccff_tail), .ZN(mem_outb[79]) );
  INVD1BWP30P140HVT U350 ( .I(mem_outb[79]), .ZN(mem_out[79]) );
  ND2D1BWP30P140HVT U351 ( .A1(config_enable[0]), .A2(
        mem_left_track_13_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[80]) );
  INVD1BWP30P140HVT U352 ( .I(mem_outb[80]), .ZN(mem_out[80]) );
  ND2D1BWP30P140HVT U353 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_22_ccff_tail), .ZN(mem_outb[81]) );
  INVD1BWP30P140HVT U354 ( .I(mem_outb[81]), .ZN(mem_out[81]) );
  ND2D1BWP30P140HVT U355 ( .A1(config_enable[0]), .A2(
        mem_left_track_15_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[82]) );
  INVD1BWP30P140HVT U356 ( .I(mem_outb[82]), .ZN(mem_out[82]) );
  ND2D1BWP30P140HVT U357 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_23_ccff_tail), .ZN(mem_outb[83]) );
  INVD1BWP30P140HVT U358 ( .I(mem_outb[83]), .ZN(mem_out[83]) );
  ND2D1BWP30P140HVT U359 ( .A1(config_enable[0]), .A2(
        mem_left_track_17_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[84]) );
  INVD1BWP30P140HVT U360 ( .I(mem_outb[84]), .ZN(mem_out[84]) );
  ND2D1BWP30P140HVT U361 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_24_ccff_tail), .ZN(mem_outb[85]) );
  INVD1BWP30P140HVT U362 ( .I(mem_outb[85]), .ZN(mem_out[85]) );
  ND2D1BWP30P140HVT U363 ( .A1(config_enable[0]), .A2(
        mem_left_track_19_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[86]) );
  INVD1BWP30P140HVT U364 ( .I(mem_outb[86]), .ZN(mem_out[86]) );
  ND2D1BWP30P140HVT U365 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_25_ccff_tail), .ZN(mem_outb[87]) );
  INVD1BWP30P140HVT U366 ( .I(mem_outb[87]), .ZN(mem_out[87]) );
  ND2D1BWP30P140HVT U367 ( .A1(config_enable[0]), .A2(
        mem_left_track_25_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[88]) );
  INVD1BWP30P140HVT U368 ( .I(mem_outb[88]), .ZN(mem_out[88]) );
  ND2D1BWP30P140HVT U369 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_26_ccff_tail), .ZN(mem_outb[89]) );
  INVD1BWP30P140HVT U370 ( .I(mem_outb[89]), .ZN(mem_out[89]) );
  ND2D1BWP30P140HVT U371 ( .A1(config_enable[0]), .A2(
        mem_left_track_27_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[90]) );
  INVD1BWP30P140HVT U372 ( .I(mem_outb[90]), .ZN(mem_out[90]) );
  ND2D1BWP30P140HVT U373 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_27_ccff_tail), .ZN(mem_outb[91]) );
  INVD1BWP30P140HVT U374 ( .I(mem_outb[91]), .ZN(mem_out[91]) );
  ND2D1BWP30P140HVT U375 ( .A1(config_enable[0]), .A2(
        mem_left_track_29_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[92]) );
  INVD1BWP30P140HVT U376 ( .I(mem_outb[92]), .ZN(mem_out[92]) );
  ND2D1BWP30P140HVT U377 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_28_ccff_tail), .ZN(mem_outb[93]) );
  INVD1BWP30P140HVT U378 ( .I(mem_outb[93]), .ZN(mem_out[93]) );
  ND2D1BWP30P140HVT U379 ( .A1(config_enable[0]), .A2(
        mem_left_track_31_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[94]) );
  INVD1BWP30P140HVT U380 ( .I(mem_outb[94]), .ZN(mem_out[94]) );
  ND2D1BWP30P140HVT U381 ( .A1(config_enable[0]), .A2(ccff_tail[0]), .ZN(
        mem_outb[95]) );
  INVD1BWP30P140HVT U382 ( .I(mem_outb[95]), .ZN(mem_out[95]) );
  ND2D1BWP30P140HVT U383 ( .A1(config_enable[0]), .A2(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[0]) );
  INVD1BWP30P140HVT U384 ( .I(mem_outb[0]), .ZN(mem_out[0]) );
  BUFFD1BWP30P140HVT mem_top_track_20_cp_buf2 ( .I(eco_net_2_0), .Z(eco_net)
         );
  BUFFD1BWP30P140HVT mem_top_track_50_cp_buf2 ( .I(eco_net_2_0), .Z(eco_net_0)
         );
  BUFFD1BWP30P140HVT mem_left_track_31_cp_buf2 ( .I(eco_net_2_0), .Z(
        eco_net_1_0) );
  BUFFD1BWP30P140HVT mem_left_track_31_cp_buf1 ( .I(prog_clk[0]), .Z(
        eco_net_2_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_cdn_buf2 ( .I(eco_net_6_0), .Z(
        eco_net_3_0) );
  BUFFD1BWP30P140HVT mem_top_track_50_cdn_buf2 ( .I(eco_net_6_0), .Z(
        eco_net_4_0) );
  BUFFD1BWP30P140HVT mem_left_track_31_cdn_buf2 ( .I(eco_net_6_0), .Z(
        eco_net_5_0) );
  BUFFD1BWP30P140HVT mem_left_track_31_cdn_buf1 ( .I(prog_reset[0]), .Z(
        eco_net_6_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del1 ( .I(ccff_head[0]), .Z(eco_net_7_0)
         );
  BUFFD1BWP30P140HVT mem_top_track_0_del2 ( .I(eco_net_7_0), .Z(eco_net_8_0)
         );
  BUFFD1BWP30P140HVT mem_top_track_22_del2 ( .I(sb_mux_size4_mem_10_ccff_tail), 
        .Z(eco_net_9_0) );
  BUFFD1BWP30P140HVT mem_top_track_52_del2 ( .I(sb_mux_size2_mem_13_ccff_tail), 
        .Z(eco_net_10_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del3_0 ( .I(eco_net_8_0), .Z(eco_net_11_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del3_1 ( .I(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_12_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del3_2 ( .I(
        mem_top_track_0_TSMC22ULP_CCFF_1_Q), .Z(eco_net_13_0) );
  BUFFD1BWP30P140HVT mem_top_track_2_del3_0 ( .I(sb_mux_size4_mem_0_ccff_tail), 
        .Z(eco_net_14_0) );
  BUFFD1BWP30P140HVT mem_top_track_2_del3_1 ( .I(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_15_0) );
  BUFFD1BWP30P140HVT mem_top_track_2_del3_2 ( .I(
        mem_top_track_2_TSMC22ULP_CCFF_1_Q), .Z(eco_net_16_0) );
  BUFFD1BWP30P140HVT mem_top_track_4_del3_0 ( .I(sb_mux_size4_mem_1_ccff_tail), 
        .Z(eco_net_17_0) );
  BUFFD1BWP30P140HVT mem_top_track_4_del3_1 ( .I(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_18_0) );
  BUFFD1BWP30P140HVT mem_top_track_4_del3_2 ( .I(
        mem_top_track_4_TSMC22ULP_CCFF_1_Q), .Z(eco_net_19_0) );
  BUFFD1BWP30P140HVT mem_top_track_6_del3_0 ( .I(sb_mux_size4_mem_2_ccff_tail), 
        .Z(eco_net_20_0) );
  BUFFD1BWP30P140HVT mem_top_track_6_del3_1 ( .I(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_21_0) );
  BUFFD1BWP30P140HVT mem_top_track_6_del3_2 ( .I(
        mem_top_track_6_TSMC22ULP_CCFF_1_Q), .Z(eco_net_22_0) );
  BUFFD1BWP30P140HVT mem_top_track_8_del3_0 ( .I(sb_mux_size4_mem_3_ccff_tail), 
        .Z(eco_net_23_0) );
  BUFFD1BWP30P140HVT mem_top_track_8_del3_1 ( .I(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q), .Z(eco_net_24_0) );
  BUFFD1BWP30P140HVT mem_top_track_8_del3_2 ( .I(
        mem_top_track_8_TSMC22ULP_CCFF_1_Q), .Z(eco_net_25_0) );
  BUFFD1BWP30P140HVT mem_top_track_10_del3_0 ( .I(sb_mux_size4_mem_4_ccff_tail), .Z(eco_net_26_0) );
  BUFFD1BWP30P140HVT mem_top_track_10_del3_1 ( .I(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q), .Z(eco_net_27_0) );
  BUFFD1BWP30P140HVT mem_top_track_10_del3_2 ( .I(
        mem_top_track_10_TSMC22ULP_CCFF_1_Q), .Z(eco_net_28_0) );
  BUFFD1BWP30P140HVT mem_top_track_12_del3_0 ( .I(sb_mux_size4_mem_5_ccff_tail), .Z(eco_net_29_0) );
  BUFFD1BWP30P140HVT mem_top_track_12_del3_1 ( .I(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q), .Z(eco_net_30_0) );
  BUFFD1BWP30P140HVT mem_top_track_12_del3_2 ( .I(
        mem_top_track_12_TSMC22ULP_CCFF_1_Q), .Z(eco_net_31_0) );
  BUFFD1BWP30P140HVT mem_top_track_14_del3_0 ( .I(sb_mux_size4_mem_6_ccff_tail), .Z(eco_net_32_0) );
  BUFFD1BWP30P140HVT mem_top_track_14_del3_1 ( .I(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q), .Z(eco_net_33_0) );
  BUFFD1BWP30P140HVT mem_top_track_14_del3_2 ( .I(
        mem_top_track_14_TSMC22ULP_CCFF_1_Q), .Z(eco_net_34_0) );
  BUFFD1BWP30P140HVT mem_top_track_16_del3_0 ( .I(sb_mux_size4_mem_7_ccff_tail), .Z(eco_net_35_0) );
  BUFFD1BWP30P140HVT mem_top_track_16_del3_1 ( .I(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q), .Z(eco_net_36_0) );
  BUFFD1BWP30P140HVT mem_top_track_16_del3_2 ( .I(
        mem_top_track_16_TSMC22ULP_CCFF_1_Q), .Z(eco_net_37_0) );
  BUFFD1BWP30P140HVT mem_top_track_18_del3_0 ( .I(sb_mux_size4_mem_8_ccff_tail), .Z(eco_net_38_0) );
  BUFFD1BWP30P140HVT mem_top_track_18_del3_1 ( .I(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q), .Z(eco_net_39_0) );
  BUFFD1BWP30P140HVT mem_top_track_18_del3_2 ( .I(
        mem_top_track_18_TSMC22ULP_CCFF_1_Q), .Z(eco_net_40_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_del3_0 ( .I(sb_mux_size4_mem_9_ccff_tail), .Z(eco_net_41_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_del3_1 ( .I(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q), .Z(eco_net_42_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_del3_2 ( .I(
        mem_top_track_20_TSMC22ULP_CCFF_1_Q), .Z(eco_net_43_0) );
  BUFFD1BWP30P140HVT mem_top_track_22_del3_0 ( .I(eco_net_9_0), .Z(
        eco_net_44_0) );
  BUFFD1BWP30P140HVT mem_top_track_22_del3_1 ( .I(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q), .Z(eco_net_45_0) );
  BUFFD1BWP30P140HVT mem_top_track_22_del3_2 ( .I(
        mem_top_track_22_TSMC22ULP_CCFF_1_Q), .Z(eco_net_46_0) );
  BUFFD1BWP30P140HVT mem_top_track_24_del3_0 ( .I(
        sb_mux_size4_mem_11_ccff_tail), .Z(eco_net_47_0) );
  BUFFD1BWP30P140HVT mem_top_track_24_del3_1 ( .I(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q), .Z(eco_net_48_0) );
  BUFFD1BWP30P140HVT mem_top_track_26_del3_0 ( .I(sb_mux_size2_mem_0_ccff_tail), .Z(eco_net_49_0) );
  BUFFD1BWP30P140HVT mem_top_track_26_del3_1 ( .I(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q), .Z(eco_net_50_0) );
  BUFFD1BWP30P140HVT mem_top_track_28_del3_0 ( .I(sb_mux_size2_mem_1_ccff_tail), .Z(eco_net_51_0) );
  BUFFD1BWP30P140HVT mem_top_track_28_del3_1 ( .I(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q), .Z(eco_net_52_0) );
  BUFFD1BWP30P140HVT mem_top_track_30_del3_0 ( .I(sb_mux_size2_mem_2_ccff_tail), .Z(eco_net_53_0) );
  BUFFD1BWP30P140HVT mem_top_track_30_del3_1 ( .I(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q), .Z(eco_net_54_0) );
  BUFFD1BWP30P140HVT mem_top_track_32_del3_0 ( .I(sb_mux_size2_mem_3_ccff_tail), .Z(eco_net_55_0) );
  BUFFD1BWP30P140HVT mem_top_track_32_del3_1 ( .I(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q), .Z(eco_net_56_0) );
  BUFFD1BWP30P140HVT mem_top_track_34_del3_0 ( .I(sb_mux_size2_mem_4_ccff_tail), .Z(eco_net_57_0) );
  BUFFD1BWP30P140HVT mem_top_track_34_del3_1 ( .I(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q), .Z(eco_net_58_0) );
  BUFFD1BWP30P140HVT mem_top_track_36_del3_0 ( .I(sb_mux_size2_mem_5_ccff_tail), .Z(eco_net_59_0) );
  BUFFD1BWP30P140HVT mem_top_track_36_del3_1 ( .I(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q), .Z(eco_net_60_0) );
  BUFFD1BWP30P140HVT mem_top_track_38_del3_0 ( .I(sb_mux_size2_mem_6_ccff_tail), .Z(eco_net_61_0) );
  BUFFD1BWP30P140HVT mem_top_track_38_del3_1 ( .I(
        mem_top_track_38_TSMC22ULP_CCFF_0_Q), .Z(eco_net_62_0) );
  BUFFD1BWP30P140HVT mem_top_track_40_del3_0 ( .I(sb_mux_size2_mem_7_ccff_tail), .Z(eco_net_63_0) );
  BUFFD1BWP30P140HVT mem_top_track_40_del3_1 ( .I(
        mem_top_track_40_TSMC22ULP_CCFF_0_Q), .Z(eco_net_64_0) );
  BUFFD1BWP30P140HVT mem_top_track_42_del3_0 ( .I(sb_mux_size2_mem_8_ccff_tail), .Z(eco_net_65_0) );
  BUFFD1BWP30P140HVT mem_top_track_42_del3_1 ( .I(
        mem_top_track_42_TSMC22ULP_CCFF_0_Q), .Z(eco_net_66_0) );
  BUFFD1BWP30P140HVT mem_top_track_44_del3_0 ( .I(sb_mux_size2_mem_9_ccff_tail), .Z(eco_net_67_0) );
  BUFFD1BWP30P140HVT mem_top_track_44_del3_1 ( .I(
        mem_top_track_44_TSMC22ULP_CCFF_0_Q), .Z(eco_net_68_0) );
  BUFFD1BWP30P140HVT mem_top_track_46_del3_0 ( .I(
        sb_mux_size2_mem_10_ccff_tail), .Z(eco_net_69_0) );
  BUFFD1BWP30P140HVT mem_top_track_46_del3_1 ( .I(
        mem_top_track_46_TSMC22ULP_CCFF_0_Q), .Z(eco_net_70_0) );
  BUFFD1BWP30P140HVT mem_top_track_48_del3_0 ( .I(
        sb_mux_size2_mem_11_ccff_tail), .Z(eco_net_71_0) );
  BUFFD1BWP30P140HVT mem_top_track_48_del3_1 ( .I(
        mem_top_track_48_TSMC22ULP_CCFF_0_Q), .Z(eco_net_72_0) );
  BUFFD1BWP30P140HVT mem_top_track_50_del3_0 ( .I(
        sb_mux_size2_mem_12_ccff_tail), .Z(eco_net_73_0) );
  BUFFD1BWP30P140HVT mem_top_track_50_del3_1 ( .I(
        mem_top_track_50_TSMC22ULP_CCFF_0_Q), .Z(eco_net_74_0) );
  BUFFD1BWP30P140HVT mem_top_track_52_del3_0 ( .I(eco_net_10_0), .Z(
        eco_net_75_0) );
  BUFFD1BWP30P140HVT mem_top_track_52_del3_1 ( .I(
        mem_top_track_52_TSMC22ULP_CCFF_0_Q), .Z(eco_net_76_0) );
  BUFFD1BWP30P140HVT mem_top_track_54_del3_0 ( .I(
        sb_mux_size2_mem_14_ccff_tail), .Z(eco_net_77_0) );
  BUFFD1BWP30P140HVT mem_top_track_54_del3_1 ( .I(
        mem_top_track_54_TSMC22ULP_CCFF_0_Q), .Z(eco_net_78_0) );
  BUFFD1BWP30P140HVT mem_top_track_56_del3_0 ( .I(
        sb_mux_size2_mem_15_ccff_tail), .Z(eco_net_79_0) );
  BUFFD1BWP30P140HVT mem_top_track_56_del3_1 ( .I(
        mem_top_track_56_TSMC22ULP_CCFF_0_Q), .Z(eco_net_80_0) );
  BUFFD1BWP30P140HVT mem_top_track_58_del3_0 ( .I(
        sb_mux_size2_mem_16_ccff_tail), .Z(eco_net_81_0) );
  BUFFD1BWP30P140HVT mem_top_track_58_del3_1 ( .I(
        mem_top_track_58_TSMC22ULP_CCFF_0_Q), .Z(eco_net_82_0) );
  BUFFD1BWP30P140HVT mem_left_track_1_del3_0 ( .I(
        sb_mux_size2_mem_17_ccff_tail), .Z(eco_net_83_0) );
  BUFFD1BWP30P140HVT mem_left_track_1_del3_1 ( .I(
        mem_left_track_1_TSMC22ULP_CCFF_0_Q), .Z(eco_net_84_0) );
  BUFFD1BWP30P140HVT mem_left_track_3_del3_0 ( .I(
        sb_mux_size2_mem_18_ccff_tail), .Z(eco_net_85_0) );
  BUFFD1BWP30P140HVT mem_left_track_3_del3_1 ( .I(
        mem_left_track_3_TSMC22ULP_CCFF_0_Q), .Z(eco_net_86_0) );
  BUFFD1BWP30P140HVT mem_left_track_5_del3_0 ( .I(
        sb_mux_size2_mem_19_ccff_tail), .Z(eco_net_87_0) );
  BUFFD1BWP30P140HVT mem_left_track_5_del3_1 ( .I(
        mem_left_track_5_TSMC22ULP_CCFF_0_Q), .Z(eco_net_88_0) );
  BUFFD1BWP30P140HVT mem_left_track_7_del3_0 ( .I(
        sb_mux_size2_mem_20_ccff_tail), .Z(eco_net_89_0) );
  BUFFD1BWP30P140HVT mem_left_track_7_del3_1 ( .I(
        mem_left_track_7_TSMC22ULP_CCFF_0_Q), .Z(eco_net_90_0) );
  BUFFD1BWP30P140HVT mem_left_track_13_del3_0 ( .I(
        sb_mux_size2_mem_21_ccff_tail), .Z(eco_net_91_0) );
  BUFFD1BWP30P140HVT mem_left_track_13_del3_1 ( .I(
        mem_left_track_13_TSMC22ULP_CCFF_0_Q), .Z(eco_net_92_0) );
  BUFFD1BWP30P140HVT mem_left_track_15_del3_0 ( .I(
        sb_mux_size2_mem_22_ccff_tail), .Z(eco_net_93_0) );
  BUFFD1BWP30P140HVT mem_left_track_15_del3_1 ( .I(
        mem_left_track_15_TSMC22ULP_CCFF_0_Q), .Z(eco_net_94_0) );
  BUFFD1BWP30P140HVT mem_left_track_17_del3_0 ( .I(
        sb_mux_size2_mem_23_ccff_tail), .Z(eco_net_95_0) );
  BUFFD1BWP30P140HVT mem_left_track_17_del3_1 ( .I(
        mem_left_track_17_TSMC22ULP_CCFF_0_Q), .Z(eco_net_96_0) );
  BUFFD1BWP30P140HVT mem_left_track_19_del3_0 ( .I(
        sb_mux_size2_mem_24_ccff_tail), .Z(eco_net_97_0) );
  BUFFD1BWP30P140HVT mem_left_track_19_del3_1 ( .I(
        mem_left_track_19_TSMC22ULP_CCFF_0_Q), .Z(eco_net_98_0) );
  BUFFD1BWP30P140HVT mem_left_track_25_del3_0 ( .I(
        sb_mux_size2_mem_25_ccff_tail), .Z(eco_net_99_0) );
  BUFFD1BWP30P140HVT mem_left_track_25_del3_1 ( .I(
        mem_left_track_25_TSMC22ULP_CCFF_0_Q), .Z(eco_net_100_0) );
  BUFFD1BWP30P140HVT mem_left_track_27_del3_0 ( .I(
        sb_mux_size2_mem_26_ccff_tail), .Z(eco_net_101_0) );
  BUFFD1BWP30P140HVT mem_left_track_27_del3_1 ( .I(
        mem_left_track_27_TSMC22ULP_CCFF_0_Q), .Z(eco_net_102_0) );
  BUFFD1BWP30P140HVT mem_left_track_29_del3_0 ( .I(
        sb_mux_size2_mem_27_ccff_tail), .Z(eco_net_103_0) );
  BUFFD1BWP30P140HVT mem_left_track_29_del3_1 ( .I(
        mem_left_track_29_TSMC22ULP_CCFF_0_Q), .Z(eco_net_104_0) );
  BUFFD1BWP30P140HVT mem_left_track_31_del3_0 ( .I(
        sb_mux_size2_mem_28_ccff_tail), .Z(eco_net_105_0) );
  BUFFD1BWP30P140HVT mem_left_track_31_del3_1 ( .I(
        mem_left_track_31_TSMC22ULP_CCFF_0_Q), .Z(eco_net_106_0) );
endmodule


module sb_6_ ( config_enable, prog_reset, prog_clk, chany_top_in, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_, 
        top_right_grid_left_width_0_height_0_subtile_0__pin_a2f_o_0_, 
        top_right_grid_left_width_0_height_0_subtile_1__pin_a2f_o_0_, 
        top_right_grid_left_width_0_height_0_subtile_2__pin_a2f_o_0_, 
        top_right_grid_left_width_0_height_0_subtile_3__pin_a2f_o_0_, 
        top_right_grid_left_width_0_height_0_subtile_4__pin_a2f_o_0_, 
        top_right_grid_left_width_0_height_0_subtile_5__pin_a2f_o_0_, 
        chanx_left_in, 
        left_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_, 
        left_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_, 
        left_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_, 
        left_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_, 
        ccff_head, chany_top_out, chanx_left_out, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:31] chany_top_in;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_0__pin_a2f_o_0_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_1__pin_a2f_o_0_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_2__pin_a2f_o_0_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_3__pin_a2f_o_0_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_4__pin_a2f_o_0_;
  input [0:0] top_right_grid_left_width_0_height_0_subtile_5__pin_a2f_o_0_;
  input [0:31] chanx_left_in;
  input [0:0] left_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_;
  input [0:0] left_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_;
  input [0:0] left_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_;
  input [0:0] left_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_;
  input [0:0] ccff_head;
  output [0:31] chany_top_out;
  output [0:31] chanx_left_out;
  output [0:0] ccff_tail;
  wire   n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30, n31, n32,
         n33, n34, n35, n36;
  wire   [0:2] sb_mux_size4_0_sram;
  wire   [0:2] sb_mux_size4_0_sram_inv;
  wire   [0:2] sb_mux_size4_1_sram;
  wire   [0:2] sb_mux_size4_1_sram_inv;
  wire   [0:2] sb_mux_size4_2_sram;
  wire   [0:2] sb_mux_size4_2_sram_inv;
  wire   [0:2] sb_mux_size4_3_sram;
  wire   [0:2] sb_mux_size4_3_sram_inv;
  wire   [0:2] sb_mux_size4_4_sram;
  wire   [0:2] sb_mux_size4_4_sram_inv;
  wire   [0:2] sb_mux_size4_5_sram;
  wire   [0:2] sb_mux_size4_5_sram_inv;
  wire   [0:2] sb_mux_size4_6_sram;
  wire   [0:2] sb_mux_size4_6_sram_inv;
  wire   [0:2] sb_mux_size4_7_sram;
  wire   [0:2] sb_mux_size4_7_sram_inv;
  wire   [0:2] sb_mux_size4_8_sram;
  wire   [0:2] sb_mux_size4_8_sram_inv;
  wire   [0:2] sb_mux_size4_9_sram;
  wire   [0:2] sb_mux_size4_9_sram_inv;
  wire   [0:2] sb_mux_size4_10_sram;
  wire   [0:2] sb_mux_size4_10_sram_inv;
  wire   [0:2] sb_mux_size4_11_sram;
  wire   [0:2] sb_mux_size4_11_sram_inv;
  wire   [0:1] sb_mux_size2_0_sram;
  wire   [0:1] sb_mux_size2_0_sram_inv;
  wire   [0:1] sb_mux_size2_1_sram;
  wire   [0:1] sb_mux_size2_1_sram_inv;
  wire   [0:1] sb_mux_size2_2_sram;
  wire   [0:1] sb_mux_size2_2_sram_inv;
  wire   [0:1] sb_mux_size2_3_sram;
  wire   [0:1] sb_mux_size2_3_sram_inv;
  wire   [0:1] sb_mux_size2_4_sram;
  wire   [0:1] sb_mux_size2_4_sram_inv;
  wire   [0:1] sb_mux_size2_5_sram;
  wire   [0:1] sb_mux_size2_5_sram_inv;
  wire   [0:1] sb_mux_size2_6_sram;
  wire   [0:1] sb_mux_size2_6_sram_inv;
  wire   [0:1] sb_mux_size2_7_sram;
  wire   [0:1] sb_mux_size2_7_sram_inv;
  wire   [0:1] sb_mux_size2_8_sram;
  wire   [0:1] sb_mux_size2_8_sram_inv;
  wire   [0:1] sb_mux_size2_9_sram;
  wire   [0:1] sb_mux_size2_9_sram_inv;
  wire   [0:1] sb_mux_size2_10_sram;
  wire   [0:1] sb_mux_size2_10_sram_inv;
  wire   [0:1] sb_mux_size2_11_sram;
  wire   [0:1] sb_mux_size2_11_sram_inv;
  wire   [0:1] sb_mux_size2_12_sram;
  wire   [0:1] sb_mux_size2_12_sram_inv;
  wire   [0:1] sb_mux_size2_13_sram;
  wire   [0:1] sb_mux_size2_13_sram_inv;
  wire   [0:1] sb_mux_size2_14_sram;
  wire   [0:1] sb_mux_size2_14_sram_inv;
  wire   [0:1] sb_mux_size2_15_sram;
  wire   [0:1] sb_mux_size2_15_sram_inv;
  wire   [0:1] sb_mux_size2_16_sram;
  wire   [0:1] sb_mux_size2_16_sram_inv;
  wire   [0:1] sb_mux_size2_17_sram;
  wire   [0:1] sb_mux_size2_17_sram_inv;
  wire   [0:1] sb_mux_size2_18_sram;
  wire   [0:1] sb_mux_size2_18_sram_inv;
  wire   [0:1] sb_mux_size2_19_sram;
  wire   [0:1] sb_mux_size2_19_sram_inv;
  wire   [0:1] sb_mux_size2_20_sram;
  wire   [0:1] sb_mux_size2_20_sram_inv;
  wire   [0:1] sb_mux_size2_21_sram;
  wire   [0:1] sb_mux_size2_21_sram_inv;
  wire   [0:1] sb_mux_size2_22_sram;
  wire   [0:1] sb_mux_size2_22_sram_inv;
  wire   [0:1] sb_mux_size2_23_sram;
  wire   [0:1] sb_mux_size2_23_sram_inv;
  wire   [0:1] sb_mux_size2_24_sram;
  wire   [0:1] sb_mux_size2_24_sram_inv;
  wire   [0:1] sb_mux_size2_25_sram;
  wire   [0:1] sb_mux_size2_25_sram_inv;
  wire   [0:1] sb_mux_size2_26_sram;
  wire   [0:1] sb_mux_size2_26_sram_inv;
  wire   [0:1] sb_mux_size2_27_sram;
  wire   [0:1] sb_mux_size2_27_sram_inv;
  wire   [0:1] sb_mux_size2_28_sram;
  wire   [0:1] sb_mux_size2_28_sram_inv;
  wire   [0:1] sb_mux_size2_29_sram;
  wire   [0:1] sb_mux_size2_29_sram_inv;
  assign chanx_left_out[4] = chany_top_in[28];
  assign chanx_left_out[5] = chany_top_in[27];
  assign chanx_left_out[10] = chany_top_in[22];
  assign chanx_left_out[11] = chany_top_in[21];
  assign chanx_left_out[16] = chany_top_in[16];
  assign chanx_left_out[17] = chany_top_in[15];
  assign chanx_left_out[18] = chany_top_in[14];
  assign chanx_left_out[19] = chany_top_in[13];
  assign chanx_left_out[20] = chany_top_in[12];
  assign chanx_left_out[21] = chany_top_in[11];
  assign chanx_left_out[22] = chany_top_in[10];
  assign chanx_left_out[23] = chany_top_in[9];
  assign chanx_left_out[24] = chany_top_in[8];
  assign chanx_left_out[25] = chany_top_in[7];
  assign chanx_left_out[26] = chany_top_in[6];
  assign chanx_left_out[27] = chany_top_in[5];
  assign chanx_left_out[28] = chany_top_in[4];
  assign chanx_left_out[29] = chany_top_in[3];
  assign chanx_left_out[30] = chany_top_in[2];
  assign chanx_left_out[31] = chany_top_in[1];
  assign chany_top_out[30] = chanx_left_in[2];
  assign chany_top_out[31] = chanx_left_in[1];

  sb_6__sb_mux_size4 mux_top_track_0 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_[0], 
        top_right_grid_left_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        chanx_left_in[0]}), .sram(sb_mux_size4_0_sram), .sram_inv(
        sb_mux_size4_0_sram_inv), .out(n19) );
  sb_6__sb_mux_size4 mux_top_track_2 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_[0], 
        top_right_grid_left_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_left_in[31]}), .sram(sb_mux_size4_1_sram), .sram_inv(
        sb_mux_size4_1_sram_inv), .out(n20) );
  sb_6__sb_mux_size4 mux_top_track_4 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_[0], 
        top_right_grid_left_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_left_in[30]}), .sram(sb_mux_size4_2_sram), .sram_inv(
        sb_mux_size4_2_sram_inv), .out(n21) );
  sb_6__sb_mux_size4 mux_top_track_6 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_[0], 
        top_right_grid_left_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_left_in[29]}), .sram(sb_mux_size4_3_sram), .sram_inv(
        sb_mux_size4_3_sram_inv), .out(n22) );
  sb_6__sb_mux_size4 mux_top_track_8 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_[0], 
        top_right_grid_left_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_left_in[28]}), .sram(sb_mux_size4_4_sram), .sram_inv(
        sb_mux_size4_4_sram_inv), .out(n23) );
  sb_6__sb_mux_size4 mux_top_track_10 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_[0], 
        top_right_grid_left_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_left_in[27]}), .sram(sb_mux_size4_5_sram), .sram_inv(
        sb_mux_size4_5_sram_inv), .out(n24) );
  sb_6__sb_mux_size4 mux_top_track_12 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_[0], 
        top_right_grid_left_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        chanx_left_in[26]}), .sram(sb_mux_size4_6_sram), .sram_inv(
        sb_mux_size4_6_sram_inv), .out(n25) );
  sb_6__sb_mux_size4 mux_top_track_14 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_[0], 
        top_right_grid_left_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_left_in[25]}), .sram(sb_mux_size4_7_sram), .sram_inv(
        sb_mux_size4_7_sram_inv), .out(n26) );
  sb_6__sb_mux_size4 mux_top_track_16 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_[0], 
        top_right_grid_left_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_left_in[24]}), .sram(sb_mux_size4_8_sram), .sram_inv(
        sb_mux_size4_8_sram_inv), .out(chany_top_out[8]) );
  sb_6__sb_mux_size4 mux_top_track_18 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_[0], 
        top_right_grid_left_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_left_in[23]}), .sram(sb_mux_size4_9_sram), .sram_inv(
        sb_mux_size4_9_sram_inv), .out(chany_top_out[9]) );
  sb_6__sb_mux_size4 mux_top_track_20 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_[0], 
        top_right_grid_left_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_left_in[22]}), .sram(sb_mux_size4_10_sram), .sram_inv(
        sb_mux_size4_10_sram_inv), .out(chany_top_out[10]) );
  sb_6__sb_mux_size4 mux_top_track_22 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_[0], 
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_[0], 
        top_right_grid_left_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_left_in[21]}), .sram(sb_mux_size4_11_sram), .sram_inv(
        sb_mux_size4_11_sram_inv), .out(chany_top_out[11]) );
  sb_6__sb_mux_size2 mux_top_track_24 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_12_[0], 
        chanx_left_in[20]}), .sram(sb_mux_size2_0_sram), .sram_inv(
        sb_mux_size2_0_sram_inv), .out(chany_top_out[12]) );
  sb_6__sb_mux_size2 mux_top_track_26 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_13_[0], 
        chanx_left_in[19]}), .sram(sb_mux_size2_1_sram), .sram_inv(
        sb_mux_size2_1_sram_inv), .out(chany_top_out[13]) );
  sb_6__sb_mux_size2 mux_top_track_28 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_14_[0], 
        chanx_left_in[18]}), .sram(sb_mux_size2_2_sram), .sram_inv(
        sb_mux_size2_2_sram_inv), .out(chany_top_out[14]) );
  sb_6__sb_mux_size2 mux_top_track_30 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_15_[0], 
        chanx_left_in[17]}), .sram(sb_mux_size2_3_sram), .sram_inv(
        sb_mux_size2_3_sram_inv), .out(chany_top_out[15]) );
  sb_6__sb_mux_size2 mux_top_track_32 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_16_[0], 
        chanx_left_in[16]}), .sram(sb_mux_size2_4_sram), .sram_inv(
        sb_mux_size2_4_sram_inv), .out(n27) );
  sb_6__sb_mux_size2 mux_top_track_34 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_17_[0], 
        chanx_left_in[15]}), .sram(sb_mux_size2_5_sram), .sram_inv(
        sb_mux_size2_5_sram_inv), .out(chany_top_out[17]) );
  sb_6__sb_mux_size2 mux_top_track_36 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_18_[0], 
        chanx_left_in[14]}), .sram(sb_mux_size2_6_sram), .sram_inv(
        sb_mux_size2_6_sram_inv), .out(chany_top_out[18]) );
  sb_6__sb_mux_size2 mux_top_track_38 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_19_[0], 
        chanx_left_in[13]}), .sram(sb_mux_size2_7_sram), .sram_inv(
        sb_mux_size2_7_sram_inv), .out(chany_top_out[19]) );
  sb_6__sb_mux_size2 mux_top_track_40 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_20_[0], 
        chanx_left_in[12]}), .sram(sb_mux_size2_8_sram), .sram_inv(
        sb_mux_size2_8_sram_inv), .out(n28) );
  sb_6__sb_mux_size2 mux_top_track_42 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_21_[0], 
        chanx_left_in[11]}), .sram(sb_mux_size2_9_sram), .sram_inv(
        sb_mux_size2_9_sram_inv), .out(chany_top_out[21]) );
  sb_6__sb_mux_size2 mux_top_track_44 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_22_[0], 
        chanx_left_in[10]}), .sram(sb_mux_size2_10_sram), .sram_inv(
        sb_mux_size2_10_sram_inv), .out(chany_top_out[22]) );
  sb_6__sb_mux_size2 mux_top_track_46 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_O_23_[0], 
        chanx_left_in[9]}), .sram(sb_mux_size2_11_sram), .sram_inv(
        sb_mux_size2_11_sram_inv), .out(chany_top_out[23]) );
  sb_6__sb_mux_size2 mux_top_track_48 ( .in({
        top_right_grid_left_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        chanx_left_in[8]}), .sram(sb_mux_size2_12_sram), .sram_inv(
        sb_mux_size2_12_sram_inv), .out(n29) );
  sb_6__sb_mux_size2 mux_top_track_50 ( .in({
        top_right_grid_left_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_left_in[7]}), .sram(sb_mux_size2_13_sram), .sram_inv(
        sb_mux_size2_13_sram_inv), .out(chany_top_out[25]) );
  sb_6__sb_mux_size2 mux_top_track_52 ( .in({
        top_right_grid_left_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_left_in[6]}), .sram(sb_mux_size2_14_sram), .sram_inv(
        sb_mux_size2_14_sram_inv), .out(chany_top_out[26]) );
  sb_6__sb_mux_size2 mux_top_track_54 ( .in({
        top_right_grid_left_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_left_in[5]}), .sram(sb_mux_size2_15_sram), .sram_inv(
        sb_mux_size2_15_sram_inv), .out(chany_top_out[27]) );
  sb_6__sb_mux_size2 mux_top_track_56 ( .in({
        top_right_grid_left_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_left_in[4]}), .sram(sb_mux_size2_16_sram), .sram_inv(
        sb_mux_size2_16_sram_inv), .out(n30) );
  sb_6__sb_mux_size2 mux_top_track_58 ( .in({
        top_right_grid_left_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_left_in[3]}), .sram(sb_mux_size2_17_sram), .sram_inv(
        sb_mux_size2_17_sram_inv), .out(chany_top_out[29]) );
  sb_6__sb_mux_size2 mux_left_track_1 ( .in({chany_top_in[0], 
        left_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_18_sram), .sram_inv(sb_mux_size2_18_sram_inv), 
        .out(n31) );
  sb_6__sb_mux_size2 mux_left_track_3 ( .in({chany_top_in[31], 
        left_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_19_sram), .sram_inv(sb_mux_size2_19_sram_inv), 
        .out(n32) );
  sb_6__sb_mux_size2 mux_left_track_5 ( .in({chany_top_in[30], 
        left_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_20_sram), .sram_inv(sb_mux_size2_20_sram_inv), 
        .out(n33) );
  sb_6__sb_mux_size2 mux_left_track_7 ( .in({chany_top_in[29], 
        left_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_21_sram), .sram_inv(sb_mux_size2_21_sram_inv), 
        .out(n34) );
  sb_6__sb_mux_size2 mux_left_track_13 ( .in({chany_top_in[26], 
        left_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_22_sram), .sram_inv(sb_mux_size2_22_sram_inv), 
        .out(n35) );
  sb_6__sb_mux_size2 mux_left_track_15 ( .in({chany_top_in[25], 
        left_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_23_sram), .sram_inv(sb_mux_size2_23_sram_inv), 
        .out(n36) );
  sb_6__sb_mux_size2 mux_left_track_17 ( .in({chany_top_in[24], 
        left_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_24_sram), .sram_inv(sb_mux_size2_24_sram_inv), 
        .out(chanx_left_out[8]) );
  sb_6__sb_mux_size2 mux_left_track_19 ( .in({chany_top_in[23], 
        left_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_25_sram), .sram_inv(sb_mux_size2_25_sram_inv), 
        .out(chanx_left_out[9]) );
  sb_6__sb_mux_size2 mux_left_track_25 ( .in({chany_top_in[20], 
        left_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_26_sram), .sram_inv(sb_mux_size2_26_sram_inv), 
        .out(chanx_left_out[12]) );
  sb_6__sb_mux_size2 mux_left_track_27 ( .in({chany_top_in[19], 
        left_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_27_sram), .sram_inv(sb_mux_size2_27_sram_inv), 
        .out(chanx_left_out[13]) );
  sb_6__sb_mux_size2 mux_left_track_29 ( .in({chany_top_in[18], 
        left_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_28_sram), .sram_inv(sb_mux_size2_28_sram_inv), 
        .out(chanx_left_out[14]) );
  sb_6__sb_mux_size2 mux_left_track_31 ( .in({chany_top_in[17], 
        left_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_29_sram), .sram_inv(sb_mux_size2_29_sram_inv), 
        .out(chanx_left_out[15]) );
  sb_6__config_group_mem_size96 sb_6__config_group_mem_size96 ( 
        .config_enable(config_enable[0]), .prog_reset(prog_reset[0]), 
        .prog_clk(prog_clk[0]), .ccff_head(ccff_head[0]), .mem_out({
        sb_mux_size4_0_sram, sb_mux_size4_1_sram, sb_mux_size4_2_sram, 
        sb_mux_size4_3_sram, sb_mux_size4_4_sram, sb_mux_size4_5_sram, 
        sb_mux_size4_6_sram, sb_mux_size4_7_sram, sb_mux_size4_8_sram, 
        sb_mux_size4_9_sram, sb_mux_size4_10_sram, sb_mux_size4_11_sram, 
        sb_mux_size2_0_sram, sb_mux_size2_1_sram, sb_mux_size2_2_sram, 
        sb_mux_size2_3_sram, sb_mux_size2_4_sram, sb_mux_size2_5_sram, 
        sb_mux_size2_6_sram, sb_mux_size2_7_sram, sb_mux_size2_8_sram, 
        sb_mux_size2_9_sram, sb_mux_size2_10_sram, sb_mux_size2_11_sram, 
        sb_mux_size2_12_sram, sb_mux_size2_13_sram, sb_mux_size2_14_sram, 
        sb_mux_size2_15_sram, sb_mux_size2_16_sram, sb_mux_size2_17_sram, 
        sb_mux_size2_18_sram, sb_mux_size2_19_sram, sb_mux_size2_20_sram, 
        sb_mux_size2_21_sram, sb_mux_size2_22_sram, sb_mux_size2_23_sram, 
        sb_mux_size2_24_sram, sb_mux_size2_25_sram, sb_mux_size2_26_sram, 
        sb_mux_size2_27_sram, sb_mux_size2_28_sram, sb_mux_size2_29_sram}), 
        .mem_outb({sb_mux_size4_0_sram_inv, sb_mux_size4_1_sram_inv, 
        sb_mux_size4_2_sram_inv, sb_mux_size4_3_sram_inv, 
        sb_mux_size4_4_sram_inv, sb_mux_size4_5_sram_inv, 
        sb_mux_size4_6_sram_inv, sb_mux_size4_7_sram_inv, 
        sb_mux_size4_8_sram_inv, sb_mux_size4_9_sram_inv, 
        sb_mux_size4_10_sram_inv, sb_mux_size4_11_sram_inv, 
        sb_mux_size2_0_sram_inv, sb_mux_size2_1_sram_inv, 
        sb_mux_size2_2_sram_inv, sb_mux_size2_3_sram_inv, 
        sb_mux_size2_4_sram_inv, sb_mux_size2_5_sram_inv, 
        sb_mux_size2_6_sram_inv, sb_mux_size2_7_sram_inv, 
        sb_mux_size2_8_sram_inv, sb_mux_size2_9_sram_inv, 
        sb_mux_size2_10_sram_inv, sb_mux_size2_11_sram_inv, 
        sb_mux_size2_12_sram_inv, sb_mux_size2_13_sram_inv, 
        sb_mux_size2_14_sram_inv, sb_mux_size2_15_sram_inv, 
        sb_mux_size2_16_sram_inv, sb_mux_size2_17_sram_inv, 
        sb_mux_size2_18_sram_inv, sb_mux_size2_19_sram_inv, 
        sb_mux_size2_20_sram_inv, sb_mux_size2_21_sram_inv, 
        sb_mux_size2_22_sram_inv, sb_mux_size2_23_sram_inv, 
        sb_mux_size2_24_sram_inv, sb_mux_size2_25_sram_inv, 
        sb_mux_size2_26_sram_inv, sb_mux_size2_27_sram_inv, 
        sb_mux_size2_28_sram_inv, sb_mux_size2_29_sram_inv}), .ccff_tail(
        ccff_tail[0]) );
  CKBD2BWP30P140HVT U1 ( .I(n36), .Z(chanx_left_out[7]) );
  CKBD2BWP30P140HVT U2 ( .I(n35), .Z(chanx_left_out[6]) );
  CKBD2BWP30P140HVT U3 ( .I(n34), .Z(chanx_left_out[3]) );
  CKBD2BWP30P140HVT U4 ( .I(n33), .Z(chanx_left_out[2]) );
  CKBD2BWP30P140HVT U5 ( .I(n32), .Z(chanx_left_out[1]) );
  CKBD2BWP30P140HVT U6 ( .I(n31), .Z(chanx_left_out[0]) );
  CKBD2BWP30P140HVT U7 ( .I(n20), .Z(chany_top_out[1]) );
  CKBD2BWP30P140HVT U8 ( .I(n21), .Z(chany_top_out[2]) );
  CKBD2BWP30P140HVT U9 ( .I(n22), .Z(chany_top_out[3]) );
  CKBD2BWP30P140HVT U10 ( .I(n23), .Z(chany_top_out[4]) );
  CKBD2BWP30P140HVT U11 ( .I(n24), .Z(chany_top_out[5]) );
  CKBD2BWP30P140HVT U12 ( .I(n25), .Z(chany_top_out[6]) );
  CKBD2BWP30P140HVT U13 ( .I(n19), .Z(chany_top_out[0]) );
  CKBD2BWP30P140HVT U14 ( .I(n26), .Z(chany_top_out[7]) );
  CKBD2BWP30P140HVT U15 ( .I(n27), .Z(chany_top_out[16]) );
  CKBD2BWP30P140HVT U16 ( .I(n28), .Z(chany_top_out[20]) );
  CKBD2BWP30P140HVT U17 ( .I(n29), .Z(chany_top_out[24]) );
  CKBD2BWP30P140HVT U18 ( .I(n30), .Z(chany_top_out[28]) );
endmodule

