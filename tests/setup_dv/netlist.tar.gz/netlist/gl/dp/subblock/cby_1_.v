/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : Q-2019.12-SP4

/////////////////////////////////////////////////////////////


module cby_1__cb_mux_size6 ( in, sram, sram_inv, out );
  input [0:5] in;
  input [0:2] sram;
  input [0:2] sram_inv;
  output [0:0] out;
  wire   n8, n9, n10, n11, n12, n13, n14;

  INVD1BWP30P140HVT U9 ( .I(sram[2]), .ZN(n14) );
  INVD1BWP30P140HVT U10 ( .I(sram[0]), .ZN(n8) );
  AOI22D1BWP30P140HVT U11 ( .A1(sram[0]), .A2(in[2]), .B1(in[3]), .B2(n8), 
        .ZN(n13) );
  AOI22D1BWP30P140HVT U12 ( .A1(sram[2]), .A2(in[0]), .B1(in[4]), .B2(n14), 
        .ZN(n10) );
  AOI22D1BWP30P140HVT U13 ( .A1(sram[2]), .A2(in[1]), .B1(in[5]), .B2(n14), 
        .ZN(n9) );
  AOI22D1BWP30P140HVT U14 ( .A1(sram[0]), .A2(n10), .B1(n9), .B2(n8), .ZN(n11)
         );
  ND2D1BWP30P140HVT U15 ( .A1(sram[1]), .A2(n11), .ZN(n12) );
  OAI31D1BWP30P140HVT U16 ( .A1(sram[1]), .A2(n14), .A3(n13), .B(n12), .ZN(
        out[0]) );
endmodule


module cby_1__config_group_mem_size36 ( config_enable, prog_reset, prog_clk, 
        ccff_head, mem_out, mem_outb, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:0] ccff_head;
  output [0:35] mem_out;
  output [0:35] mem_outb;
  output [0:0] ccff_tail;
  wire   cb_mux_size6_mem_0_ccff_tail, cb_mux_size6_mem_1_ccff_tail,
         cb_mux_size6_mem_2_ccff_tail, cb_mux_size6_mem_3_ccff_tail,
         cb_mux_size6_mem_4_ccff_tail, cb_mux_size6_mem_5_ccff_tail,
         cb_mux_size6_mem_6_ccff_tail, cb_mux_size6_mem_7_ccff_tail,
         cb_mux_size6_mem_8_ccff_tail, cb_mux_size6_mem_9_ccff_tail,
         cb_mux_size6_mem_10_ccff_tail, mem_right_ipin_0_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_0_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_11_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_11_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_10_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_10_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_9_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_9_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_8_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_8_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_7_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_7_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_6_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_6_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_5_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_5_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_4_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_4_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_3_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_3_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_2_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_2_TSMC22ULP_CCFF_0_Q,
         mem_right_ipin_1_TSMC22ULP_CCFF_1_Q,
         mem_right_ipin_1_TSMC22ULP_CCFF_0_Q, eco_net, eco_net_0, eco_net_1_0,
         eco_net_2_0, eco_net_3_0, eco_net_4_0, eco_net_5_0, eco_net_6_0,
         eco_net_7_0, eco_net_8_0, eco_net_9_0, eco_net_10_0, eco_net_11_0,
         eco_net_12_0, eco_net_13_0, eco_net_14_0, eco_net_15_0, eco_net_16_0,
         eco_net_17_0, eco_net_18_0, eco_net_19_0, eco_net_20_0, eco_net_21_0,
         eco_net_22_0, eco_net_23_0, eco_net_24_0, eco_net_25_0, eco_net_26_0,
         eco_net_27_0, eco_net_28_0, eco_net_29_0, eco_net_30_0, eco_net_31_0,
         eco_net_32_0, eco_net_33_0, eco_net_34_0, eco_net_35_0, eco_net_36_0,
         eco_net_37_0;

  DFCNQD1BWP30P140HVT mem_right_ipin_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_5_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_11_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(mem_right_ipin_11_TSMC22ULP_CCFF_1_Q), .CP(prog_clk[0]), .CDN(
        prog_reset[0]), .Q(ccff_tail[0]) );
  DFCNQD1BWP30P140HVT mem_right_ipin_11_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(mem_right_ipin_11_TSMC22ULP_CCFF_0_Q), .CP(prog_clk[0]), .CDN(
        prog_reset[0]), .Q(mem_right_ipin_11_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_11_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(cb_mux_size6_mem_10_ccff_tail), .CP(prog_clk[0]), .CDN(
        prog_reset[0]), .Q(mem_right_ipin_11_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_10_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_37_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_10_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_36_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_10_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_10_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_35_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_10_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_9_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_34_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_9_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_33_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_9_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_9_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_32_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_9_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_8_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_31_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_8_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_30_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_8_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_8_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_29_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_8_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_7_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_28_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_7_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_27_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_7_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_7_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_26_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_7_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_6_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_25_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_24_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_6_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_23_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_5_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_22_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_5_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_21_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_5_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_5_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_20_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_5_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_4_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_19_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_18_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_4_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_17_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_3_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_16_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_3_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_15_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_3_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_3_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_14_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_3_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_2_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_13_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_12_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_2_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_11_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_1_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_10_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_1_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_9_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_1_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_1_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_8_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_1_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_ipin_0_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_7_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        cb_mux_size6_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_ipin_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_6_0), .CP(eco_net), .CDN(eco_net_1_0), .Q(
        mem_right_ipin_0_TSMC22ULP_CCFF_1_Q) );
  ND2D1BWP30P140HVT U73 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_0_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[1]) );
  INVD1BWP30P140HVT U74 ( .I(mem_outb[1]), .ZN(mem_out[1]) );
  ND2D1BWP30P140HVT U75 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_0_ccff_tail), .ZN(mem_outb[2]) );
  INVD1BWP30P140HVT U76 ( .I(mem_outb[2]), .ZN(mem_out[2]) );
  ND2D1BWP30P140HVT U77 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_1_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[3]) );
  INVD1BWP30P140HVT U78 ( .I(mem_outb[3]), .ZN(mem_out[3]) );
  ND2D1BWP30P140HVT U79 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_1_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[4]) );
  INVD1BWP30P140HVT U80 ( .I(mem_outb[4]), .ZN(mem_out[4]) );
  ND2D1BWP30P140HVT U81 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_1_ccff_tail), .ZN(mem_outb[5]) );
  INVD1BWP30P140HVT U82 ( .I(mem_outb[5]), .ZN(mem_out[5]) );
  ND2D1BWP30P140HVT U83 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[6]) );
  INVD1BWP30P140HVT U84 ( .I(mem_outb[6]), .ZN(mem_out[6]) );
  ND2D1BWP30P140HVT U85 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_2_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[7]) );
  INVD1BWP30P140HVT U86 ( .I(mem_outb[7]), .ZN(mem_out[7]) );
  ND2D1BWP30P140HVT U87 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_2_ccff_tail), .ZN(mem_outb[8]) );
  INVD1BWP30P140HVT U88 ( .I(mem_outb[8]), .ZN(mem_out[8]) );
  ND2D1BWP30P140HVT U89 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_3_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[9]) );
  INVD1BWP30P140HVT U90 ( .I(mem_outb[9]), .ZN(mem_out[9]) );
  ND2D1BWP30P140HVT U91 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_3_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[10]) );
  INVD1BWP30P140HVT U92 ( .I(mem_outb[10]), .ZN(mem_out[10]) );
  ND2D1BWP30P140HVT U93 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_3_ccff_tail), .ZN(mem_outb[11]) );
  INVD1BWP30P140HVT U94 ( .I(mem_outb[11]), .ZN(mem_out[11]) );
  ND2D1BWP30P140HVT U95 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[12]) );
  INVD1BWP30P140HVT U96 ( .I(mem_outb[12]), .ZN(mem_out[12]) );
  ND2D1BWP30P140HVT U97 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_4_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[13]) );
  INVD1BWP30P140HVT U98 ( .I(mem_outb[13]), .ZN(mem_out[13]) );
  ND2D1BWP30P140HVT U99 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_4_ccff_tail), .ZN(mem_outb[14]) );
  INVD1BWP30P140HVT U100 ( .I(mem_outb[14]), .ZN(mem_out[14]) );
  ND2D1BWP30P140HVT U101 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_5_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[15]) );
  INVD1BWP30P140HVT U102 ( .I(mem_outb[15]), .ZN(mem_out[15]) );
  ND2D1BWP30P140HVT U103 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_5_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[16]) );
  INVD1BWP30P140HVT U104 ( .I(mem_outb[16]), .ZN(mem_out[16]) );
  ND2D1BWP30P140HVT U105 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_5_ccff_tail), .ZN(mem_outb[17]) );
  INVD1BWP30P140HVT U106 ( .I(mem_outb[17]), .ZN(mem_out[17]) );
  ND2D1BWP30P140HVT U107 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[18]) );
  INVD1BWP30P140HVT U108 ( .I(mem_outb[18]), .ZN(mem_out[18]) );
  ND2D1BWP30P140HVT U109 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_6_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[19]) );
  INVD1BWP30P140HVT U110 ( .I(mem_outb[19]), .ZN(mem_out[19]) );
  ND2D1BWP30P140HVT U111 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_6_ccff_tail), .ZN(mem_outb[20]) );
  INVD1BWP30P140HVT U112 ( .I(mem_outb[20]), .ZN(mem_out[20]) );
  ND2D1BWP30P140HVT U113 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_7_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[21]) );
  INVD1BWP30P140HVT U114 ( .I(mem_outb[21]), .ZN(mem_out[21]) );
  ND2D1BWP30P140HVT U115 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_7_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[22]) );
  INVD1BWP30P140HVT U116 ( .I(mem_outb[22]), .ZN(mem_out[22]) );
  ND2D1BWP30P140HVT U117 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_7_ccff_tail), .ZN(mem_outb[23]) );
  INVD1BWP30P140HVT U118 ( .I(mem_outb[23]), .ZN(mem_out[23]) );
  ND2D1BWP30P140HVT U119 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_8_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[24]) );
  INVD1BWP30P140HVT U120 ( .I(mem_outb[24]), .ZN(mem_out[24]) );
  ND2D1BWP30P140HVT U121 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_8_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[25]) );
  INVD1BWP30P140HVT U122 ( .I(mem_outb[25]), .ZN(mem_out[25]) );
  ND2D1BWP30P140HVT U123 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_8_ccff_tail), .ZN(mem_outb[26]) );
  INVD1BWP30P140HVT U124 ( .I(mem_outb[26]), .ZN(mem_out[26]) );
  ND2D1BWP30P140HVT U125 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_9_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[27]) );
  INVD1BWP30P140HVT U126 ( .I(mem_outb[27]), .ZN(mem_out[27]) );
  ND2D1BWP30P140HVT U127 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_9_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[28]) );
  INVD1BWP30P140HVT U128 ( .I(mem_outb[28]), .ZN(mem_out[28]) );
  ND2D1BWP30P140HVT U129 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_9_ccff_tail), .ZN(mem_outb[29]) );
  INVD1BWP30P140HVT U130 ( .I(mem_outb[29]), .ZN(mem_out[29]) );
  ND2D1BWP30P140HVT U131 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_10_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[30]) );
  INVD1BWP30P140HVT U132 ( .I(mem_outb[30]), .ZN(mem_out[30]) );
  ND2D1BWP30P140HVT U133 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_10_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[31]) );
  INVD1BWP30P140HVT U134 ( .I(mem_outb[31]), .ZN(mem_out[31]) );
  ND2D1BWP30P140HVT U135 ( .A1(config_enable[0]), .A2(
        cb_mux_size6_mem_10_ccff_tail), .ZN(mem_outb[32]) );
  INVD1BWP30P140HVT U136 ( .I(mem_outb[32]), .ZN(mem_out[32]) );
  ND2D1BWP30P140HVT U137 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_11_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[33]) );
  INVD1BWP30P140HVT U138 ( .I(mem_outb[33]), .ZN(mem_out[33]) );
  ND2D1BWP30P140HVT U139 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_11_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[34]) );
  INVD1BWP30P140HVT U140 ( .I(mem_outb[34]), .ZN(mem_out[34]) );
  ND2D1BWP30P140HVT U141 ( .A1(config_enable[0]), .A2(ccff_tail[0]), .ZN(
        mem_outb[35]) );
  INVD1BWP30P140HVT U142 ( .I(mem_outb[35]), .ZN(mem_out[35]) );
  ND2D1BWP30P140HVT U143 ( .A1(config_enable[0]), .A2(
        mem_right_ipin_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[0]) );
  INVD1BWP30P140HVT U144 ( .I(mem_outb[0]), .ZN(mem_out[0]) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_cp_buf2 ( .I(eco_net_0), .Z(eco_net) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_cp_buf1 ( .I(prog_clk[0]), .Z(eco_net_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_cdn_buf2 ( .I(eco_net_2_0), .Z(
        eco_net_1_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_cdn_buf1 ( .I(prog_reset[0]), .Z(
        eco_net_2_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_0_del1 ( .I(ccff_head[0]), .Z(eco_net_3_0)
         );
  BUFFD1BWP30P140HVT mem_right_ipin_0_del2 ( .I(eco_net_3_0), .Z(eco_net_4_0)
         );
  BUFFD1BWP30P140HVT mem_right_ipin_0_del3_0 ( .I(eco_net_4_0), .Z(eco_net_5_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_0_del3_1 ( .I(
        mem_right_ipin_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_6_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_0_del3_2 ( .I(
        mem_right_ipin_0_TSMC22ULP_CCFF_1_Q), .Z(eco_net_7_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_1_del3_0 ( .I(cb_mux_size6_mem_0_ccff_tail), .Z(eco_net_8_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_1_del3_1 ( .I(
        mem_right_ipin_1_TSMC22ULP_CCFF_0_Q), .Z(eco_net_9_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_1_del3_2 ( .I(
        mem_right_ipin_1_TSMC22ULP_CCFF_1_Q), .Z(eco_net_10_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_2_del3_0 ( .I(cb_mux_size6_mem_1_ccff_tail), .Z(eco_net_11_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_2_del3_1 ( .I(
        mem_right_ipin_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_12_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_2_del3_2 ( .I(
        mem_right_ipin_2_TSMC22ULP_CCFF_1_Q), .Z(eco_net_13_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_3_del3_0 ( .I(cb_mux_size6_mem_2_ccff_tail), .Z(eco_net_14_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_3_del3_1 ( .I(
        mem_right_ipin_3_TSMC22ULP_CCFF_0_Q), .Z(eco_net_15_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_3_del3_2 ( .I(
        mem_right_ipin_3_TSMC22ULP_CCFF_1_Q), .Z(eco_net_16_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_4_del3_0 ( .I(cb_mux_size6_mem_3_ccff_tail), .Z(eco_net_17_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_4_del3_1 ( .I(
        mem_right_ipin_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_18_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_4_del3_2 ( .I(
        mem_right_ipin_4_TSMC22ULP_CCFF_1_Q), .Z(eco_net_19_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_5_del3_0 ( .I(cb_mux_size6_mem_4_ccff_tail), .Z(eco_net_20_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_5_del3_1 ( .I(
        mem_right_ipin_5_TSMC22ULP_CCFF_0_Q), .Z(eco_net_21_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_5_del3_2 ( .I(
        mem_right_ipin_5_TSMC22ULP_CCFF_1_Q), .Z(eco_net_22_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_6_del3_0 ( .I(cb_mux_size6_mem_5_ccff_tail), .Z(eco_net_23_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_6_del3_1 ( .I(
        mem_right_ipin_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_24_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_6_del3_2 ( .I(
        mem_right_ipin_6_TSMC22ULP_CCFF_1_Q), .Z(eco_net_25_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_7_del3_0 ( .I(cb_mux_size6_mem_6_ccff_tail), .Z(eco_net_26_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_7_del3_1 ( .I(
        mem_right_ipin_7_TSMC22ULP_CCFF_0_Q), .Z(eco_net_27_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_7_del3_2 ( .I(
        mem_right_ipin_7_TSMC22ULP_CCFF_1_Q), .Z(eco_net_28_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_8_del3_0 ( .I(cb_mux_size6_mem_7_ccff_tail), .Z(eco_net_29_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_8_del3_1 ( .I(
        mem_right_ipin_8_TSMC22ULP_CCFF_0_Q), .Z(eco_net_30_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_8_del3_2 ( .I(
        mem_right_ipin_8_TSMC22ULP_CCFF_1_Q), .Z(eco_net_31_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_9_del3_0 ( .I(cb_mux_size6_mem_8_ccff_tail), .Z(eco_net_32_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_9_del3_1 ( .I(
        mem_right_ipin_9_TSMC22ULP_CCFF_0_Q), .Z(eco_net_33_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_9_del3_2 ( .I(
        mem_right_ipin_9_TSMC22ULP_CCFF_1_Q), .Z(eco_net_34_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_del3_0 ( .I(
        cb_mux_size6_mem_9_ccff_tail), .Z(eco_net_35_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_del3_1 ( .I(
        mem_right_ipin_10_TSMC22ULP_CCFF_0_Q), .Z(eco_net_36_0) );
  BUFFD1BWP30P140HVT mem_right_ipin_10_del3_2 ( .I(
        mem_right_ipin_10_TSMC22ULP_CCFF_1_Q), .Z(eco_net_37_0) );
endmodule


module cby_1_ ( config_enable, prog_reset, prog_clk, chany_bottom_in, 
        chany_top_in, ccff_head, chany_bottom_out, chany_top_out, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_14_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_15_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_16_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_17_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_18_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_19_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_20_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_21_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_22_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_23_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_24_, 
        left_grid_right_width_0_height_0_subtile_0__pin_I_25_, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:31] chany_bottom_in;
  input [0:31] chany_top_in;
  input [0:0] ccff_head;
  output [0:31] chany_bottom_out;
  output [0:31] chany_top_out;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_14_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_15_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_16_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_17_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_18_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_19_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_20_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_21_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_22_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_23_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_24_;
  output [0:0] left_grid_right_width_0_height_0_subtile_0__pin_I_25_;
  output [0:0] ccff_tail;
  wire   n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n14, n16,
         n18, n20, n22, n24, n26, n28, n30, n32, n34, n36, n37, n38, n39, n40,
         n41, n42, n43, n44, n45, n46, n47, n48;
  wire   [0:2] cb_mux_size6_0_sram;
  wire   [0:2] cb_mux_size6_0_sram_inv;
  wire   [0:2] cb_mux_size6_1_sram;
  wire   [0:2] cb_mux_size6_1_sram_inv;
  wire   [0:2] cb_mux_size6_2_sram;
  wire   [0:2] cb_mux_size6_2_sram_inv;
  wire   [0:2] cb_mux_size6_3_sram;
  wire   [0:2] cb_mux_size6_3_sram_inv;
  wire   [0:2] cb_mux_size6_4_sram;
  wire   [0:2] cb_mux_size6_4_sram_inv;
  wire   [0:2] cb_mux_size6_5_sram;
  wire   [0:2] cb_mux_size6_5_sram_inv;
  wire   [0:2] cb_mux_size6_6_sram;
  wire   [0:2] cb_mux_size6_6_sram_inv;
  wire   [0:2] cb_mux_size6_7_sram;
  wire   [0:2] cb_mux_size6_7_sram_inv;
  wire   [0:2] cb_mux_size6_8_sram;
  wire   [0:2] cb_mux_size6_8_sram_inv;
  wire   [0:2] cb_mux_size6_9_sram;
  wire   [0:2] cb_mux_size6_9_sram_inv;
  wire   [0:2] cb_mux_size6_10_sram;
  wire   [0:2] cb_mux_size6_10_sram_inv;
  wire   [0:2] cb_mux_size6_11_sram;
  wire   [0:2] cb_mux_size6_11_sram_inv;
  assign chany_bottom_out[0] = chany_top_in[0];
  assign chany_bottom_out[1] = chany_top_in[1];
  assign chany_bottom_out[2] = chany_top_in[2];
  assign chany_bottom_out[3] = chany_top_in[3];
  assign chany_bottom_out[4] = chany_top_in[4];
  assign chany_bottom_out[5] = chany_top_in[5];
  assign chany_bottom_out[6] = chany_top_in[6];
  assign chany_bottom_out[7] = chany_top_in[7];
  assign chany_bottom_out[8] = chany_top_in[8];
  assign chany_bottom_out[9] = chany_top_in[9];
  assign chany_bottom_out[10] = chany_top_in[10];
  assign chany_bottom_out[11] = chany_top_in[11];
  assign chany_bottom_out[24] = chany_top_in[24];
  assign chany_bottom_out[25] = chany_top_in[25];
  assign chany_bottom_out[26] = chany_top_in[26];
  assign chany_bottom_out[27] = chany_top_in[27];
  assign chany_bottom_out[28] = chany_top_in[28];
  assign chany_bottom_out[29] = chany_top_in[29];
  assign chany_bottom_out[30] = chany_top_in[30];
  assign chany_bottom_out[31] = chany_top_in[31];
  assign chany_top_out[0] = chany_bottom_in[0];
  assign chany_top_out[1] = chany_bottom_in[1];
  assign chany_top_out[2] = chany_bottom_in[2];
  assign chany_top_out[3] = chany_bottom_in[3];
  assign chany_top_out[4] = chany_bottom_in[4];
  assign chany_top_out[5] = chany_bottom_in[5];
  assign chany_top_out[6] = chany_bottom_in[6];
  assign chany_top_out[7] = chany_bottom_in[7];
  assign chany_top_out[8] = chany_bottom_in[8];
  assign chany_top_out[9] = chany_bottom_in[9];
  assign chany_top_out[10] = chany_bottom_in[10];
  assign chany_top_out[11] = chany_bottom_in[11];
  assign chany_top_out[12] = chany_bottom_in[12];
  assign chany_top_out[13] = chany_bottom_in[13];
  assign chany_top_out[14] = chany_bottom_in[14];
  assign chany_top_out[15] = chany_bottom_in[15];
  assign chany_top_out[16] = chany_bottom_in[16];
  assign chany_top_out[17] = chany_bottom_in[17];
  assign chany_top_out[18] = chany_bottom_in[18];
  assign chany_top_out[19] = chany_bottom_in[19];
  assign chany_top_out[20] = chany_bottom_in[20];
  assign chany_top_out[21] = chany_bottom_in[21];
  assign chany_top_out[22] = chany_bottom_in[22];
  assign chany_top_out[23] = chany_bottom_in[23];
  assign chany_top_out[24] = chany_bottom_in[24];
  assign chany_top_out[25] = chany_bottom_in[25];
  assign chany_top_out[26] = chany_bottom_in[26];
  assign chany_top_out[27] = chany_bottom_in[27];
  assign chany_top_out[28] = chany_bottom_in[28];
  assign chany_top_out[29] = chany_bottom_in[29];
  assign chany_top_out[30] = chany_bottom_in[30];
  assign chany_top_out[31] = chany_bottom_in[31];

  cby_1__cb_mux_size6 mux_right_ipin_0 ( .in({chany_bottom_in[0], 
        chany_top_in[0], chany_bottom_in[6], chany_top_in[6], 
        chany_bottom_in[12], n48}), .sram(cb_mux_size6_0_sram), .sram_inv(
        cb_mux_size6_0_sram_inv), .out(n61) );
  cby_1__cb_mux_size6 mux_right_ipin_1 ( .in({chany_bottom_in[1], 
        chany_top_in[1], chany_bottom_in[7], chany_top_in[7], 
        chany_bottom_in[13], n47}), .sram(cb_mux_size6_1_sram), .sram_inv(
        cb_mux_size6_1_sram_inv), .out(n62) );
  cby_1__cb_mux_size6 mux_right_ipin_2 ( .in({chany_bottom_in[2], 
        chany_top_in[2], chany_bottom_in[8], chany_top_in[8], 
        chany_bottom_in[14], n46}), .sram(cb_mux_size6_2_sram), .sram_inv(
        cb_mux_size6_2_sram_inv), .out(n63) );
  cby_1__cb_mux_size6 mux_right_ipin_3 ( .in({chany_bottom_in[3], 
        chany_top_in[3], chany_bottom_in[9], chany_top_in[9], 
        chany_bottom_in[15], n45}), .sram(cb_mux_size6_3_sram), .sram_inv(
        cb_mux_size6_3_sram_inv), .out(n64) );
  cby_1__cb_mux_size6 mux_right_ipin_4 ( .in({chany_bottom_in[4], 
        chany_top_in[4], chany_bottom_in[10], chany_top_in[10], 
        chany_bottom_in[16], n44}), .sram(cb_mux_size6_4_sram), .sram_inv(
        cb_mux_size6_4_sram_inv), .out(n65) );
  cby_1__cb_mux_size6 mux_right_ipin_5 ( .in({chany_bottom_in[5], 
        chany_top_in[5], chany_bottom_in[11], chany_top_in[11], 
        chany_bottom_in[17], n43}), .sram(cb_mux_size6_5_sram), .sram_inv(
        cb_mux_size6_5_sram_inv), .out(n66) );
  cby_1__cb_mux_size6 mux_right_ipin_6 ( .in({chany_bottom_in[0], 
        chany_top_in[0], chany_bottom_in[6], chany_top_in[6], 
        chany_bottom_in[18], n42}), .sram(cb_mux_size6_6_sram), .sram_inv(
        cb_mux_size6_6_sram_inv), .out(n67) );
  cby_1__cb_mux_size6 mux_right_ipin_7 ( .in({chany_bottom_in[1], 
        chany_top_in[1], chany_bottom_in[7], chany_top_in[7], 
        chany_bottom_in[19], n41}), .sram(cb_mux_size6_7_sram), .sram_inv(
        cb_mux_size6_7_sram_inv), .out(n68) );
  cby_1__cb_mux_size6 mux_right_ipin_8 ( .in({chany_bottom_in[2], 
        chany_top_in[2], chany_bottom_in[8], chany_top_in[8], 
        chany_bottom_in[20], n40}), .sram(cb_mux_size6_8_sram), .sram_inv(
        cb_mux_size6_8_sram_inv), .out(n69) );
  cby_1__cb_mux_size6 mux_right_ipin_9 ( .in({chany_bottom_in[3], 
        chany_top_in[3], chany_bottom_in[9], chany_top_in[9], 
        chany_bottom_in[21], n39}), .sram(cb_mux_size6_9_sram), .sram_inv(
        cb_mux_size6_9_sram_inv), .out(n70) );
  cby_1__cb_mux_size6 mux_right_ipin_10 ( .in({chany_bottom_in[4], 
        chany_top_in[4], chany_bottom_in[10], chany_top_in[10], 
        chany_bottom_in[22], n38}), .sram(cb_mux_size6_10_sram), .sram_inv(
        cb_mux_size6_10_sram_inv), .out(n71) );
  cby_1__cb_mux_size6 mux_right_ipin_11 ( .in({chany_bottom_in[5], 
        chany_top_in[5], chany_bottom_in[11], chany_top_in[11], 
        chany_bottom_in[23], n37}), .sram(cb_mux_size6_11_sram), .sram_inv(
        cb_mux_size6_11_sram_inv), .out(n72) );
  cby_1__config_group_mem_size36 cby_1__config_group_mem_size36 ( 
        .config_enable(config_enable[0]), .prog_reset(prog_reset[0]), 
        .prog_clk(prog_clk[0]), .ccff_head(ccff_head[0]), .mem_out({
        cb_mux_size6_0_sram, cb_mux_size6_1_sram, cb_mux_size6_2_sram, 
        cb_mux_size6_3_sram, cb_mux_size6_4_sram, cb_mux_size6_5_sram, 
        cb_mux_size6_6_sram, cb_mux_size6_7_sram, cb_mux_size6_8_sram, 
        cb_mux_size6_9_sram, cb_mux_size6_10_sram, cb_mux_size6_11_sram}), 
        .mem_outb({cb_mux_size6_0_sram_inv, cb_mux_size6_1_sram_inv, 
        cb_mux_size6_2_sram_inv, cb_mux_size6_3_sram_inv, 
        cb_mux_size6_4_sram_inv, cb_mux_size6_5_sram_inv, 
        cb_mux_size6_6_sram_inv, cb_mux_size6_7_sram_inv, 
        cb_mux_size6_8_sram_inv, cb_mux_size6_9_sram_inv, 
        cb_mux_size6_10_sram_inv, cb_mux_size6_11_sram_inv}), .ccff_tail(
        ccff_tail[0]) );
  INVD6BWP30P140HVT U1 ( .I(chany_top_in[21]), .ZN(n18) );
  INVD6BWP30P140HVT U2 ( .I(chany_top_in[16]), .ZN(n28) );
  INVD6BWP30P140HVT U3 ( .I(chany_top_in[20]), .ZN(n20) );
  INVD6BWP30P140HVT U4 ( .I(chany_top_in[22]), .ZN(n16) );
  INVD6BWP30P140HVT U5 ( .I(chany_top_in[15]), .ZN(n30) );
  INVD6BWP30P140HVT U6 ( .I(chany_top_in[18]), .ZN(n24) );
  INVD6BWP30P140HVT U7 ( .I(chany_top_in[14]), .ZN(n32) );
  INVD6BWP30P140HVT U8 ( .I(chany_top_in[13]), .ZN(n34) );
  INVD6BWP30P140HVT U9 ( .I(chany_top_in[17]), .ZN(n26) );
  INVD6BWP30P140HVT U10 ( .I(chany_top_in[12]), .ZN(n36) );
  INVD1BWP30P140HVT U11 ( .I(n14), .ZN(n37) );
  INVD1BWP30P140HVT U12 ( .I(n22), .ZN(n41) );
  INVD2BWP30P140HVT U13 ( .I(n32), .ZN(n46) );
  INVD2BWP30P140HVT U14 ( .I(n34), .ZN(n47) );
  INVD2BWP30P140HVT U15 ( .I(n28), .ZN(n44) );
  INVD2BWP30P140HVT U16 ( .I(n18), .ZN(n39) );
  INVD2BWP30P140HVT U17 ( .I(n24), .ZN(n42) );
  INVD2BWP30P140HVT U18 ( .I(n30), .ZN(n45) );
  INVD2BWP30P140HVT U19 ( .I(n26), .ZN(n43) );
  INVD2BWP30P140HVT U20 ( .I(n16), .ZN(n38) );
  INVD2BWP30P140HVT U21 ( .I(n36), .ZN(n48) );
  INVD2BWP30P140HVT U22 ( .I(n20), .ZN(n40) );
  BUFFD1BWP30P140HVT U23 ( .I(n48), .Z(chany_bottom_out[12]) );
  BUFFD1BWP30P140HVT U24 ( .I(n47), .Z(chany_bottom_out[13]) );
  BUFFD1BWP30P140HVT U25 ( .I(n46), .Z(chany_bottom_out[14]) );
  BUFFD1BWP30P140HVT U26 ( .I(n39), .Z(chany_bottom_out[21]) );
  BUFFD1BWP30P140HVT U27 ( .I(n40), .Z(chany_bottom_out[20]) );
  BUFFD1BWP30P140HVT U28 ( .I(n38), .Z(chany_bottom_out[22]) );
  BUFFD1BWP30P140HVT U29 ( .I(n37), .Z(chany_bottom_out[23]) );
  BUFFD1BWP30P140HVT U30 ( .I(n43), .Z(chany_bottom_out[17]) );
  BUFFD1BWP30P140HVT U31 ( .I(n42), .Z(chany_bottom_out[18]) );
  BUFFD1BWP30P140HVT U32 ( .I(n44), .Z(chany_bottom_out[16]) );
  BUFFD1BWP30P140HVT U33 ( .I(n45), .Z(chany_bottom_out[15]) );
  BUFFD1BWP30P140HVT U34 ( .I(n41), .Z(chany_bottom_out[19]) );
  INVD12BWP30P140HVT U35 ( .I(chany_top_in[19]), .ZN(n22) );
  INVD12BWP30P140HVT U36 ( .I(chany_top_in[23]), .ZN(n14) );
  BUFFD4BWP30P140HVT U37 ( .I(n72), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_25_[0]) );
  BUFFD4BWP30P140HVT U38 ( .I(n71), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_24_[0]) );
  BUFFD4BWP30P140HVT U39 ( .I(n70), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_23_[0]) );
  BUFFD4BWP30P140HVT U40 ( .I(n69), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_22_[0]) );
  BUFFD4BWP30P140HVT U41 ( .I(n68), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_21_[0]) );
  BUFFD4BWP30P140HVT U42 ( .I(n67), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_20_[0]) );
  BUFFD4BWP30P140HVT U43 ( .I(n66), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_19_[0]) );
  BUFFD4BWP30P140HVT U44 ( .I(n65), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_18_[0]) );
  BUFFD4BWP30P140HVT U45 ( .I(n64), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_17_[0]) );
  BUFFD4BWP30P140HVT U46 ( .I(n63), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_16_[0]) );
  BUFFD4BWP30P140HVT U47 ( .I(n62), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_15_[0]) );
  BUFFD4BWP30P140HVT U48 ( .I(n61), .Z(
        left_grid_right_width_0_height_0_subtile_0__pin_I_14_[0]) );
endmodule

