/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : Q-2019.12-SP4

/////////////////////////////////////////////////////////////


module cbx_0__cb_mux_size8 ( in, sram, sram_inv, out );
  input [0:7] in;
  input [0:3] sram;
  input [0:3] sram_inv;
  output [0:0] out;
  wire   n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21;

  INVD1BWP30P140HVT U12 ( .I(sram[1]), .ZN(n16) );
  AOI22D1BWP30P140HVT U13 ( .A1(sram[1]), .A2(in[5]), .B1(in[6]), .B2(n16), 
        .ZN(n15) );
  INVD1BWP30P140HVT U14 ( .I(sram[0]), .ZN(n11) );
  AOI22D1BWP30P140HVT U15 ( .A1(sram[0]), .A2(in[0]), .B1(in[1]), .B2(n11), 
        .ZN(n12) );
  ND2D1BWP30P140HVT U16 ( .A1(sram[1]), .A2(n12), .ZN(n13) );
  OAI211D1BWP30P140HVT U17 ( .A1(sram[1]), .A2(in[2]), .B(n13), .C(sram[3]), 
        .ZN(n14) );
  OAI21D1BWP30P140HVT U18 ( .A1(sram[3]), .A2(n15), .B(n14), .ZN(n21) );
  AOI22D1BWP30P140HVT U19 ( .A1(sram[1]), .A2(in[3]), .B1(in[4]), .B2(n16), 
        .ZN(n19) );
  ND2D1BWP30P140HVT U20 ( .A1(sram[1]), .A2(in[7]), .ZN(n18) );
  INVD1BWP30P140HVT U21 ( .I(sram[3]), .ZN(n17) );
  AOI221D1BWP30P140HVT U22 ( .A1(n19), .A2(sram[3]), .B1(n18), .B2(n17), .C(
        sram[2]), .ZN(n20) );
  AO21D1BWP30P140HVT U23 ( .A1(sram[2]), .A2(n21), .B(n20), .Z(out[0]) );
endmodule


module cbx_0__config_group_mem_size128 ( config_enable, prog_reset, prog_clk, 
        ccff_head, mem_out, mem_outb, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:0] ccff_head;
  output [0:127] mem_out;
  output [0:127] mem_outb;
  output [0:0] ccff_tail;
  wire   cb_mux_size8_mem_0_ccff_tail, cb_mux_size8_mem_1_ccff_tail,
         cb_mux_size8_mem_2_ccff_tail, cb_mux_size8_mem_3_ccff_tail,
         cb_mux_size8_mem_4_ccff_tail, cb_mux_size8_mem_5_ccff_tail,
         cb_mux_size8_mem_6_ccff_tail, cb_mux_size8_mem_7_ccff_tail,
         cb_mux_size8_mem_8_ccff_tail, cb_mux_size8_mem_9_ccff_tail,
         cb_mux_size8_mem_10_ccff_tail, cb_mux_size8_mem_11_ccff_tail,
         cb_mux_size8_mem_12_ccff_tail, cb_mux_size8_mem_13_ccff_tail,
         cb_mux_size8_mem_14_ccff_tail, cb_mux_size8_mem_15_ccff_tail,
         cb_mux_size8_mem_16_ccff_tail, cb_mux_size8_mem_17_ccff_tail,
         cb_mux_size8_mem_18_ccff_tail, cb_mux_size8_mem_19_ccff_tail,
         cb_mux_size8_mem_20_ccff_tail, cb_mux_size8_mem_21_ccff_tail,
         cb_mux_size8_mem_22_ccff_tail, cb_mux_size8_mem_23_ccff_tail,
         cb_mux_size8_mem_24_ccff_tail, cb_mux_size8_mem_25_ccff_tail,
         cb_mux_size8_mem_26_ccff_tail, cb_mux_size8_mem_27_ccff_tail,
         cb_mux_size8_mem_28_ccff_tail, cb_mux_size8_mem_29_ccff_tail,
         cb_mux_size8_mem_30_ccff_tail, mem_top_ipin_0_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_0_TSMC22ULP_CCFF_1_Q, mem_top_ipin_0_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_31_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_31_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_31_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_30_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_30_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_30_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_29_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_29_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_29_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_28_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_28_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_28_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_27_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_27_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_27_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_26_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_26_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_26_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_25_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_25_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_25_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_24_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_24_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_24_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_23_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_23_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_23_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_22_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_22_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_22_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_21_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_21_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_21_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_20_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_20_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_20_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_19_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_19_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_19_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_18_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_18_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_18_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_17_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_17_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_17_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_16_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_16_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_16_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_15_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_14_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_13_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_13_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_13_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_12_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_11_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_10_TSMC22ULP_CCFF_0_Q, mem_top_ipin_9_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_9_TSMC22ULP_CCFF_1_Q, mem_top_ipin_9_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_8_TSMC22ULP_CCFF_2_Q, mem_top_ipin_8_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_8_TSMC22ULP_CCFF_0_Q, mem_top_ipin_7_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_7_TSMC22ULP_CCFF_1_Q, mem_top_ipin_7_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_6_TSMC22ULP_CCFF_2_Q, mem_top_ipin_6_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_6_TSMC22ULP_CCFF_0_Q, mem_top_ipin_5_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_5_TSMC22ULP_CCFF_1_Q, mem_top_ipin_5_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_4_TSMC22ULP_CCFF_2_Q, mem_top_ipin_4_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_4_TSMC22ULP_CCFF_0_Q, mem_top_ipin_3_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_3_TSMC22ULP_CCFF_1_Q, mem_top_ipin_3_TSMC22ULP_CCFF_0_Q,
         mem_top_ipin_2_TSMC22ULP_CCFF_2_Q, mem_top_ipin_2_TSMC22ULP_CCFF_1_Q,
         mem_top_ipin_2_TSMC22ULP_CCFF_0_Q, mem_top_ipin_1_TSMC22ULP_CCFF_2_Q,
         mem_top_ipin_1_TSMC22ULP_CCFF_1_Q, mem_top_ipin_1_TSMC22ULP_CCFF_0_Q,
         eco_net, eco_net_0, eco_net_1_0, eco_net_2_0, eco_net_3_0,
         eco_net_4_0, eco_net_5_0, eco_net_6_0, eco_net_7_0, eco_net_8_0,
         eco_net_9_0, eco_net_10_0, eco_net_11_0, eco_net_12_0, eco_net_13_0,
         eco_net_14_0, eco_net_15_0, eco_net_16_0, eco_net_17_0, eco_net_18_0,
         eco_net_19_0, eco_net_20_0, eco_net_21_0, eco_net_22_0, eco_net_23_0,
         eco_net_24_0, eco_net_25_0, eco_net_26_0, eco_net_27_0, eco_net_28_0,
         eco_net_29_0, eco_net_30_0, eco_net_31_0, eco_net_32_0, eco_net_33_0,
         eco_net_34_0, eco_net_35_0, eco_net_36_0, eco_net_37_0, eco_net_38_0,
         eco_net_39_0, eco_net_40_0, eco_net_41_0, eco_net_42_0, eco_net_43_0,
         eco_net_44_0, eco_net_45_0, eco_net_46_0, eco_net_47_0, eco_net_48_0,
         eco_net_49_0, eco_net_50_0, eco_net_51_0, eco_net_52_0, eco_net_53_0,
         eco_net_54_0, eco_net_55_0, eco_net_56_0, eco_net_57_0, eco_net_58_0,
         eco_net_59_0, eco_net_60_0, eco_net_61_0, eco_net_62_0, eco_net_63_0,
         eco_net_64_0, eco_net_65_0, eco_net_66_0, eco_net_67_0, eco_net_68_0,
         eco_net_69_0, eco_net_70_0, eco_net_71_0, eco_net_72_0, eco_net_73_0,
         eco_net_74_0, eco_net_75_0, eco_net_76_0, eco_net_77_0, eco_net_78_0,
         eco_net_79_0, eco_net_80_0, eco_net_81_0, eco_net_82_0, eco_net_83_0,
         eco_net_84_0, eco_net_85_0, eco_net_86_0, eco_net_87_0, eco_net_88_0,
         eco_net_89_0, eco_net_90_0, eco_net_91_0, eco_net_92_0, eco_net_93_0,
         eco_net_94_0, eco_net_95_0, eco_net_96_0, eco_net_97_0, eco_net_98_0,
         eco_net_99_0, eco_net_100_0, eco_net_101_0, eco_net_102_0,
         eco_net_103_0, eco_net_104_0, eco_net_105_0, eco_net_106_0,
         eco_net_107_0, eco_net_108_0, eco_net_109_0, eco_net_110_0,
         eco_net_111_0, eco_net_112_0, eco_net_113_0, eco_net_114_0,
         eco_net_115_0, eco_net_116_0, eco_net_117_0, eco_net_118_0,
         eco_net_119_0, eco_net_120_0, eco_net_121_0, eco_net_122_0,
         eco_net_123_0, eco_net_124_0, eco_net_125_0, eco_net_126_0,
         eco_net_127_0, eco_net_128_0, eco_net_129_0, eco_net_130_0,
         eco_net_131_0, eco_net_132_0, eco_net_133_0, eco_net_134_0,
         eco_net_135_0, eco_net_136_0, eco_net_137_0, eco_net_138_0,
         eco_net_139_0, eco_net_140_0, eco_net_141_0;

  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_14_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_31_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_141_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        ccff_tail[0]) );
  DFCNQD1BWP30P140HVT mem_top_ipin_31_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_140_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_31_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_31_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_139_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_31_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_31_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_138_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_31_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_30_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_137_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_30_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_30_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_136_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_30_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_30_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_135_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_30_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_30_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_134_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_30_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_29_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_133_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_29_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_29_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_132_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_29_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_29_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_131_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_29_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_29_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_130_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_29_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_28_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_129_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_28_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_28_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_128_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_28_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_28_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_127_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_28_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_28_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_126_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_28_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_27_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_125_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_27_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_27_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_124_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_27_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_27_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_123_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_27_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_27_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_122_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_27_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_26_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_121_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_26_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_26_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_120_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_26_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_26_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_119_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_26_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_26_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_118_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_26_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_25_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_117_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_25_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_25_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_116_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_25_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_25_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_115_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_25_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_25_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_114_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_25_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_24_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_113_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        cb_mux_size8_mem_24_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_24_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_112_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_24_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_24_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_111_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_24_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_24_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_110_0), .CP(eco_net_2_0), .CDN(eco_net_7_0), .Q(
        mem_top_ipin_24_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_23_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_109_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_23_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_23_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_108_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_23_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_23_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_107_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_23_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_23_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_106_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_23_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_22_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_105_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_22_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_22_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_104_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_22_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_22_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_103_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_22_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_22_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_102_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_22_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_21_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_101_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_21_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_21_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_100_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_21_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_21_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_99_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_21_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_21_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_98_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_21_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_20_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_97_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_20_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_20_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_96_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_20_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_20_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_95_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_20_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_20_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_94_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_20_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_19_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_93_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_19_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_19_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_92_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_19_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_19_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_91_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_19_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_19_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_90_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_19_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_18_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_89_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_18_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_18_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_88_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_18_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_18_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_87_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_18_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_18_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_86_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_18_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_17_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_85_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_17_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_17_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_84_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_17_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_17_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_83_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_17_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_17_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_82_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_17_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_16_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_81_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        cb_mux_size8_mem_16_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_16_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_80_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_16_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_16_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_79_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_16_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_16_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_78_0), .CP(eco_net_1_0), .CDN(eco_net_6_0), .Q(
        mem_top_ipin_16_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_77_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_15_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_76_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_75_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_15_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_74_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_73_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_14_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_72_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_71_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_14_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_70_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_69_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_13_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_68_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_13_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_67_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_13_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_66_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_65_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_12_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_64_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_63_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_12_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_62_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_61_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_11_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_60_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_59_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_11_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_58_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_57_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_56_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_55_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_10_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_54_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_53_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_52_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_51_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_9_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_50_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_49_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        cb_mux_size8_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_48_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_47_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_8_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_46_0), .CP(eco_net_0), .CDN(eco_net_5_0), .Q(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_45_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_44_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_43_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_7_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_42_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_41_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_40_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_39_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_38_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_37_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_36_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_35_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_5_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_34_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_33_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_32_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_31_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_30_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_29_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_28_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_27_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_3_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_26_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_25_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_24_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_23_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_22_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_21_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_20_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_19_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_1_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_18_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_3__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_17_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        cb_mux_size8_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_2__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_16_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q) );
  DFCNQD1BWP30P140HVT mem_top_ipin_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_15_0), .CP(eco_net), .CDN(eco_net_4_0), .Q(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q) );
  ND2D1BWP30P140HVT U257 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_31_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[126]) );
  INVD1BWP30P140HVT U258 ( .I(mem_outb[126]), .ZN(mem_out[126]) );
  ND2D1BWP30P140HVT U259 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_31_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[125]) );
  INVD1BWP30P140HVT U260 ( .I(mem_outb[125]), .ZN(mem_out[125]) );
  ND2D1BWP30P140HVT U261 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_31_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[124]) );
  INVD1BWP30P140HVT U262 ( .I(mem_outb[124]), .ZN(mem_out[124]) );
  ND2D1BWP30P140HVT U263 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_30_ccff_tail), .ZN(mem_outb[123]) );
  INVD1BWP30P140HVT U264 ( .I(mem_outb[123]), .ZN(mem_out[123]) );
  ND2D1BWP30P140HVT U265 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_30_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[122]) );
  INVD1BWP30P140HVT U266 ( .I(mem_outb[122]), .ZN(mem_out[122]) );
  ND2D1BWP30P140HVT U267 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_30_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[121]) );
  INVD1BWP30P140HVT U268 ( .I(mem_outb[121]), .ZN(mem_out[121]) );
  ND2D1BWP30P140HVT U269 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_30_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[120]) );
  INVD1BWP30P140HVT U270 ( .I(mem_outb[120]), .ZN(mem_out[120]) );
  ND2D1BWP30P140HVT U271 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_29_ccff_tail), .ZN(mem_outb[119]) );
  INVD1BWP30P140HVT U272 ( .I(mem_outb[119]), .ZN(mem_out[119]) );
  ND2D1BWP30P140HVT U273 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_29_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[118]) );
  INVD1BWP30P140HVT U274 ( .I(mem_outb[118]), .ZN(mem_out[118]) );
  ND2D1BWP30P140HVT U275 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_29_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[117]) );
  INVD1BWP30P140HVT U276 ( .I(mem_outb[117]), .ZN(mem_out[117]) );
  ND2D1BWP30P140HVT U277 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_29_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[116]) );
  INVD1BWP30P140HVT U278 ( .I(mem_outb[116]), .ZN(mem_out[116]) );
  ND2D1BWP30P140HVT U279 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_28_ccff_tail), .ZN(mem_outb[115]) );
  INVD1BWP30P140HVT U280 ( .I(mem_outb[115]), .ZN(mem_out[115]) );
  ND2D1BWP30P140HVT U281 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_28_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[114]) );
  INVD1BWP30P140HVT U282 ( .I(mem_outb[114]), .ZN(mem_out[114]) );
  ND2D1BWP30P140HVT U283 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_28_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[113]) );
  INVD1BWP30P140HVT U284 ( .I(mem_outb[113]), .ZN(mem_out[113]) );
  ND2D1BWP30P140HVT U285 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_28_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[112]) );
  INVD1BWP30P140HVT U286 ( .I(mem_outb[112]), .ZN(mem_out[112]) );
  ND2D1BWP30P140HVT U287 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_27_ccff_tail), .ZN(mem_outb[111]) );
  INVD1BWP30P140HVT U288 ( .I(mem_outb[111]), .ZN(mem_out[111]) );
  ND2D1BWP30P140HVT U289 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_27_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[110]) );
  INVD1BWP30P140HVT U290 ( .I(mem_outb[110]), .ZN(mem_out[110]) );
  ND2D1BWP30P140HVT U291 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_27_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[109]) );
  INVD1BWP30P140HVT U292 ( .I(mem_outb[109]), .ZN(mem_out[109]) );
  ND2D1BWP30P140HVT U293 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_27_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[108]) );
  INVD1BWP30P140HVT U294 ( .I(mem_outb[108]), .ZN(mem_out[108]) );
  ND2D1BWP30P140HVT U295 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_26_ccff_tail), .ZN(mem_outb[107]) );
  INVD1BWP30P140HVT U296 ( .I(mem_outb[107]), .ZN(mem_out[107]) );
  ND2D1BWP30P140HVT U297 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_26_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[106]) );
  INVD1BWP30P140HVT U298 ( .I(mem_outb[106]), .ZN(mem_out[106]) );
  ND2D1BWP30P140HVT U299 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_26_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[105]) );
  INVD1BWP30P140HVT U300 ( .I(mem_outb[105]), .ZN(mem_out[105]) );
  ND2D1BWP30P140HVT U301 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_26_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[104]) );
  INVD1BWP30P140HVT U302 ( .I(mem_outb[104]), .ZN(mem_out[104]) );
  ND2D1BWP30P140HVT U303 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_25_ccff_tail), .ZN(mem_outb[103]) );
  INVD1BWP30P140HVT U304 ( .I(mem_outb[103]), .ZN(mem_out[103]) );
  ND2D1BWP30P140HVT U305 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_25_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[102]) );
  INVD1BWP30P140HVT U306 ( .I(mem_outb[102]), .ZN(mem_out[102]) );
  ND2D1BWP30P140HVT U307 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_25_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[101]) );
  INVD1BWP30P140HVT U308 ( .I(mem_outb[101]), .ZN(mem_out[101]) );
  ND2D1BWP30P140HVT U309 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_25_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[100]) );
  INVD1BWP30P140HVT U310 ( .I(mem_outb[100]), .ZN(mem_out[100]) );
  ND2D1BWP30P140HVT U311 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_24_ccff_tail), .ZN(mem_outb[99]) );
  INVD1BWP30P140HVT U312 ( .I(mem_outb[99]), .ZN(mem_out[99]) );
  ND2D1BWP30P140HVT U313 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_24_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[98]) );
  INVD1BWP30P140HVT U314 ( .I(mem_outb[98]), .ZN(mem_out[98]) );
  ND2D1BWP30P140HVT U315 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_24_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[97]) );
  INVD1BWP30P140HVT U316 ( .I(mem_outb[97]), .ZN(mem_out[97]) );
  ND2D1BWP30P140HVT U317 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_24_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[96]) );
  INVD1BWP30P140HVT U318 ( .I(mem_outb[96]), .ZN(mem_out[96]) );
  ND2D1BWP30P140HVT U319 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_23_ccff_tail), .ZN(mem_outb[95]) );
  INVD1BWP30P140HVT U320 ( .I(mem_outb[95]), .ZN(mem_out[95]) );
  ND2D1BWP30P140HVT U321 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_23_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[94]) );
  INVD1BWP30P140HVT U322 ( .I(mem_outb[94]), .ZN(mem_out[94]) );
  ND2D1BWP30P140HVT U323 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_23_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[93]) );
  INVD1BWP30P140HVT U324 ( .I(mem_outb[93]), .ZN(mem_out[93]) );
  ND2D1BWP30P140HVT U325 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_23_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[92]) );
  INVD1BWP30P140HVT U326 ( .I(mem_outb[92]), .ZN(mem_out[92]) );
  ND2D1BWP30P140HVT U327 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_22_ccff_tail), .ZN(mem_outb[91]) );
  INVD1BWP30P140HVT U328 ( .I(mem_outb[91]), .ZN(mem_out[91]) );
  ND2D1BWP30P140HVT U329 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_22_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[90]) );
  INVD1BWP30P140HVT U330 ( .I(mem_outb[90]), .ZN(mem_out[90]) );
  ND2D1BWP30P140HVT U331 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_22_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[89]) );
  INVD1BWP30P140HVT U332 ( .I(mem_outb[89]), .ZN(mem_out[89]) );
  ND2D1BWP30P140HVT U333 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_22_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[88]) );
  INVD1BWP30P140HVT U334 ( .I(mem_outb[88]), .ZN(mem_out[88]) );
  ND2D1BWP30P140HVT U335 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_21_ccff_tail), .ZN(mem_outb[87]) );
  INVD1BWP30P140HVT U336 ( .I(mem_outb[87]), .ZN(mem_out[87]) );
  ND2D1BWP30P140HVT U337 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_21_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[86]) );
  INVD1BWP30P140HVT U338 ( .I(mem_outb[86]), .ZN(mem_out[86]) );
  ND2D1BWP30P140HVT U339 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_21_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[85]) );
  INVD1BWP30P140HVT U340 ( .I(mem_outb[85]), .ZN(mem_out[85]) );
  ND2D1BWP30P140HVT U341 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_21_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[84]) );
  INVD1BWP30P140HVT U342 ( .I(mem_outb[84]), .ZN(mem_out[84]) );
  ND2D1BWP30P140HVT U343 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_20_ccff_tail), .ZN(mem_outb[83]) );
  INVD1BWP30P140HVT U344 ( .I(mem_outb[83]), .ZN(mem_out[83]) );
  ND2D1BWP30P140HVT U345 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_20_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[82]) );
  INVD1BWP30P140HVT U346 ( .I(mem_outb[82]), .ZN(mem_out[82]) );
  ND2D1BWP30P140HVT U347 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_20_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[81]) );
  INVD1BWP30P140HVT U348 ( .I(mem_outb[81]), .ZN(mem_out[81]) );
  ND2D1BWP30P140HVT U349 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_20_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[80]) );
  INVD1BWP30P140HVT U350 ( .I(mem_outb[80]), .ZN(mem_out[80]) );
  ND2D1BWP30P140HVT U351 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_19_ccff_tail), .ZN(mem_outb[79]) );
  INVD1BWP30P140HVT U352 ( .I(mem_outb[79]), .ZN(mem_out[79]) );
  ND2D1BWP30P140HVT U353 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_19_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[78]) );
  INVD1BWP30P140HVT U354 ( .I(mem_outb[78]), .ZN(mem_out[78]) );
  ND2D1BWP30P140HVT U355 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_19_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[77]) );
  INVD1BWP30P140HVT U356 ( .I(mem_outb[77]), .ZN(mem_out[77]) );
  ND2D1BWP30P140HVT U357 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_19_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[76]) );
  INVD1BWP30P140HVT U358 ( .I(mem_outb[76]), .ZN(mem_out[76]) );
  ND2D1BWP30P140HVT U359 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_18_ccff_tail), .ZN(mem_outb[75]) );
  INVD1BWP30P140HVT U360 ( .I(mem_outb[75]), .ZN(mem_out[75]) );
  ND2D1BWP30P140HVT U361 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_18_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[74]) );
  INVD1BWP30P140HVT U362 ( .I(mem_outb[74]), .ZN(mem_out[74]) );
  ND2D1BWP30P140HVT U363 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_18_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[73]) );
  INVD1BWP30P140HVT U364 ( .I(mem_outb[73]), .ZN(mem_out[73]) );
  ND2D1BWP30P140HVT U365 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_18_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[72]) );
  INVD1BWP30P140HVT U366 ( .I(mem_outb[72]), .ZN(mem_out[72]) );
  ND2D1BWP30P140HVT U367 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_17_ccff_tail), .ZN(mem_outb[71]) );
  INVD1BWP30P140HVT U368 ( .I(mem_outb[71]), .ZN(mem_out[71]) );
  ND2D1BWP30P140HVT U369 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_17_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[70]) );
  INVD1BWP30P140HVT U370 ( .I(mem_outb[70]), .ZN(mem_out[70]) );
  ND2D1BWP30P140HVT U371 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_17_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[69]) );
  INVD1BWP30P140HVT U372 ( .I(mem_outb[69]), .ZN(mem_out[69]) );
  ND2D1BWP30P140HVT U373 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_17_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[68]) );
  INVD1BWP30P140HVT U374 ( .I(mem_outb[68]), .ZN(mem_out[68]) );
  ND2D1BWP30P140HVT U375 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_16_ccff_tail), .ZN(mem_outb[67]) );
  INVD1BWP30P140HVT U376 ( .I(mem_outb[67]), .ZN(mem_out[67]) );
  ND2D1BWP30P140HVT U377 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_16_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[66]) );
  INVD1BWP30P140HVT U378 ( .I(mem_outb[66]), .ZN(mem_out[66]) );
  ND2D1BWP30P140HVT U379 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_16_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[65]) );
  INVD1BWP30P140HVT U380 ( .I(mem_outb[65]), .ZN(mem_out[65]) );
  ND2D1BWP30P140HVT U381 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_16_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[64]) );
  INVD1BWP30P140HVT U382 ( .I(mem_outb[64]), .ZN(mem_out[64]) );
  ND2D1BWP30P140HVT U383 ( .A1(config_enable[0]), .A2(ccff_tail[0]), .ZN(
        mem_outb[127]) );
  INVD1BWP30P140HVT U384 ( .I(mem_outb[127]), .ZN(mem_out[127]) );
  ND2D1BWP30P140HVT U385 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_15_ccff_tail), .ZN(mem_outb[63]) );
  INVD1BWP30P140HVT U386 ( .I(mem_outb[63]), .ZN(mem_out[63]) );
  ND2D1BWP30P140HVT U387 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[62]) );
  INVD1BWP30P140HVT U388 ( .I(mem_outb[62]), .ZN(mem_out[62]) );
  ND2D1BWP30P140HVT U389 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[61]) );
  INVD1BWP30P140HVT U390 ( .I(mem_outb[61]), .ZN(mem_out[61]) );
  ND2D1BWP30P140HVT U391 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[60]) );
  INVD1BWP30P140HVT U392 ( .I(mem_outb[60]), .ZN(mem_out[60]) );
  ND2D1BWP30P140HVT U393 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_14_ccff_tail), .ZN(mem_outb[59]) );
  INVD1BWP30P140HVT U394 ( .I(mem_outb[59]), .ZN(mem_out[59]) );
  ND2D1BWP30P140HVT U395 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[58]) );
  INVD1BWP30P140HVT U396 ( .I(mem_outb[58]), .ZN(mem_out[58]) );
  ND2D1BWP30P140HVT U397 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[57]) );
  INVD1BWP30P140HVT U398 ( .I(mem_outb[57]), .ZN(mem_out[57]) );
  ND2D1BWP30P140HVT U399 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[56]) );
  INVD1BWP30P140HVT U400 ( .I(mem_outb[56]), .ZN(mem_out[56]) );
  ND2D1BWP30P140HVT U401 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_13_ccff_tail), .ZN(mem_outb[55]) );
  INVD1BWP30P140HVT U402 ( .I(mem_outb[55]), .ZN(mem_out[55]) );
  ND2D1BWP30P140HVT U403 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_13_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[54]) );
  INVD1BWP30P140HVT U404 ( .I(mem_outb[54]), .ZN(mem_out[54]) );
  ND2D1BWP30P140HVT U405 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[53]) );
  INVD1BWP30P140HVT U406 ( .I(mem_outb[53]), .ZN(mem_out[53]) );
  ND2D1BWP30P140HVT U407 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[52]) );
  INVD1BWP30P140HVT U408 ( .I(mem_outb[52]), .ZN(mem_out[52]) );
  ND2D1BWP30P140HVT U409 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_12_ccff_tail), .ZN(mem_outb[51]) );
  INVD1BWP30P140HVT U410 ( .I(mem_outb[51]), .ZN(mem_out[51]) );
  ND2D1BWP30P140HVT U411 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[50]) );
  INVD1BWP30P140HVT U412 ( .I(mem_outb[50]), .ZN(mem_out[50]) );
  ND2D1BWP30P140HVT U413 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[49]) );
  INVD1BWP30P140HVT U414 ( .I(mem_outb[49]), .ZN(mem_out[49]) );
  ND2D1BWP30P140HVT U415 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[48]) );
  INVD1BWP30P140HVT U416 ( .I(mem_outb[48]), .ZN(mem_out[48]) );
  ND2D1BWP30P140HVT U417 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_11_ccff_tail), .ZN(mem_outb[47]) );
  INVD1BWP30P140HVT U418 ( .I(mem_outb[47]), .ZN(mem_out[47]) );
  ND2D1BWP30P140HVT U419 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[46]) );
  INVD1BWP30P140HVT U420 ( .I(mem_outb[46]), .ZN(mem_out[46]) );
  ND2D1BWP30P140HVT U421 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[45]) );
  INVD1BWP30P140HVT U422 ( .I(mem_outb[45]), .ZN(mem_out[45]) );
  ND2D1BWP30P140HVT U423 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[44]) );
  INVD1BWP30P140HVT U424 ( .I(mem_outb[44]), .ZN(mem_out[44]) );
  ND2D1BWP30P140HVT U425 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_10_ccff_tail), .ZN(mem_outb[43]) );
  INVD1BWP30P140HVT U426 ( .I(mem_outb[43]), .ZN(mem_out[43]) );
  ND2D1BWP30P140HVT U427 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[42]) );
  INVD1BWP30P140HVT U428 ( .I(mem_outb[42]), .ZN(mem_out[42]) );
  ND2D1BWP30P140HVT U429 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[41]) );
  INVD1BWP30P140HVT U430 ( .I(mem_outb[41]), .ZN(mem_out[41]) );
  ND2D1BWP30P140HVT U431 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[40]) );
  INVD1BWP30P140HVT U432 ( .I(mem_outb[40]), .ZN(mem_out[40]) );
  ND2D1BWP30P140HVT U433 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_9_ccff_tail), .ZN(mem_outb[39]) );
  INVD1BWP30P140HVT U434 ( .I(mem_outb[39]), .ZN(mem_out[39]) );
  ND2D1BWP30P140HVT U435 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[38]) );
  INVD1BWP30P140HVT U436 ( .I(mem_outb[38]), .ZN(mem_out[38]) );
  ND2D1BWP30P140HVT U437 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[37]) );
  INVD1BWP30P140HVT U438 ( .I(mem_outb[37]), .ZN(mem_out[37]) );
  ND2D1BWP30P140HVT U439 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[36]) );
  INVD1BWP30P140HVT U440 ( .I(mem_outb[36]), .ZN(mem_out[36]) );
  ND2D1BWP30P140HVT U441 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_8_ccff_tail), .ZN(mem_outb[35]) );
  INVD1BWP30P140HVT U442 ( .I(mem_outb[35]), .ZN(mem_out[35]) );
  ND2D1BWP30P140HVT U443 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[34]) );
  INVD1BWP30P140HVT U444 ( .I(mem_outb[34]), .ZN(mem_out[34]) );
  ND2D1BWP30P140HVT U445 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[33]) );
  INVD1BWP30P140HVT U446 ( .I(mem_outb[33]), .ZN(mem_out[33]) );
  ND2D1BWP30P140HVT U447 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[32]) );
  INVD1BWP30P140HVT U448 ( .I(mem_outb[32]), .ZN(mem_out[32]) );
  ND2D1BWP30P140HVT U449 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_7_ccff_tail), .ZN(mem_outb[31]) );
  INVD1BWP30P140HVT U450 ( .I(mem_outb[31]), .ZN(mem_out[31]) );
  ND2D1BWP30P140HVT U451 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[30]) );
  INVD1BWP30P140HVT U452 ( .I(mem_outb[30]), .ZN(mem_out[30]) );
  ND2D1BWP30P140HVT U453 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[29]) );
  INVD1BWP30P140HVT U454 ( .I(mem_outb[29]), .ZN(mem_out[29]) );
  ND2D1BWP30P140HVT U455 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[28]) );
  INVD1BWP30P140HVT U456 ( .I(mem_outb[28]), .ZN(mem_out[28]) );
  ND2D1BWP30P140HVT U457 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_6_ccff_tail), .ZN(mem_outb[27]) );
  INVD1BWP30P140HVT U458 ( .I(mem_outb[27]), .ZN(mem_out[27]) );
  ND2D1BWP30P140HVT U459 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[26]) );
  INVD1BWP30P140HVT U460 ( .I(mem_outb[26]), .ZN(mem_out[26]) );
  ND2D1BWP30P140HVT U461 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[25]) );
  INVD1BWP30P140HVT U462 ( .I(mem_outb[25]), .ZN(mem_out[25]) );
  ND2D1BWP30P140HVT U463 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[24]) );
  INVD1BWP30P140HVT U464 ( .I(mem_outb[24]), .ZN(mem_out[24]) );
  ND2D1BWP30P140HVT U465 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_5_ccff_tail), .ZN(mem_outb[23]) );
  INVD1BWP30P140HVT U466 ( .I(mem_outb[23]), .ZN(mem_out[23]) );
  ND2D1BWP30P140HVT U467 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[22]) );
  INVD1BWP30P140HVT U468 ( .I(mem_outb[22]), .ZN(mem_out[22]) );
  ND2D1BWP30P140HVT U469 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[21]) );
  INVD1BWP30P140HVT U470 ( .I(mem_outb[21]), .ZN(mem_out[21]) );
  ND2D1BWP30P140HVT U471 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[20]) );
  INVD1BWP30P140HVT U472 ( .I(mem_outb[20]), .ZN(mem_out[20]) );
  ND2D1BWP30P140HVT U473 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_4_ccff_tail), .ZN(mem_outb[19]) );
  INVD1BWP30P140HVT U474 ( .I(mem_outb[19]), .ZN(mem_out[19]) );
  ND2D1BWP30P140HVT U475 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[18]) );
  INVD1BWP30P140HVT U476 ( .I(mem_outb[18]), .ZN(mem_out[18]) );
  ND2D1BWP30P140HVT U477 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[17]) );
  INVD1BWP30P140HVT U478 ( .I(mem_outb[17]), .ZN(mem_out[17]) );
  ND2D1BWP30P140HVT U479 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[16]) );
  INVD1BWP30P140HVT U480 ( .I(mem_outb[16]), .ZN(mem_out[16]) );
  ND2D1BWP30P140HVT U481 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_3_ccff_tail), .ZN(mem_outb[15]) );
  INVD1BWP30P140HVT U482 ( .I(mem_outb[15]), .ZN(mem_out[15]) );
  ND2D1BWP30P140HVT U483 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[14]) );
  INVD1BWP30P140HVT U484 ( .I(mem_outb[14]), .ZN(mem_out[14]) );
  ND2D1BWP30P140HVT U485 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[13]) );
  INVD1BWP30P140HVT U486 ( .I(mem_outb[13]), .ZN(mem_out[13]) );
  ND2D1BWP30P140HVT U487 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[12]) );
  INVD1BWP30P140HVT U488 ( .I(mem_outb[12]), .ZN(mem_out[12]) );
  ND2D1BWP30P140HVT U489 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_2_ccff_tail), .ZN(mem_outb[11]) );
  INVD1BWP30P140HVT U490 ( .I(mem_outb[11]), .ZN(mem_out[11]) );
  ND2D1BWP30P140HVT U491 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[10]) );
  INVD1BWP30P140HVT U492 ( .I(mem_outb[10]), .ZN(mem_out[10]) );
  ND2D1BWP30P140HVT U493 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[9]) );
  INVD1BWP30P140HVT U494 ( .I(mem_outb[9]), .ZN(mem_out[9]) );
  ND2D1BWP30P140HVT U495 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[8]) );
  INVD1BWP30P140HVT U496 ( .I(mem_outb[8]), .ZN(mem_out[8]) );
  ND2D1BWP30P140HVT U497 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_1_ccff_tail), .ZN(mem_outb[7]) );
  INVD1BWP30P140HVT U498 ( .I(mem_outb[7]), .ZN(mem_out[7]) );
  ND2D1BWP30P140HVT U499 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[6]) );
  INVD1BWP30P140HVT U500 ( .I(mem_outb[6]), .ZN(mem_out[6]) );
  ND2D1BWP30P140HVT U501 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[5]) );
  INVD1BWP30P140HVT U502 ( .I(mem_outb[5]), .ZN(mem_out[5]) );
  ND2D1BWP30P140HVT U503 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[4]) );
  INVD1BWP30P140HVT U504 ( .I(mem_outb[4]), .ZN(mem_out[4]) );
  ND2D1BWP30P140HVT U505 ( .A1(config_enable[0]), .A2(
        cb_mux_size8_mem_0_ccff_tail), .ZN(mem_outb[3]) );
  INVD1BWP30P140HVT U506 ( .I(mem_outb[3]), .ZN(mem_out[3]) );
  ND2D1BWP30P140HVT U507 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q), .ZN(mem_outb[2]) );
  INVD1BWP30P140HVT U508 ( .I(mem_outb[2]), .ZN(mem_out[2]) );
  ND2D1BWP30P140HVT U509 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q), .ZN(mem_outb[1]) );
  INVD1BWP30P140HVT U510 ( .I(mem_outb[1]), .ZN(mem_out[1]) );
  ND2D1BWP30P140HVT U511 ( .A1(config_enable[0]), .A2(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[0]) );
  INVD1BWP30P140HVT U512 ( .I(mem_outb[0]), .ZN(mem_out[0]) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_cp_buf2 ( .I(eco_net_3_0), .Z(eco_net) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cp_buf2 ( .I(eco_net_3_0), .Z(eco_net_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_23_cp_buf2 ( .I(eco_net_3_0), .Z(eco_net_1_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_cp_buf2 ( .I(eco_net_3_0), .Z(eco_net_2_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_cp_buf1 ( .I(prog_clk[0]), .Z(eco_net_3_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_cdn_buf2 ( .I(eco_net_8_0), .Z(eco_net_4_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_cdn_buf2 ( .I(eco_net_8_0), .Z(
        eco_net_5_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_23_cdn_buf2 ( .I(eco_net_8_0), .Z(
        eco_net_6_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_cdn_buf2 ( .I(eco_net_8_0), .Z(
        eco_net_7_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_cdn_buf1 ( .I(prog_reset[0]), .Z(
        eco_net_8_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del1 ( .I(ccff_head[0]), .Z(eco_net_9_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del2 ( .I(eco_net_9_0), .Z(eco_net_10_0)
         );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del2 ( .I(cb_mux_size8_mem_7_ccff_tail), 
        .Z(eco_net_11_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_16_del2 ( .I(cb_mux_size8_mem_15_ccff_tail), 
        .Z(eco_net_12_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_24_del2 ( .I(cb_mux_size8_mem_23_ccff_tail), 
        .Z(eco_net_13_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_0 ( .I(eco_net_10_0), .Z(eco_net_14_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_1 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_15_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_2 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_1_Q), .Z(eco_net_16_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_0_del3_3 ( .I(
        mem_top_ipin_0_TSMC22ULP_CCFF_2_Q), .Z(eco_net_17_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_0 ( .I(cb_mux_size8_mem_0_ccff_tail), 
        .Z(eco_net_18_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_1 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_0_Q), .Z(eco_net_19_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_2 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_1_Q), .Z(eco_net_20_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_1_del3_3 ( .I(
        mem_top_ipin_1_TSMC22ULP_CCFF_2_Q), .Z(eco_net_21_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_0 ( .I(cb_mux_size8_mem_1_ccff_tail), 
        .Z(eco_net_22_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_1 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_23_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_2 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_1_Q), .Z(eco_net_24_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_2_del3_3 ( .I(
        mem_top_ipin_2_TSMC22ULP_CCFF_2_Q), .Z(eco_net_25_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_0 ( .I(cb_mux_size8_mem_2_ccff_tail), 
        .Z(eco_net_26_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_1 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_0_Q), .Z(eco_net_27_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_2 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_1_Q), .Z(eco_net_28_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_3_del3_3 ( .I(
        mem_top_ipin_3_TSMC22ULP_CCFF_2_Q), .Z(eco_net_29_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_0 ( .I(cb_mux_size8_mem_3_ccff_tail), 
        .Z(eco_net_30_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_1 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_31_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_2 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_1_Q), .Z(eco_net_32_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_4_del3_3 ( .I(
        mem_top_ipin_4_TSMC22ULP_CCFF_2_Q), .Z(eco_net_33_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_0 ( .I(cb_mux_size8_mem_4_ccff_tail), 
        .Z(eco_net_34_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_1 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_0_Q), .Z(eco_net_35_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_2 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_1_Q), .Z(eco_net_36_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_5_del3_3 ( .I(
        mem_top_ipin_5_TSMC22ULP_CCFF_2_Q), .Z(eco_net_37_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_0 ( .I(cb_mux_size8_mem_5_ccff_tail), 
        .Z(eco_net_38_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_1 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_39_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_2 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_1_Q), .Z(eco_net_40_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_6_del3_3 ( .I(
        mem_top_ipin_6_TSMC22ULP_CCFF_2_Q), .Z(eco_net_41_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_0 ( .I(cb_mux_size8_mem_6_ccff_tail), 
        .Z(eco_net_42_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_1 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_0_Q), .Z(eco_net_43_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_2 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_1_Q), .Z(eco_net_44_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_7_del3_3 ( .I(
        mem_top_ipin_7_TSMC22ULP_CCFF_2_Q), .Z(eco_net_45_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_0 ( .I(eco_net_11_0), .Z(eco_net_46_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_1 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_0_Q), .Z(eco_net_47_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_2 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_1_Q), .Z(eco_net_48_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_8_del3_3 ( .I(
        mem_top_ipin_8_TSMC22ULP_CCFF_2_Q), .Z(eco_net_49_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_0 ( .I(cb_mux_size8_mem_8_ccff_tail), 
        .Z(eco_net_50_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_1 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_0_Q), .Z(eco_net_51_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_2 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_1_Q), .Z(eco_net_52_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_9_del3_3 ( .I(
        mem_top_ipin_9_TSMC22ULP_CCFF_2_Q), .Z(eco_net_53_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_0 ( .I(cb_mux_size8_mem_9_ccff_tail), 
        .Z(eco_net_54_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_1 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_0_Q), .Z(eco_net_55_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_2 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_1_Q), .Z(eco_net_56_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_10_del3_3 ( .I(
        mem_top_ipin_10_TSMC22ULP_CCFF_2_Q), .Z(eco_net_57_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_0 ( .I(cb_mux_size8_mem_10_ccff_tail), .Z(eco_net_58_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_1 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_0_Q), .Z(eco_net_59_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_2 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_1_Q), .Z(eco_net_60_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_11_del3_3 ( .I(
        mem_top_ipin_11_TSMC22ULP_CCFF_2_Q), .Z(eco_net_61_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_0 ( .I(cb_mux_size8_mem_11_ccff_tail), .Z(eco_net_62_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_1 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_0_Q), .Z(eco_net_63_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_2 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_1_Q), .Z(eco_net_64_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_12_del3_3 ( .I(
        mem_top_ipin_12_TSMC22ULP_CCFF_2_Q), .Z(eco_net_65_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_0 ( .I(cb_mux_size8_mem_12_ccff_tail), .Z(eco_net_66_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_1 ( .I(
        mem_top_ipin_13_TSMC22ULP_CCFF_0_Q), .Z(eco_net_67_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_2 ( .I(
        mem_top_ipin_13_TSMC22ULP_CCFF_1_Q), .Z(eco_net_68_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_13_del3_3 ( .I(
        mem_top_ipin_13_TSMC22ULP_CCFF_2_Q), .Z(eco_net_69_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_0 ( .I(cb_mux_size8_mem_13_ccff_tail), .Z(eco_net_70_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_1 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_0_Q), .Z(eco_net_71_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_2 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_1_Q), .Z(eco_net_72_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_14_del3_3 ( .I(
        mem_top_ipin_14_TSMC22ULP_CCFF_2_Q), .Z(eco_net_73_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_0 ( .I(cb_mux_size8_mem_14_ccff_tail), .Z(eco_net_74_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_1 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_0_Q), .Z(eco_net_75_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_2 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_1_Q), .Z(eco_net_76_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_15_del3_3 ( .I(
        mem_top_ipin_15_TSMC22ULP_CCFF_2_Q), .Z(eco_net_77_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_16_del3_0 ( .I(eco_net_12_0), .Z(
        eco_net_78_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_16_del3_1 ( .I(
        mem_top_ipin_16_TSMC22ULP_CCFF_0_Q), .Z(eco_net_79_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_16_del3_2 ( .I(
        mem_top_ipin_16_TSMC22ULP_CCFF_1_Q), .Z(eco_net_80_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_16_del3_3 ( .I(
        mem_top_ipin_16_TSMC22ULP_CCFF_2_Q), .Z(eco_net_81_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_17_del3_0 ( .I(cb_mux_size8_mem_16_ccff_tail), .Z(eco_net_82_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_17_del3_1 ( .I(
        mem_top_ipin_17_TSMC22ULP_CCFF_0_Q), .Z(eco_net_83_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_17_del3_2 ( .I(
        mem_top_ipin_17_TSMC22ULP_CCFF_1_Q), .Z(eco_net_84_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_17_del3_3 ( .I(
        mem_top_ipin_17_TSMC22ULP_CCFF_2_Q), .Z(eco_net_85_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_18_del3_0 ( .I(cb_mux_size8_mem_17_ccff_tail), .Z(eco_net_86_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_18_del3_1 ( .I(
        mem_top_ipin_18_TSMC22ULP_CCFF_0_Q), .Z(eco_net_87_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_18_del3_2 ( .I(
        mem_top_ipin_18_TSMC22ULP_CCFF_1_Q), .Z(eco_net_88_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_18_del3_3 ( .I(
        mem_top_ipin_18_TSMC22ULP_CCFF_2_Q), .Z(eco_net_89_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_19_del3_0 ( .I(cb_mux_size8_mem_18_ccff_tail), .Z(eco_net_90_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_19_del3_1 ( .I(
        mem_top_ipin_19_TSMC22ULP_CCFF_0_Q), .Z(eco_net_91_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_19_del3_2 ( .I(
        mem_top_ipin_19_TSMC22ULP_CCFF_1_Q), .Z(eco_net_92_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_19_del3_3 ( .I(
        mem_top_ipin_19_TSMC22ULP_CCFF_2_Q), .Z(eco_net_93_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_20_del3_0 ( .I(cb_mux_size8_mem_19_ccff_tail), .Z(eco_net_94_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_20_del3_1 ( .I(
        mem_top_ipin_20_TSMC22ULP_CCFF_0_Q), .Z(eco_net_95_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_20_del3_2 ( .I(
        mem_top_ipin_20_TSMC22ULP_CCFF_1_Q), .Z(eco_net_96_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_20_del3_3 ( .I(
        mem_top_ipin_20_TSMC22ULP_CCFF_2_Q), .Z(eco_net_97_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_21_del3_0 ( .I(cb_mux_size8_mem_20_ccff_tail), .Z(eco_net_98_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_21_del3_1 ( .I(
        mem_top_ipin_21_TSMC22ULP_CCFF_0_Q), .Z(eco_net_99_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_21_del3_2 ( .I(
        mem_top_ipin_21_TSMC22ULP_CCFF_1_Q), .Z(eco_net_100_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_21_del3_3 ( .I(
        mem_top_ipin_21_TSMC22ULP_CCFF_2_Q), .Z(eco_net_101_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_22_del3_0 ( .I(cb_mux_size8_mem_21_ccff_tail), .Z(eco_net_102_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_22_del3_1 ( .I(
        mem_top_ipin_22_TSMC22ULP_CCFF_0_Q), .Z(eco_net_103_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_22_del3_2 ( .I(
        mem_top_ipin_22_TSMC22ULP_CCFF_1_Q), .Z(eco_net_104_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_22_del3_3 ( .I(
        mem_top_ipin_22_TSMC22ULP_CCFF_2_Q), .Z(eco_net_105_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_23_del3_0 ( .I(cb_mux_size8_mem_22_ccff_tail), .Z(eco_net_106_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_23_del3_1 ( .I(
        mem_top_ipin_23_TSMC22ULP_CCFF_0_Q), .Z(eco_net_107_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_23_del3_2 ( .I(
        mem_top_ipin_23_TSMC22ULP_CCFF_1_Q), .Z(eco_net_108_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_23_del3_3 ( .I(
        mem_top_ipin_23_TSMC22ULP_CCFF_2_Q), .Z(eco_net_109_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_24_del3_0 ( .I(eco_net_13_0), .Z(
        eco_net_110_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_24_del3_1 ( .I(
        mem_top_ipin_24_TSMC22ULP_CCFF_0_Q), .Z(eco_net_111_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_24_del3_2 ( .I(
        mem_top_ipin_24_TSMC22ULP_CCFF_1_Q), .Z(eco_net_112_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_24_del3_3 ( .I(
        mem_top_ipin_24_TSMC22ULP_CCFF_2_Q), .Z(eco_net_113_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_25_del3_0 ( .I(cb_mux_size8_mem_24_ccff_tail), .Z(eco_net_114_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_25_del3_1 ( .I(
        mem_top_ipin_25_TSMC22ULP_CCFF_0_Q), .Z(eco_net_115_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_25_del3_2 ( .I(
        mem_top_ipin_25_TSMC22ULP_CCFF_1_Q), .Z(eco_net_116_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_25_del3_3 ( .I(
        mem_top_ipin_25_TSMC22ULP_CCFF_2_Q), .Z(eco_net_117_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_26_del3_0 ( .I(cb_mux_size8_mem_25_ccff_tail), .Z(eco_net_118_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_26_del3_1 ( .I(
        mem_top_ipin_26_TSMC22ULP_CCFF_0_Q), .Z(eco_net_119_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_26_del3_2 ( .I(
        mem_top_ipin_26_TSMC22ULP_CCFF_1_Q), .Z(eco_net_120_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_26_del3_3 ( .I(
        mem_top_ipin_26_TSMC22ULP_CCFF_2_Q), .Z(eco_net_121_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_27_del3_0 ( .I(cb_mux_size8_mem_26_ccff_tail), .Z(eco_net_122_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_27_del3_1 ( .I(
        mem_top_ipin_27_TSMC22ULP_CCFF_0_Q), .Z(eco_net_123_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_27_del3_2 ( .I(
        mem_top_ipin_27_TSMC22ULP_CCFF_1_Q), .Z(eco_net_124_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_27_del3_3 ( .I(
        mem_top_ipin_27_TSMC22ULP_CCFF_2_Q), .Z(eco_net_125_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_28_del3_0 ( .I(cb_mux_size8_mem_27_ccff_tail), .Z(eco_net_126_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_28_del3_1 ( .I(
        mem_top_ipin_28_TSMC22ULP_CCFF_0_Q), .Z(eco_net_127_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_28_del3_2 ( .I(
        mem_top_ipin_28_TSMC22ULP_CCFF_1_Q), .Z(eco_net_128_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_28_del3_3 ( .I(
        mem_top_ipin_28_TSMC22ULP_CCFF_2_Q), .Z(eco_net_129_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_29_del3_0 ( .I(cb_mux_size8_mem_28_ccff_tail), .Z(eco_net_130_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_29_del3_1 ( .I(
        mem_top_ipin_29_TSMC22ULP_CCFF_0_Q), .Z(eco_net_131_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_29_del3_2 ( .I(
        mem_top_ipin_29_TSMC22ULP_CCFF_1_Q), .Z(eco_net_132_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_29_del3_3 ( .I(
        mem_top_ipin_29_TSMC22ULP_CCFF_2_Q), .Z(eco_net_133_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_30_del3_0 ( .I(cb_mux_size8_mem_29_ccff_tail), .Z(eco_net_134_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_30_del3_1 ( .I(
        mem_top_ipin_30_TSMC22ULP_CCFF_0_Q), .Z(eco_net_135_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_30_del3_2 ( .I(
        mem_top_ipin_30_TSMC22ULP_CCFF_1_Q), .Z(eco_net_136_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_30_del3_3 ( .I(
        mem_top_ipin_30_TSMC22ULP_CCFF_2_Q), .Z(eco_net_137_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_del3_0 ( .I(cb_mux_size8_mem_30_ccff_tail), .Z(eco_net_138_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_del3_1 ( .I(
        mem_top_ipin_31_TSMC22ULP_CCFF_0_Q), .Z(eco_net_139_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_del3_2 ( .I(
        mem_top_ipin_31_TSMC22ULP_CCFF_1_Q), .Z(eco_net_140_0) );
  BUFFD1BWP30P140HVT mem_top_ipin_31_del3_3 ( .I(
        mem_top_ipin_31_TSMC22ULP_CCFF_2_Q), .Z(eco_net_141_0) );
endmodule


module cbx_0_ ( config_enable, prog_reset, prog_clk, chanx_left_in, 
        chanx_right_in, ccff_head, chanx_left_out, chanx_right_out, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_1__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_1__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_2__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_2__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_3__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_3__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_4__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_4__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_4__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_5__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_5__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_5__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_6__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_6__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_6__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_7__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_7__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_7__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_8__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_8__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_8__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_9__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_9__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_9__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_10__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_10__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_10__pin_lreset_0_, 
        bottom_grid_top_width_0_height_0_subtile_11__pin_f2a_i_0_, 
        bottom_grid_top_width_0_height_0_subtile_11__pin_lclk_0_, 
        bottom_grid_top_width_0_height_0_subtile_11__pin_lreset_0_, ccff_tail
 );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:31] chanx_left_in;
  input [0:31] chanx_right_in;
  input [0:0] ccff_head;
  output [0:31] chanx_left_out;
  output [0:31] chanx_right_out;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_1__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_1__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_2__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_2__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_3__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_3__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_4__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_4__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_4__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_5__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_5__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_5__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_6__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_6__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_6__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_7__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_7__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_7__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_8__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_8__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_8__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_9__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_9__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_9__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_10__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_10__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_10__pin_lreset_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_11__pin_f2a_i_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_11__pin_lclk_0_;
  output [0:0] bottom_grid_top_width_0_height_0_subtile_11__pin_lreset_0_;
  output [0:0] ccff_tail;
  wire   n5, n6;
  wire   [0:3] cb_mux_size8_0_sram;
  wire   [0:3] cb_mux_size8_0_sram_inv;
  wire   [0:3] cb_mux_size8_1_sram;
  wire   [0:3] cb_mux_size8_1_sram_inv;
  wire   [0:3] cb_mux_size8_2_sram;
  wire   [0:3] cb_mux_size8_2_sram_inv;
  wire   [0:3] cb_mux_size8_3_sram;
  wire   [0:3] cb_mux_size8_3_sram_inv;
  wire   [0:3] cb_mux_size8_4_sram;
  wire   [0:3] cb_mux_size8_4_sram_inv;
  wire   [0:3] cb_mux_size8_5_sram;
  wire   [0:3] cb_mux_size8_5_sram_inv;
  wire   [0:3] cb_mux_size8_6_sram;
  wire   [0:3] cb_mux_size8_6_sram_inv;
  wire   [0:3] cb_mux_size8_7_sram;
  wire   [0:3] cb_mux_size8_7_sram_inv;
  wire   [0:3] cb_mux_size8_8_sram;
  wire   [0:3] cb_mux_size8_8_sram_inv;
  wire   [0:3] cb_mux_size8_9_sram;
  wire   [0:3] cb_mux_size8_9_sram_inv;
  wire   [0:3] cb_mux_size8_10_sram;
  wire   [0:3] cb_mux_size8_10_sram_inv;
  wire   [0:3] cb_mux_size8_11_sram;
  wire   [0:3] cb_mux_size8_11_sram_inv;
  wire   [0:3] cb_mux_size8_12_sram;
  wire   [0:3] cb_mux_size8_12_sram_inv;
  wire   [0:3] cb_mux_size8_13_sram;
  wire   [0:3] cb_mux_size8_13_sram_inv;
  wire   [0:3] cb_mux_size8_14_sram;
  wire   [0:3] cb_mux_size8_14_sram_inv;
  wire   [0:3] cb_mux_size8_15_sram;
  wire   [0:3] cb_mux_size8_15_sram_inv;
  wire   [0:3] cb_mux_size8_16_sram;
  wire   [0:3] cb_mux_size8_16_sram_inv;
  wire   [0:3] cb_mux_size8_17_sram;
  wire   [0:3] cb_mux_size8_17_sram_inv;
  wire   [0:3] cb_mux_size8_18_sram;
  wire   [0:3] cb_mux_size8_18_sram_inv;
  wire   [0:3] cb_mux_size8_19_sram;
  wire   [0:3] cb_mux_size8_19_sram_inv;
  wire   [0:3] cb_mux_size8_20_sram;
  wire   [0:3] cb_mux_size8_20_sram_inv;
  wire   [0:3] cb_mux_size8_21_sram;
  wire   [0:3] cb_mux_size8_21_sram_inv;
  wire   [0:3] cb_mux_size8_22_sram;
  wire   [0:3] cb_mux_size8_22_sram_inv;
  wire   [0:3] cb_mux_size8_23_sram;
  wire   [0:3] cb_mux_size8_23_sram_inv;
  wire   [0:3] cb_mux_size8_24_sram;
  wire   [0:3] cb_mux_size8_24_sram_inv;
  wire   [0:3] cb_mux_size8_25_sram;
  wire   [0:3] cb_mux_size8_25_sram_inv;
  wire   [0:3] cb_mux_size8_26_sram;
  wire   [0:3] cb_mux_size8_26_sram_inv;
  wire   [0:3] cb_mux_size8_27_sram;
  wire   [0:3] cb_mux_size8_27_sram_inv;
  wire   [0:3] cb_mux_size8_28_sram;
  wire   [0:3] cb_mux_size8_28_sram_inv;
  wire   [0:3] cb_mux_size8_29_sram;
  wire   [0:3] cb_mux_size8_29_sram_inv;
  wire   [0:3] cb_mux_size8_30_sram;
  wire   [0:3] cb_mux_size8_30_sram_inv;
  wire   [0:3] cb_mux_size8_31_sram;
  wire   [0:3] cb_mux_size8_31_sram_inv;
  assign chanx_left_out[2] = chanx_right_in[2];
  assign chanx_left_out[3] = chanx_right_in[3];
  assign chanx_left_out[4] = chanx_right_in[4];
  assign chanx_left_out[5] = chanx_right_in[5];
  assign chanx_left_out[6] = chanx_right_in[6];
  assign chanx_left_out[7] = chanx_right_in[7];
  assign chanx_left_out[8] = chanx_right_in[8];
  assign chanx_left_out[9] = chanx_right_in[9];
  assign chanx_left_out[10] = chanx_right_in[10];
  assign chanx_left_out[11] = chanx_right_in[11];
  assign chanx_left_out[12] = chanx_right_in[12];
  assign chanx_left_out[13] = chanx_right_in[13];
  assign chanx_left_out[14] = chanx_right_in[14];
  assign chanx_left_out[15] = chanx_right_in[15];
  assign chanx_left_out[16] = chanx_right_in[16];
  assign chanx_left_out[17] = chanx_right_in[17];
  assign chanx_left_out[18] = chanx_right_in[18];
  assign chanx_left_out[19] = chanx_right_in[19];
  assign chanx_left_out[20] = chanx_right_in[20];
  assign chanx_left_out[21] = chanx_right_in[21];
  assign chanx_left_out[22] = chanx_right_in[22];
  assign chanx_left_out[23] = chanx_right_in[23];
  assign chanx_left_out[24] = chanx_right_in[24];
  assign chanx_left_out[25] = chanx_right_in[25];
  assign chanx_left_out[26] = chanx_right_in[26];
  assign chanx_left_out[27] = chanx_right_in[27];
  assign chanx_left_out[28] = chanx_right_in[28];
  assign chanx_left_out[29] = chanx_right_in[29];
  assign chanx_left_out[30] = chanx_right_in[30];
  assign chanx_left_out[31] = chanx_right_in[31];
  assign chanx_left_out[1] = chanx_right_in[1];
  assign chanx_left_out[0] = chanx_right_in[0];
  assign chanx_right_out[0] = chanx_left_in[0];
  assign chanx_right_out[1] = chanx_left_in[1];
  assign chanx_right_out[2] = chanx_left_in[2];
  assign chanx_right_out[3] = chanx_left_in[3];
  assign chanx_right_out[4] = chanx_left_in[4];
  assign chanx_right_out[5] = chanx_left_in[5];
  assign chanx_right_out[6] = chanx_left_in[6];
  assign chanx_right_out[7] = chanx_left_in[7];
  assign chanx_right_out[8] = chanx_left_in[8];
  assign chanx_right_out[9] = chanx_left_in[9];
  assign chanx_right_out[10] = chanx_left_in[10];
  assign chanx_right_out[11] = chanx_left_in[11];
  assign chanx_right_out[12] = chanx_left_in[12];
  assign chanx_right_out[13] = chanx_left_in[13];
  assign chanx_right_out[14] = chanx_left_in[14];
  assign chanx_right_out[15] = chanx_left_in[15];
  assign chanx_right_out[16] = chanx_left_in[16];
  assign chanx_right_out[17] = chanx_left_in[17];
  assign chanx_right_out[18] = chanx_left_in[18];
  assign chanx_right_out[19] = chanx_left_in[19];
  assign chanx_right_out[20] = chanx_left_in[20];
  assign chanx_right_out[21] = chanx_left_in[21];
  assign chanx_right_out[22] = chanx_left_in[22];
  assign chanx_right_out[23] = chanx_left_in[23];
  assign chanx_right_out[24] = chanx_left_in[24];
  assign chanx_right_out[25] = chanx_left_in[25];
  assign chanx_right_out[26] = chanx_left_in[26];
  assign chanx_right_out[27] = chanx_left_in[27];
  assign chanx_right_out[28] = chanx_left_in[28];
  assign chanx_right_out[29] = chanx_left_in[29];
  assign chanx_right_out[30] = chanx_left_in[30];
  assign chanx_right_out[31] = chanx_left_in[31];

  cbx_0__cb_mux_size8 mux_top_ipin_0 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[25], 
        chanx_right_in[25]}), .sram(cb_mux_size8_0_sram), .sram_inv(
        cb_mux_size8_0_sram_inv), .out(n5) );
  cbx_0__cb_mux_size8 mux_top_ipin_1 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[26], 
        chanx_right_in[26]}), .sram(cb_mux_size8_1_sram), .sram_inv(
        cb_mux_size8_1_sram_inv), .out(n6) );
  cbx_0__cb_mux_size8 mux_top_ipin_2 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[27], 
        chanx_right_in[27]}), .sram(cb_mux_size8_2_sram), .sram_inv(
        cb_mux_size8_2_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_1__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_3 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[28], 
        chanx_right_in[28]}), .sram(cb_mux_size8_3_sram), .sram_inv(
        cb_mux_size8_3_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_1__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_4 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[29], 
        chanx_right_in[29]}), .sram(cb_mux_size8_4_sram), .sram_inv(
        cb_mux_size8_4_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_2__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_5 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[17], chanx_right_in[17], chanx_left_in[30], 
        chanx_right_in[30]}), .sram(cb_mux_size8_5_sram), .sram_inv(
        cb_mux_size8_5_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_2__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_6 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[18], chanx_right_in[18], chanx_left_in[31], 
        chanx_right_in[31]}), .sram(cb_mux_size8_6_sram), .sram_inv(
        cb_mux_size8_6_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_3__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_7 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[19], 
        chanx_right_in[19]}), .sram(cb_mux_size8_7_sram), .sram_inv(
        cb_mux_size8_7_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_3__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_8 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[20], 
        chanx_right_in[20]}), .sram(cb_mux_size8_8_sram), .sram_inv(
        cb_mux_size8_8_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_4__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_9 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[21], 
        chanx_right_in[21]}), .sram(cb_mux_size8_9_sram), .sram_inv(
        cb_mux_size8_9_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_4__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_10 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[22], 
        chanx_right_in[22]}), .sram(cb_mux_size8_10_sram), .sram_inv(
        cb_mux_size8_10_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_4__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_11 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[23], 
        chanx_right_in[23]}), .sram(cb_mux_size8_11_sram), .sram_inv(
        cb_mux_size8_11_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_5__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_12 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[17], chanx_right_in[17], chanx_left_in[24], 
        chanx_right_in[24]}), .sram(cb_mux_size8_12_sram), .sram_inv(
        cb_mux_size8_12_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_5__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_13 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[18], chanx_right_in[18], chanx_left_in[25], 
        chanx_right_in[25]}), .sram(cb_mux_size8_13_sram), .sram_inv(
        cb_mux_size8_13_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_5__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_14 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[19], chanx_right_in[19], chanx_left_in[26], 
        chanx_right_in[26]}), .sram(cb_mux_size8_14_sram), .sram_inv(
        cb_mux_size8_14_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_6__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_15 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[20], chanx_right_in[20], chanx_left_in[27], 
        chanx_right_in[27]}), .sram(cb_mux_size8_15_sram), .sram_inv(
        cb_mux_size8_15_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_6__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_16 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[21], chanx_right_in[21], chanx_left_in[28], 
        chanx_right_in[28]}), .sram(cb_mux_size8_16_sram), .sram_inv(
        cb_mux_size8_16_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_6__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_17 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[22], chanx_right_in[22], chanx_left_in[29], 
        chanx_right_in[29]}), .sram(cb_mux_size8_17_sram), .sram_inv(
        cb_mux_size8_17_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_7__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_18 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[23], chanx_right_in[23], chanx_left_in[30], 
        chanx_right_in[30]}), .sram(cb_mux_size8_18_sram), .sram_inv(
        cb_mux_size8_18_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_7__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_19 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[24], chanx_right_in[24], chanx_left_in[31], 
        chanx_right_in[31]}), .sram(cb_mux_size8_19_sram), .sram_inv(
        cb_mux_size8_19_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_7__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_20 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[25], 
        chanx_right_in[25]}), .sram(cb_mux_size8_20_sram), .sram_inv(
        cb_mux_size8_20_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_8__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_21 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[26], 
        chanx_right_in[26]}), .sram(cb_mux_size8_21_sram), .sram_inv(
        cb_mux_size8_21_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_8__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_22 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[27], 
        chanx_right_in[27]}), .sram(cb_mux_size8_22_sram), .sram_inv(
        cb_mux_size8_22_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_8__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_23 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[28], 
        chanx_right_in[28]}), .sram(cb_mux_size8_23_sram), .sram_inv(
        cb_mux_size8_23_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_9__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_24 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[29], 
        chanx_right_in[29]}), .sram(cb_mux_size8_24_sram), .sram_inv(
        cb_mux_size8_24_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_9__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_25 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[17], chanx_right_in[17], chanx_left_in[30], 
        chanx_right_in[30]}), .sram(cb_mux_size8_25_sram), .sram_inv(
        cb_mux_size8_25_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_9__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_26 ( .in({chanx_left_in[2], 
        chanx_right_in[2], chanx_left_in[8], chanx_right_in[8], 
        chanx_left_in[18], chanx_right_in[18], chanx_left_in[31], 
        chanx_right_in[31]}), .sram(cb_mux_size8_26_sram), .sram_inv(
        cb_mux_size8_26_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_10__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_27 ( .in({chanx_left_in[3], 
        chanx_right_in[3], chanx_left_in[9], chanx_right_in[9], 
        chanx_left_in[12], chanx_right_in[12], chanx_left_in[19], 
        chanx_right_in[19]}), .sram(cb_mux_size8_27_sram), .sram_inv(
        cb_mux_size8_27_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_10__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_28 ( .in({chanx_left_in[4], 
        chanx_right_in[4], chanx_left_in[10], chanx_right_in[10], 
        chanx_left_in[13], chanx_right_in[13], chanx_left_in[20], 
        chanx_right_in[20]}), .sram(cb_mux_size8_28_sram), .sram_inv(
        cb_mux_size8_28_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_10__pin_lreset_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_29 ( .in({chanx_left_in[5], 
        chanx_right_in[5], chanx_left_in[11], chanx_right_in[11], 
        chanx_left_in[14], chanx_right_in[14], chanx_left_in[21], 
        chanx_right_in[21]}), .sram(cb_mux_size8_29_sram), .sram_inv(
        cb_mux_size8_29_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_11__pin_f2a_i_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_30 ( .in({chanx_left_in[0], 
        chanx_right_in[0], chanx_left_in[6], chanx_right_in[6], 
        chanx_left_in[15], chanx_right_in[15], chanx_left_in[22], 
        chanx_right_in[22]}), .sram(cb_mux_size8_30_sram), .sram_inv(
        cb_mux_size8_30_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_11__pin_lclk_0_[0]) );
  cbx_0__cb_mux_size8 mux_top_ipin_31 ( .in({chanx_left_in[1], 
        chanx_right_in[1], chanx_left_in[7], chanx_right_in[7], 
        chanx_left_in[16], chanx_right_in[16], chanx_left_in[23], 
        chanx_right_in[23]}), .sram(cb_mux_size8_31_sram), .sram_inv(
        cb_mux_size8_31_sram_inv), .out(
        bottom_grid_top_width_0_height_0_subtile_11__pin_lreset_0_[0]) );
  cbx_0__config_group_mem_size128 cbx_0__config_group_mem_size128 ( 
        .config_enable(config_enable[0]), .prog_reset(prog_reset[0]), 
        .prog_clk(prog_clk[0]), .ccff_head(ccff_head[0]), .mem_out({
        cb_mux_size8_0_sram, cb_mux_size8_1_sram, cb_mux_size8_2_sram, 
        cb_mux_size8_3_sram, cb_mux_size8_4_sram, cb_mux_size8_5_sram, 
        cb_mux_size8_6_sram, cb_mux_size8_7_sram, cb_mux_size8_8_sram, 
        cb_mux_size8_9_sram, cb_mux_size8_10_sram, cb_mux_size8_11_sram, 
        cb_mux_size8_12_sram, cb_mux_size8_13_sram, cb_mux_size8_14_sram, 
        cb_mux_size8_15_sram, cb_mux_size8_16_sram, cb_mux_size8_17_sram, 
        cb_mux_size8_18_sram, cb_mux_size8_19_sram, cb_mux_size8_20_sram, 
        cb_mux_size8_21_sram, cb_mux_size8_22_sram, cb_mux_size8_23_sram, 
        cb_mux_size8_24_sram, cb_mux_size8_25_sram, cb_mux_size8_26_sram, 
        cb_mux_size8_27_sram, cb_mux_size8_28_sram, cb_mux_size8_29_sram, 
        cb_mux_size8_30_sram, cb_mux_size8_31_sram}), .mem_outb({
        cb_mux_size8_0_sram_inv, cb_mux_size8_1_sram_inv, 
        cb_mux_size8_2_sram_inv, cb_mux_size8_3_sram_inv, 
        cb_mux_size8_4_sram_inv, cb_mux_size8_5_sram_inv, 
        cb_mux_size8_6_sram_inv, cb_mux_size8_7_sram_inv, 
        cb_mux_size8_8_sram_inv, cb_mux_size8_9_sram_inv, 
        cb_mux_size8_10_sram_inv, cb_mux_size8_11_sram_inv, 
        cb_mux_size8_12_sram_inv, cb_mux_size8_13_sram_inv, 
        cb_mux_size8_14_sram_inv, cb_mux_size8_15_sram_inv, 
        cb_mux_size8_16_sram_inv, cb_mux_size8_17_sram_inv, 
        cb_mux_size8_18_sram_inv, cb_mux_size8_19_sram_inv, 
        cb_mux_size8_20_sram_inv, cb_mux_size8_21_sram_inv, 
        cb_mux_size8_22_sram_inv, cb_mux_size8_23_sram_inv, 
        cb_mux_size8_24_sram_inv, cb_mux_size8_25_sram_inv, 
        cb_mux_size8_26_sram_inv, cb_mux_size8_27_sram_inv, 
        cb_mux_size8_28_sram_inv, cb_mux_size8_29_sram_inv, 
        cb_mux_size8_30_sram_inv, cb_mux_size8_31_sram_inv}), .ccff_tail(
        ccff_tail[0]) );
  BUFFD6BWP30P140HVT U1 ( .I(n6), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_lreset_0_[0]) );
  BUFFD6BWP30P140HVT U2 ( .I(n5), .Z(
        bottom_grid_top_width_0_height_0_subtile_0__pin_lclk_0_[0]) );
endmodule

