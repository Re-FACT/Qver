/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : Q-2019.12-SP4

/////////////////////////////////////////////////////////////


module sb_0__sb_mux_size3 ( in, sram, sram_inv, out );
  input [0:2] in;
  input [0:1] sram;
  input [0:1] sram_inv;
  output [0:0] out;
  wire   n5, n6, n7, n8;

  INVD1BWP30P140HVT U6 ( .I(sram[1]), .ZN(n8) );
  INVD1BWP30P140HVT U7 ( .I(sram[0]), .ZN(n5) );
  AOI22D1BWP30P140HVT U8 ( .A1(sram[0]), .A2(in[0]), .B1(in[1]), .B2(n5), .ZN(
        n7) );
  ND3D1BWP30P140HVT U9 ( .A1(n8), .A2(in[2]), .A3(sram[0]), .ZN(n6) );
  OAI21D1BWP30P140HVT U10 ( .A1(n8), .A2(n7), .B(n6), .ZN(out[0]) );
endmodule


module sb_0__sb_mux_size2 ( in, sram, sram_inv, out );
  input [0:1] in;
  input [0:1] sram;
  input [0:1] sram_inv;
  output [0:0] out;
  wire   n3, n4;

  INVD1BWP30P140HVT U4 ( .I(in[0]), .ZN(n4) );
  OAI21D1BWP30P140HVT U5 ( .A1(in[1]), .A2(sram[0]), .B(sram[1]), .ZN(n3) );
  AOI21D1BWP30P140HVT U6 ( .A1(sram[0]), .A2(n4), .B(n3), .ZN(out[0]) );
endmodule


module sb_0__config_group_mem_size62 ( config_enable, prog_reset, prog_clk, 
        ccff_head, mem_out, mem_outb, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:0] ccff_head;
  output [0:61] mem_out;
  output [0:61] mem_outb;
  output [0:0] ccff_tail;
  wire   sb_mux_size3_mem_0_ccff_tail, sb_mux_size2_mem_4_ccff_tail,
         sb_mux_size3_mem_1_ccff_tail, sb_mux_size2_mem_0_ccff_tail,
         sb_mux_size2_mem_1_ccff_tail, sb_mux_size2_mem_2_ccff_tail,
         sb_mux_size2_mem_3_ccff_tail, sb_mux_size2_mem_5_ccff_tail,
         sb_mux_size2_mem_6_ccff_tail, sb_mux_size2_mem_7_ccff_tail,
         sb_mux_size2_mem_8_ccff_tail, sb_mux_size2_mem_9_ccff_tail,
         sb_mux_size2_mem_10_ccff_tail, sb_mux_size2_mem_11_ccff_tail,
         sb_mux_size2_mem_12_ccff_tail, sb_mux_size2_mem_13_ccff_tail,
         sb_mux_size2_mem_14_ccff_tail, sb_mux_size2_mem_15_ccff_tail,
         sb_mux_size2_mem_16_ccff_tail, sb_mux_size2_mem_17_ccff_tail,
         sb_mux_size2_mem_18_ccff_tail, sb_mux_size2_mem_19_ccff_tail,
         sb_mux_size2_mem_20_ccff_tail, sb_mux_size2_mem_21_ccff_tail,
         sb_mux_size2_mem_22_ccff_tail, sb_mux_size2_mem_23_ccff_tail,
         sb_mux_size2_mem_24_ccff_tail, sb_mux_size2_mem_25_ccff_tail,
         sb_mux_size2_mem_26_ccff_tail, sb_mux_size2_mem_27_ccff_tail,
         mem_top_track_0_TSMC22ULP_CCFF_0_Q,
         mem_top_track_2_TSMC22ULP_CCFF_0_Q,
         mem_top_track_12_TSMC22ULP_CCFF_0_Q,
         mem_right_track_30_TSMC22ULP_CCFF_0_Q,
         mem_right_track_28_TSMC22ULP_CCFF_0_Q,
         mem_right_track_26_TSMC22ULP_CCFF_0_Q,
         mem_right_track_24_TSMC22ULP_CCFF_0_Q,
         mem_right_track_18_TSMC22ULP_CCFF_0_Q,
         mem_right_track_16_TSMC22ULP_CCFF_0_Q,
         mem_right_track_14_TSMC22ULP_CCFF_0_Q,
         mem_right_track_12_TSMC22ULP_CCFF_0_Q,
         mem_right_track_6_TSMC22ULP_CCFF_0_Q,
         mem_right_track_4_TSMC22ULP_CCFF_0_Q,
         mem_right_track_2_TSMC22ULP_CCFF_0_Q,
         mem_right_track_0_TSMC22ULP_CCFF_0_Q,
         mem_top_track_36_TSMC22ULP_CCFF_0_Q,
         mem_top_track_34_TSMC22ULP_CCFF_0_Q,
         mem_top_track_32_TSMC22ULP_CCFF_0_Q,
         mem_top_track_30_TSMC22ULP_CCFF_0_Q,
         mem_top_track_28_TSMC22ULP_CCFF_0_Q,
         mem_top_track_26_TSMC22ULP_CCFF_0_Q,
         mem_top_track_24_TSMC22ULP_CCFF_0_Q,
         mem_top_track_22_TSMC22ULP_CCFF_0_Q,
         mem_top_track_20_TSMC22ULP_CCFF_0_Q,
         mem_top_track_18_TSMC22ULP_CCFF_0_Q,
         mem_top_track_16_TSMC22ULP_CCFF_0_Q,
         mem_top_track_14_TSMC22ULP_CCFF_0_Q,
         mem_top_track_10_TSMC22ULP_CCFF_0_Q,
         mem_top_track_8_TSMC22ULP_CCFF_0_Q,
         mem_top_track_6_TSMC22ULP_CCFF_0_Q,
         mem_top_track_4_TSMC22ULP_CCFF_0_Q, eco_net, eco_net_0, eco_net_1_0,
         eco_net_2_0, eco_net_3_0, eco_net_4_0, eco_net_5_0, eco_net_6_0,
         eco_net_7_0, eco_net_8_0, eco_net_9_0, eco_net_10_0, eco_net_11_0,
         eco_net_12_0, eco_net_13_0, eco_net_14_0, eco_net_15_0, eco_net_16_0,
         eco_net_17_0, eco_net_18_0, eco_net_19_0, eco_net_20_0, eco_net_21_0,
         eco_net_22_0, eco_net_23_0, eco_net_24_0, eco_net_25_0, eco_net_26_0,
         eco_net_27_0, eco_net_28_0, eco_net_29_0, eco_net_30_0, eco_net_31_0,
         eco_net_32_0, eco_net_33_0, eco_net_34_0, eco_net_35_0, eco_net_36_0,
         eco_net_37_0, eco_net_38_0, eco_net_39_0, eco_net_40_0, eco_net_41_0,
         eco_net_42_0, eco_net_43_0, eco_net_44_0, eco_net_45_0, eco_net_46_0,
         eco_net_47_0, eco_net_48_0, eco_net_49_0, eco_net_50_0, eco_net_51_0,
         eco_net_52_0, eco_net_53_0, eco_net_54_0, eco_net_55_0, eco_net_56_0,
         eco_net_57_0, eco_net_58_0, eco_net_59_0, eco_net_60_0, eco_net_61_0,
         eco_net_62_0, eco_net_63_0, eco_net_64_0, eco_net_65_0, eco_net_66_0,
         eco_net_67_0, eco_net_68_0, eco_net_69_0;

  DFCNQD1BWP30P140HVT mem_top_track_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_8_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_30_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_69_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(ccff_tail[0])
         );
  DFCNQD1BWP30P140HVT mem_right_track_30_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_68_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_30_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_28_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_67_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_27_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_28_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_66_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_28_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_26_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_65_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_26_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_26_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_64_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_26_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_24_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_63_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_25_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_24_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_62_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_24_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_18_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_61_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_24_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_18_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_60_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_18_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_16_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_59_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_23_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_16_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_58_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_16_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_14_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_57_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_22_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_14_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_56_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_14_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_12_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_55_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_21_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_12_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_54_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_12_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_53_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_20_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_52_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_51_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_19_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_50_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_49_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_18_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_48_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_right_track_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_47_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_17_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_right_track_0_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_46_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_right_track_0_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_36_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_45_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_16_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_36_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_44_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_34_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_43_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_15_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_34_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_42_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_32_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_41_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        sb_mux_size2_mem_14_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_32_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_40_0), .CP(eco_net_0), .CDN(eco_net_3_0), .Q(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_30_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_39_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_13_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_30_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_38_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_28_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_37_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_12_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_28_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_36_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_26_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_35_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_11_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_26_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_34_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_24_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_33_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_10_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_24_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_32_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_22_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_31_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_9_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_22_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_30_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_20_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_29_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_8_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_20_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_28_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_18_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_27_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_7_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_18_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_26_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_16_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_25_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_6_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_16_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_24_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_14_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_23_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_5_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_14_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_22_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_10_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_19_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_4_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_10_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_18_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_8_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_17_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_3_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_8_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_16_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_6_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_15_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_2_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_6_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_14_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_4_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_13_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_4_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_12_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_2_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_11_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size2_mem_0_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_2_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_10_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_12_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_21_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size3_mem_1_ccff_tail) );
  DFCNQD1BWP30P140HVT mem_top_track_12_TSMC22ULP_CCFF_0__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_20_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q) );
  DFCNQD1BWP30P140HVT mem_top_track_0_TSMC22ULP_CCFF_1__SDFF_RST_SINGLE_OUTPUT_DFF_STD_CELL ( 
        .D(eco_net_9_0), .CP(eco_net), .CDN(eco_net_2_0), .Q(
        sb_mux_size3_mem_0_ccff_tail) );
  ND2D1BWP30P140HVT U125 ( .A1(config_enable[0]), .A2(
        sb_mux_size3_mem_0_ccff_tail), .ZN(mem_outb[1]) );
  INVD1BWP30P140HVT U126 ( .I(mem_outb[1]), .ZN(mem_out[1]) );
  ND2D1BWP30P140HVT U127 ( .A1(config_enable[0]), .A2(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[2]) );
  INVD1BWP30P140HVT U128 ( .I(mem_outb[2]), .ZN(mem_out[2]) );
  ND2D1BWP30P140HVT U129 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_0_ccff_tail), .ZN(mem_outb[3]) );
  INVD1BWP30P140HVT U130 ( .I(mem_outb[3]), .ZN(mem_out[3]) );
  ND2D1BWP30P140HVT U131 ( .A1(config_enable[0]), .A2(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[4]) );
  INVD1BWP30P140HVT U132 ( .I(mem_outb[4]), .ZN(mem_out[4]) );
  ND2D1BWP30P140HVT U133 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_1_ccff_tail), .ZN(mem_outb[5]) );
  INVD1BWP30P140HVT U134 ( .I(mem_outb[5]), .ZN(mem_out[5]) );
  ND2D1BWP30P140HVT U135 ( .A1(config_enable[0]), .A2(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[6]) );
  INVD1BWP30P140HVT U136 ( .I(mem_outb[6]), .ZN(mem_out[6]) );
  ND2D1BWP30P140HVT U137 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_2_ccff_tail), .ZN(mem_outb[7]) );
  INVD1BWP30P140HVT U138 ( .I(mem_outb[7]), .ZN(mem_out[7]) );
  ND2D1BWP30P140HVT U139 ( .A1(config_enable[0]), .A2(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[8]) );
  INVD1BWP30P140HVT U140 ( .I(mem_outb[8]), .ZN(mem_out[8]) );
  ND2D1BWP30P140HVT U141 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_3_ccff_tail), .ZN(mem_outb[9]) );
  INVD1BWP30P140HVT U142 ( .I(mem_outb[9]), .ZN(mem_out[9]) );
  ND2D1BWP30P140HVT U143 ( .A1(config_enable[0]), .A2(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[10]) );
  INVD1BWP30P140HVT U144 ( .I(mem_outb[10]), .ZN(mem_out[10]) );
  ND2D1BWP30P140HVT U145 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_4_ccff_tail), .ZN(mem_outb[11]) );
  INVD1BWP30P140HVT U146 ( .I(mem_outb[11]), .ZN(mem_out[11]) );
  ND2D1BWP30P140HVT U147 ( .A1(config_enable[0]), .A2(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[12]) );
  INVD1BWP30P140HVT U148 ( .I(mem_outb[12]), .ZN(mem_out[12]) );
  ND2D1BWP30P140HVT U149 ( .A1(config_enable[0]), .A2(
        sb_mux_size3_mem_1_ccff_tail), .ZN(mem_outb[13]) );
  INVD1BWP30P140HVT U150 ( .I(mem_outb[13]), .ZN(mem_out[13]) );
  ND2D1BWP30P140HVT U151 ( .A1(config_enable[0]), .A2(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[14]) );
  INVD1BWP30P140HVT U152 ( .I(mem_outb[14]), .ZN(mem_out[14]) );
  ND2D1BWP30P140HVT U153 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_5_ccff_tail), .ZN(mem_outb[15]) );
  INVD1BWP30P140HVT U154 ( .I(mem_outb[15]), .ZN(mem_out[15]) );
  ND2D1BWP30P140HVT U155 ( .A1(config_enable[0]), .A2(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[16]) );
  INVD1BWP30P140HVT U156 ( .I(mem_outb[16]), .ZN(mem_out[16]) );
  ND2D1BWP30P140HVT U157 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_6_ccff_tail), .ZN(mem_outb[17]) );
  INVD1BWP30P140HVT U158 ( .I(mem_outb[17]), .ZN(mem_out[17]) );
  ND2D1BWP30P140HVT U159 ( .A1(config_enable[0]), .A2(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[18]) );
  INVD1BWP30P140HVT U160 ( .I(mem_outb[18]), .ZN(mem_out[18]) );
  ND2D1BWP30P140HVT U161 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_7_ccff_tail), .ZN(mem_outb[19]) );
  INVD1BWP30P140HVT U162 ( .I(mem_outb[19]), .ZN(mem_out[19]) );
  ND2D1BWP30P140HVT U163 ( .A1(config_enable[0]), .A2(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[20]) );
  INVD1BWP30P140HVT U164 ( .I(mem_outb[20]), .ZN(mem_out[20]) );
  ND2D1BWP30P140HVT U165 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_8_ccff_tail), .ZN(mem_outb[21]) );
  INVD1BWP30P140HVT U166 ( .I(mem_outb[21]), .ZN(mem_out[21]) );
  ND2D1BWP30P140HVT U167 ( .A1(config_enable[0]), .A2(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[22]) );
  INVD1BWP30P140HVT U168 ( .I(mem_outb[22]), .ZN(mem_out[22]) );
  ND2D1BWP30P140HVT U169 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_9_ccff_tail), .ZN(mem_outb[23]) );
  INVD1BWP30P140HVT U170 ( .I(mem_outb[23]), .ZN(mem_out[23]) );
  ND2D1BWP30P140HVT U171 ( .A1(config_enable[0]), .A2(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[24]) );
  INVD1BWP30P140HVT U172 ( .I(mem_outb[24]), .ZN(mem_out[24]) );
  ND2D1BWP30P140HVT U173 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_10_ccff_tail), .ZN(mem_outb[25]) );
  INVD1BWP30P140HVT U174 ( .I(mem_outb[25]), .ZN(mem_out[25]) );
  ND2D1BWP30P140HVT U175 ( .A1(config_enable[0]), .A2(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[26]) );
  INVD1BWP30P140HVT U176 ( .I(mem_outb[26]), .ZN(mem_out[26]) );
  ND2D1BWP30P140HVT U177 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_11_ccff_tail), .ZN(mem_outb[27]) );
  INVD1BWP30P140HVT U178 ( .I(mem_outb[27]), .ZN(mem_out[27]) );
  ND2D1BWP30P140HVT U179 ( .A1(config_enable[0]), .A2(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[28]) );
  INVD1BWP30P140HVT U180 ( .I(mem_outb[28]), .ZN(mem_out[28]) );
  ND2D1BWP30P140HVT U181 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_12_ccff_tail), .ZN(mem_outb[29]) );
  INVD1BWP30P140HVT U182 ( .I(mem_outb[29]), .ZN(mem_out[29]) );
  ND2D1BWP30P140HVT U183 ( .A1(config_enable[0]), .A2(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[30]) );
  INVD1BWP30P140HVT U184 ( .I(mem_outb[30]), .ZN(mem_out[30]) );
  ND2D1BWP30P140HVT U185 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_13_ccff_tail), .ZN(mem_outb[31]) );
  INVD1BWP30P140HVT U186 ( .I(mem_outb[31]), .ZN(mem_out[31]) );
  ND2D1BWP30P140HVT U187 ( .A1(config_enable[0]), .A2(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[32]) );
  INVD1BWP30P140HVT U188 ( .I(mem_outb[32]), .ZN(mem_out[32]) );
  ND2D1BWP30P140HVT U189 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_14_ccff_tail), .ZN(mem_outb[33]) );
  INVD1BWP30P140HVT U190 ( .I(mem_outb[33]), .ZN(mem_out[33]) );
  ND2D1BWP30P140HVT U191 ( .A1(config_enable[0]), .A2(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[34]) );
  INVD1BWP30P140HVT U192 ( .I(mem_outb[34]), .ZN(mem_out[34]) );
  ND2D1BWP30P140HVT U193 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_15_ccff_tail), .ZN(mem_outb[35]) );
  INVD1BWP30P140HVT U194 ( .I(mem_outb[35]), .ZN(mem_out[35]) );
  ND2D1BWP30P140HVT U195 ( .A1(config_enable[0]), .A2(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[36]) );
  INVD1BWP30P140HVT U196 ( .I(mem_outb[36]), .ZN(mem_out[36]) );
  ND2D1BWP30P140HVT U197 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_16_ccff_tail), .ZN(mem_outb[37]) );
  INVD1BWP30P140HVT U198 ( .I(mem_outb[37]), .ZN(mem_out[37]) );
  ND2D1BWP30P140HVT U199 ( .A1(config_enable[0]), .A2(
        mem_right_track_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[38]) );
  INVD1BWP30P140HVT U200 ( .I(mem_outb[38]), .ZN(mem_out[38]) );
  ND2D1BWP30P140HVT U201 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_17_ccff_tail), .ZN(mem_outb[39]) );
  INVD1BWP30P140HVT U202 ( .I(mem_outb[39]), .ZN(mem_out[39]) );
  ND2D1BWP30P140HVT U203 ( .A1(config_enable[0]), .A2(
        mem_right_track_2_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[40]) );
  INVD1BWP30P140HVT U204 ( .I(mem_outb[40]), .ZN(mem_out[40]) );
  ND2D1BWP30P140HVT U205 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_18_ccff_tail), .ZN(mem_outb[41]) );
  INVD1BWP30P140HVT U206 ( .I(mem_outb[41]), .ZN(mem_out[41]) );
  ND2D1BWP30P140HVT U207 ( .A1(config_enable[0]), .A2(
        mem_right_track_4_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[42]) );
  INVD1BWP30P140HVT U208 ( .I(mem_outb[42]), .ZN(mem_out[42]) );
  ND2D1BWP30P140HVT U209 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_19_ccff_tail), .ZN(mem_outb[43]) );
  INVD1BWP30P140HVT U210 ( .I(mem_outb[43]), .ZN(mem_out[43]) );
  ND2D1BWP30P140HVT U211 ( .A1(config_enable[0]), .A2(
        mem_right_track_6_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[44]) );
  INVD1BWP30P140HVT U212 ( .I(mem_outb[44]), .ZN(mem_out[44]) );
  ND2D1BWP30P140HVT U213 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_20_ccff_tail), .ZN(mem_outb[45]) );
  INVD1BWP30P140HVT U214 ( .I(mem_outb[45]), .ZN(mem_out[45]) );
  ND2D1BWP30P140HVT U215 ( .A1(config_enable[0]), .A2(
        mem_right_track_12_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[46]) );
  INVD1BWP30P140HVT U216 ( .I(mem_outb[46]), .ZN(mem_out[46]) );
  ND2D1BWP30P140HVT U217 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_21_ccff_tail), .ZN(mem_outb[47]) );
  INVD1BWP30P140HVT U218 ( .I(mem_outb[47]), .ZN(mem_out[47]) );
  ND2D1BWP30P140HVT U219 ( .A1(config_enable[0]), .A2(
        mem_right_track_14_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[48]) );
  INVD1BWP30P140HVT U220 ( .I(mem_outb[48]), .ZN(mem_out[48]) );
  ND2D1BWP30P140HVT U221 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_22_ccff_tail), .ZN(mem_outb[49]) );
  INVD1BWP30P140HVT U222 ( .I(mem_outb[49]), .ZN(mem_out[49]) );
  ND2D1BWP30P140HVT U223 ( .A1(config_enable[0]), .A2(
        mem_right_track_16_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[50]) );
  INVD1BWP30P140HVT U224 ( .I(mem_outb[50]), .ZN(mem_out[50]) );
  ND2D1BWP30P140HVT U225 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_23_ccff_tail), .ZN(mem_outb[51]) );
  INVD1BWP30P140HVT U226 ( .I(mem_outb[51]), .ZN(mem_out[51]) );
  ND2D1BWP30P140HVT U227 ( .A1(config_enable[0]), .A2(
        mem_right_track_18_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[52]) );
  INVD1BWP30P140HVT U228 ( .I(mem_outb[52]), .ZN(mem_out[52]) );
  ND2D1BWP30P140HVT U229 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_24_ccff_tail), .ZN(mem_outb[53]) );
  INVD1BWP30P140HVT U230 ( .I(mem_outb[53]), .ZN(mem_out[53]) );
  ND2D1BWP30P140HVT U231 ( .A1(config_enable[0]), .A2(
        mem_right_track_24_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[54]) );
  INVD1BWP30P140HVT U232 ( .I(mem_outb[54]), .ZN(mem_out[54]) );
  ND2D1BWP30P140HVT U233 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_25_ccff_tail), .ZN(mem_outb[55]) );
  INVD1BWP30P140HVT U234 ( .I(mem_outb[55]), .ZN(mem_out[55]) );
  ND2D1BWP30P140HVT U235 ( .A1(config_enable[0]), .A2(
        mem_right_track_26_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[56]) );
  INVD1BWP30P140HVT U236 ( .I(mem_outb[56]), .ZN(mem_out[56]) );
  ND2D1BWP30P140HVT U237 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_26_ccff_tail), .ZN(mem_outb[57]) );
  INVD1BWP30P140HVT U238 ( .I(mem_outb[57]), .ZN(mem_out[57]) );
  ND2D1BWP30P140HVT U239 ( .A1(config_enable[0]), .A2(
        mem_right_track_28_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[58]) );
  INVD1BWP30P140HVT U240 ( .I(mem_outb[58]), .ZN(mem_out[58]) );
  ND2D1BWP30P140HVT U241 ( .A1(config_enable[0]), .A2(
        sb_mux_size2_mem_27_ccff_tail), .ZN(mem_outb[59]) );
  INVD1BWP30P140HVT U242 ( .I(mem_outb[59]), .ZN(mem_out[59]) );
  ND2D1BWP30P140HVT U243 ( .A1(config_enable[0]), .A2(
        mem_right_track_30_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[60]) );
  INVD1BWP30P140HVT U244 ( .I(mem_outb[60]), .ZN(mem_out[60]) );
  ND2D1BWP30P140HVT U245 ( .A1(config_enable[0]), .A2(ccff_tail[0]), .ZN(
        mem_outb[61]) );
  INVD1BWP30P140HVT U246 ( .I(mem_outb[61]), .ZN(mem_out[61]) );
  ND2D1BWP30P140HVT U247 ( .A1(config_enable[0]), .A2(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q), .ZN(mem_outb[0]) );
  INVD1BWP30P140HVT U248 ( .I(mem_outb[0]), .ZN(mem_out[0]) );
  BUFFD1BWP30P140HVT mem_top_track_30_cp_buf2 ( .I(eco_net_1_0), .Z(eco_net)
         );
  BUFFD1BWP30P140HVT mem_right_track_30_cp_buf2 ( .I(eco_net_1_0), .Z(
        eco_net_0) );
  BUFFD1BWP30P140HVT mem_right_track_30_cp_buf1 ( .I(prog_clk[0]), .Z(
        eco_net_1_0) );
  BUFFD1BWP30P140HVT mem_top_track_30_cdn_buf2 ( .I(eco_net_4_0), .Z(
        eco_net_2_0) );
  BUFFD1BWP30P140HVT mem_right_track_30_cdn_buf2 ( .I(eco_net_4_0), .Z(
        eco_net_3_0) );
  BUFFD1BWP30P140HVT mem_right_track_30_cdn_buf1 ( .I(prog_reset[0]), .Z(
        eco_net_4_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del1 ( .I(ccff_head[0]), .Z(eco_net_5_0)
         );
  BUFFD1BWP30P140HVT mem_top_track_0_del2 ( .I(eco_net_5_0), .Z(eco_net_6_0)
         );
  BUFFD1BWP30P140HVT mem_top_track_32_del2 ( .I(sb_mux_size2_mem_13_ccff_tail), 
        .Z(eco_net_7_0) );
  BUFFD1BWP30P140HVT mem_top_track_0_del3_0 ( .I(eco_net_6_0), .Z(eco_net_8_0)
         );
  BUFFD1BWP30P140HVT mem_top_track_0_del3_1 ( .I(
        mem_top_track_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_9_0) );
  BUFFD1BWP30P140HVT mem_top_track_2_del3_0 ( .I(sb_mux_size3_mem_0_ccff_tail), 
        .Z(eco_net_10_0) );
  BUFFD1BWP30P140HVT mem_top_track_2_del3_1 ( .I(
        mem_top_track_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_11_0) );
  BUFFD1BWP30P140HVT mem_top_track_4_del3_0 ( .I(sb_mux_size2_mem_0_ccff_tail), 
        .Z(eco_net_12_0) );
  BUFFD1BWP30P140HVT mem_top_track_4_del3_1 ( .I(
        mem_top_track_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_13_0) );
  BUFFD1BWP30P140HVT mem_top_track_6_del3_0 ( .I(sb_mux_size2_mem_1_ccff_tail), 
        .Z(eco_net_14_0) );
  BUFFD1BWP30P140HVT mem_top_track_6_del3_1 ( .I(
        mem_top_track_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_15_0) );
  BUFFD1BWP30P140HVT mem_top_track_8_del3_0 ( .I(sb_mux_size2_mem_2_ccff_tail), 
        .Z(eco_net_16_0) );
  BUFFD1BWP30P140HVT mem_top_track_8_del3_1 ( .I(
        mem_top_track_8_TSMC22ULP_CCFF_0_Q), .Z(eco_net_17_0) );
  BUFFD1BWP30P140HVT mem_top_track_10_del3_0 ( .I(sb_mux_size2_mem_3_ccff_tail), .Z(eco_net_18_0) );
  BUFFD1BWP30P140HVT mem_top_track_10_del3_1 ( .I(
        mem_top_track_10_TSMC22ULP_CCFF_0_Q), .Z(eco_net_19_0) );
  BUFFD1BWP30P140HVT mem_top_track_12_del3_0 ( .I(sb_mux_size2_mem_4_ccff_tail), .Z(eco_net_20_0) );
  BUFFD1BWP30P140HVT mem_top_track_12_del3_1 ( .I(
        mem_top_track_12_TSMC22ULP_CCFF_0_Q), .Z(eco_net_21_0) );
  BUFFD1BWP30P140HVT mem_top_track_14_del3_0 ( .I(sb_mux_size3_mem_1_ccff_tail), .Z(eco_net_22_0) );
  BUFFD1BWP30P140HVT mem_top_track_14_del3_1 ( .I(
        mem_top_track_14_TSMC22ULP_CCFF_0_Q), .Z(eco_net_23_0) );
  BUFFD1BWP30P140HVT mem_top_track_16_del3_0 ( .I(sb_mux_size2_mem_5_ccff_tail), .Z(eco_net_24_0) );
  BUFFD1BWP30P140HVT mem_top_track_16_del3_1 ( .I(
        mem_top_track_16_TSMC22ULP_CCFF_0_Q), .Z(eco_net_25_0) );
  BUFFD1BWP30P140HVT mem_top_track_18_del3_0 ( .I(sb_mux_size2_mem_6_ccff_tail), .Z(eco_net_26_0) );
  BUFFD1BWP30P140HVT mem_top_track_18_del3_1 ( .I(
        mem_top_track_18_TSMC22ULP_CCFF_0_Q), .Z(eco_net_27_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_del3_0 ( .I(sb_mux_size2_mem_7_ccff_tail), .Z(eco_net_28_0) );
  BUFFD1BWP30P140HVT mem_top_track_20_del3_1 ( .I(
        mem_top_track_20_TSMC22ULP_CCFF_0_Q), .Z(eco_net_29_0) );
  BUFFD1BWP30P140HVT mem_top_track_22_del3_0 ( .I(sb_mux_size2_mem_8_ccff_tail), .Z(eco_net_30_0) );
  BUFFD1BWP30P140HVT mem_top_track_22_del3_1 ( .I(
        mem_top_track_22_TSMC22ULP_CCFF_0_Q), .Z(eco_net_31_0) );
  BUFFD1BWP30P140HVT mem_top_track_24_del3_0 ( .I(sb_mux_size2_mem_9_ccff_tail), .Z(eco_net_32_0) );
  BUFFD1BWP30P140HVT mem_top_track_24_del3_1 ( .I(
        mem_top_track_24_TSMC22ULP_CCFF_0_Q), .Z(eco_net_33_0) );
  BUFFD1BWP30P140HVT mem_top_track_26_del3_0 ( .I(
        sb_mux_size2_mem_10_ccff_tail), .Z(eco_net_34_0) );
  BUFFD1BWP30P140HVT mem_top_track_26_del3_1 ( .I(
        mem_top_track_26_TSMC22ULP_CCFF_0_Q), .Z(eco_net_35_0) );
  BUFFD1BWP30P140HVT mem_top_track_28_del3_0 ( .I(
        sb_mux_size2_mem_11_ccff_tail), .Z(eco_net_36_0) );
  BUFFD1BWP30P140HVT mem_top_track_28_del3_1 ( .I(
        mem_top_track_28_TSMC22ULP_CCFF_0_Q), .Z(eco_net_37_0) );
  BUFFD1BWP30P140HVT mem_top_track_30_del3_0 ( .I(
        sb_mux_size2_mem_12_ccff_tail), .Z(eco_net_38_0) );
  BUFFD1BWP30P140HVT mem_top_track_30_del3_1 ( .I(
        mem_top_track_30_TSMC22ULP_CCFF_0_Q), .Z(eco_net_39_0) );
  BUFFD1BWP30P140HVT mem_top_track_32_del3_0 ( .I(eco_net_7_0), .Z(
        eco_net_40_0) );
  BUFFD1BWP30P140HVT mem_top_track_32_del3_1 ( .I(
        mem_top_track_32_TSMC22ULP_CCFF_0_Q), .Z(eco_net_41_0) );
  BUFFD1BWP30P140HVT mem_top_track_34_del3_0 ( .I(
        sb_mux_size2_mem_14_ccff_tail), .Z(eco_net_42_0) );
  BUFFD1BWP30P140HVT mem_top_track_34_del3_1 ( .I(
        mem_top_track_34_TSMC22ULP_CCFF_0_Q), .Z(eco_net_43_0) );
  BUFFD1BWP30P140HVT mem_top_track_36_del3_0 ( .I(
        sb_mux_size2_mem_15_ccff_tail), .Z(eco_net_44_0) );
  BUFFD1BWP30P140HVT mem_top_track_36_del3_1 ( .I(
        mem_top_track_36_TSMC22ULP_CCFF_0_Q), .Z(eco_net_45_0) );
  BUFFD1BWP30P140HVT mem_right_track_0_del3_0 ( .I(
        sb_mux_size2_mem_16_ccff_tail), .Z(eco_net_46_0) );
  BUFFD1BWP30P140HVT mem_right_track_0_del3_1 ( .I(
        mem_right_track_0_TSMC22ULP_CCFF_0_Q), .Z(eco_net_47_0) );
  BUFFD1BWP30P140HVT mem_right_track_2_del3_0 ( .I(
        sb_mux_size2_mem_17_ccff_tail), .Z(eco_net_48_0) );
  BUFFD1BWP30P140HVT mem_right_track_2_del3_1 ( .I(
        mem_right_track_2_TSMC22ULP_CCFF_0_Q), .Z(eco_net_49_0) );
  BUFFD1BWP30P140HVT mem_right_track_4_del3_0 ( .I(
        sb_mux_size2_mem_18_ccff_tail), .Z(eco_net_50_0) );
  BUFFD1BWP30P140HVT mem_right_track_4_del3_1 ( .I(
        mem_right_track_4_TSMC22ULP_CCFF_0_Q), .Z(eco_net_51_0) );
  BUFFD1BWP30P140HVT mem_right_track_6_del3_0 ( .I(
        sb_mux_size2_mem_19_ccff_tail), .Z(eco_net_52_0) );
  BUFFD1BWP30P140HVT mem_right_track_6_del3_1 ( .I(
        mem_right_track_6_TSMC22ULP_CCFF_0_Q), .Z(eco_net_53_0) );
  BUFFD1BWP30P140HVT mem_right_track_12_del3_0 ( .I(
        sb_mux_size2_mem_20_ccff_tail), .Z(eco_net_54_0) );
  BUFFD1BWP30P140HVT mem_right_track_12_del3_1 ( .I(
        mem_right_track_12_TSMC22ULP_CCFF_0_Q), .Z(eco_net_55_0) );
  BUFFD1BWP30P140HVT mem_right_track_14_del3_0 ( .I(
        sb_mux_size2_mem_21_ccff_tail), .Z(eco_net_56_0) );
  BUFFD1BWP30P140HVT mem_right_track_14_del3_1 ( .I(
        mem_right_track_14_TSMC22ULP_CCFF_0_Q), .Z(eco_net_57_0) );
  BUFFD1BWP30P140HVT mem_right_track_16_del3_0 ( .I(
        sb_mux_size2_mem_22_ccff_tail), .Z(eco_net_58_0) );
  BUFFD1BWP30P140HVT mem_right_track_16_del3_1 ( .I(
        mem_right_track_16_TSMC22ULP_CCFF_0_Q), .Z(eco_net_59_0) );
  BUFFD1BWP30P140HVT mem_right_track_18_del3_0 ( .I(
        sb_mux_size2_mem_23_ccff_tail), .Z(eco_net_60_0) );
  BUFFD1BWP30P140HVT mem_right_track_18_del3_1 ( .I(
        mem_right_track_18_TSMC22ULP_CCFF_0_Q), .Z(eco_net_61_0) );
  BUFFD1BWP30P140HVT mem_right_track_24_del3_0 ( .I(
        sb_mux_size2_mem_24_ccff_tail), .Z(eco_net_62_0) );
  BUFFD1BWP30P140HVT mem_right_track_24_del3_1 ( .I(
        mem_right_track_24_TSMC22ULP_CCFF_0_Q), .Z(eco_net_63_0) );
  BUFFD1BWP30P140HVT mem_right_track_26_del3_0 ( .I(
        sb_mux_size2_mem_25_ccff_tail), .Z(eco_net_64_0) );
  BUFFD1BWP30P140HVT mem_right_track_26_del3_1 ( .I(
        mem_right_track_26_TSMC22ULP_CCFF_0_Q), .Z(eco_net_65_0) );
  BUFFD1BWP30P140HVT mem_right_track_28_del3_0 ( .I(
        sb_mux_size2_mem_26_ccff_tail), .Z(eco_net_66_0) );
  BUFFD1BWP30P140HVT mem_right_track_28_del3_1 ( .I(
        mem_right_track_28_TSMC22ULP_CCFF_0_Q), .Z(eco_net_67_0) );
  BUFFD1BWP30P140HVT mem_right_track_30_del3_0 ( .I(
        sb_mux_size2_mem_27_ccff_tail), .Z(eco_net_68_0) );
  BUFFD1BWP30P140HVT mem_right_track_30_del3_1 ( .I(
        mem_right_track_30_TSMC22ULP_CCFF_0_Q), .Z(eco_net_69_0) );
endmodule


module sb_0_ ( config_enable, prog_reset, prog_clk, chany_top_in, 
        top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_, 
        top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_, 
        chanx_right_in, 
        right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_, 
        right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_, 
        right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_, 
        right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_, 
        ccff_head, chany_top_out, chanx_right_out, ccff_tail );
  input [0:0] config_enable;
  input [0:0] prog_reset;
  input [0:0] prog_clk;
  input [0:31] chany_top_in;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_;
  input [0:0] top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_;
  input [0:31] chanx_right_in;
  input [0:0] right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_;
  input [0:0] right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_;
  input [0:0] right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_;
  input [0:0] right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_;
  input [0:0] ccff_head;
  output [0:31] chany_top_out;
  output [0:31] chanx_right_out;
  output [0:0] ccff_tail;
  wire   n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31;
  wire   [0:1] sb_mux_size3_0_sram;
  wire   [0:1] sb_mux_size3_0_sram_inv;
  wire   [0:1] sb_mux_size3_1_sram;
  wire   [0:1] sb_mux_size3_1_sram_inv;
  wire   [0:1] sb_mux_size2_0_sram;
  wire   [0:1] sb_mux_size2_0_sram_inv;
  wire   [0:1] sb_mux_size2_1_sram;
  wire   [0:1] sb_mux_size2_1_sram_inv;
  wire   [0:1] sb_mux_size2_2_sram;
  wire   [0:1] sb_mux_size2_2_sram_inv;
  wire   [0:1] sb_mux_size2_3_sram;
  wire   [0:1] sb_mux_size2_3_sram_inv;
  wire   [0:1] sb_mux_size2_4_sram;
  wire   [0:1] sb_mux_size2_4_sram_inv;
  wire   [0:1] sb_mux_size2_5_sram;
  wire   [0:1] sb_mux_size2_5_sram_inv;
  wire   [0:1] sb_mux_size2_6_sram;
  wire   [0:1] sb_mux_size2_6_sram_inv;
  wire   [0:1] sb_mux_size2_7_sram;
  wire   [0:1] sb_mux_size2_7_sram_inv;
  wire   [0:1] sb_mux_size2_8_sram;
  wire   [0:1] sb_mux_size2_8_sram_inv;
  wire   [0:1] sb_mux_size2_9_sram;
  wire   [0:1] sb_mux_size2_9_sram_inv;
  wire   [0:1] sb_mux_size2_10_sram;
  wire   [0:1] sb_mux_size2_10_sram_inv;
  wire   [0:1] sb_mux_size2_11_sram;
  wire   [0:1] sb_mux_size2_11_sram_inv;
  wire   [0:1] sb_mux_size2_12_sram;
  wire   [0:1] sb_mux_size2_12_sram_inv;
  wire   [0:1] sb_mux_size2_13_sram;
  wire   [0:1] sb_mux_size2_13_sram_inv;
  wire   [0:1] sb_mux_size2_14_sram;
  wire   [0:1] sb_mux_size2_14_sram_inv;
  wire   [0:1] sb_mux_size2_15_sram;
  wire   [0:1] sb_mux_size2_15_sram_inv;
  wire   [0:1] sb_mux_size2_16_sram;
  wire   [0:1] sb_mux_size2_16_sram_inv;
  wire   [0:1] sb_mux_size2_17_sram;
  wire   [0:1] sb_mux_size2_17_sram_inv;
  wire   [0:1] sb_mux_size2_18_sram;
  wire   [0:1] sb_mux_size2_18_sram_inv;
  wire   [0:1] sb_mux_size2_19_sram;
  wire   [0:1] sb_mux_size2_19_sram_inv;
  wire   [0:1] sb_mux_size2_20_sram;
  wire   [0:1] sb_mux_size2_20_sram_inv;
  wire   [0:1] sb_mux_size2_21_sram;
  wire   [0:1] sb_mux_size2_21_sram_inv;
  wire   [0:1] sb_mux_size2_22_sram;
  wire   [0:1] sb_mux_size2_22_sram_inv;
  wire   [0:1] sb_mux_size2_23_sram;
  wire   [0:1] sb_mux_size2_23_sram_inv;
  wire   [0:1] sb_mux_size2_24_sram;
  wire   [0:1] sb_mux_size2_24_sram_inv;
  wire   [0:1] sb_mux_size2_25_sram;
  wire   [0:1] sb_mux_size2_25_sram_inv;
  wire   [0:1] sb_mux_size2_26_sram;
  wire   [0:1] sb_mux_size2_26_sram_inv;
  wire   [0:1] sb_mux_size2_27_sram;
  wire   [0:1] sb_mux_size2_27_sram_inv;
  wire   [0:1] sb_mux_size2_28_sram;
  wire   [0:1] sb_mux_size2_28_sram_inv;
  assign chanx_right_out[4] = chany_top_in[3];
  assign chanx_right_out[5] = chany_top_in[4];
  assign chanx_right_out[10] = chany_top_in[9];
  assign chanx_right_out[11] = chany_top_in[10];
  assign chanx_right_out[16] = chany_top_in[15];
  assign chanx_right_out[17] = chany_top_in[16];
  assign chanx_right_out[18] = chany_top_in[17];
  assign chanx_right_out[19] = chany_top_in[18];
  assign chanx_right_out[20] = chany_top_in[19];
  assign chanx_right_out[21] = chany_top_in[20];
  assign chanx_right_out[22] = chany_top_in[21];
  assign chanx_right_out[23] = chany_top_in[22];
  assign chanx_right_out[24] = chany_top_in[23];
  assign chanx_right_out[25] = chany_top_in[24];
  assign chanx_right_out[26] = chany_top_in[25];
  assign chanx_right_out[27] = chany_top_in[26];
  assign chanx_right_out[28] = chany_top_in[27];
  assign chanx_right_out[29] = chany_top_in[28];
  assign chanx_right_out[30] = chany_top_in[29];
  assign chanx_right_out[31] = chany_top_in[30];
  assign chany_top_out[19] = chanx_right_in[20];
  assign chany_top_out[20] = chanx_right_in[21];
  assign chany_top_out[21] = chanx_right_in[22];
  assign chany_top_out[22] = chanx_right_in[23];
  assign chany_top_out[23] = chanx_right_in[24];
  assign chany_top_out[24] = chanx_right_in[25];
  assign chany_top_out[25] = chanx_right_in[26];
  assign chany_top_out[26] = chanx_right_in[27];
  assign chany_top_out[27] = chanx_right_in[28];
  assign chany_top_out[28] = chanx_right_in[29];
  assign chany_top_out[29] = chanx_right_in[30];
  assign chany_top_out[30] = chanx_right_in[31];
  assign chany_top_out[31] = chanx_right_in[0];

  sb_0__sb_mux_size3 mux_top_track_0 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_[0], 
        chanx_right_in[1]}), .sram(sb_mux_size3_0_sram), .sram_inv(
        sb_mux_size3_0_sram_inv), .out(n17) );
  sb_0__sb_mux_size3 mux_top_track_12 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_[0], 
        chanx_right_in[7]}), .sram(sb_mux_size3_1_sram), .sram_inv(
        sb_mux_size3_1_sram_inv), .out(n23) );
  sb_0__sb_mux_size2 mux_top_track_2 ( .in({
        top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_right_in[2]}), .sram(sb_mux_size2_0_sram), .sram_inv(
        sb_mux_size2_0_sram_inv), .out(n18) );
  sb_0__sb_mux_size2 mux_top_track_4 ( .in({
        top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_right_in[3]}), .sram(sb_mux_size2_1_sram), .sram_inv(
        sb_mux_size2_1_sram_inv), .out(n19) );
  sb_0__sb_mux_size2 mux_top_track_6 ( .in({
        top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_right_in[4]}), .sram(sb_mux_size2_2_sram), .sram_inv(
        sb_mux_size2_2_sram_inv), .out(n20) );
  sb_0__sb_mux_size2 mux_top_track_8 ( .in({
        top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_right_in[5]}), .sram(sb_mux_size2_3_sram), .sram_inv(
        sb_mux_size2_3_sram_inv), .out(n21) );
  sb_0__sb_mux_size2 mux_top_track_10 ( .in({
        top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_right_in[6]}), .sram(sb_mux_size2_4_sram), .sram_inv(
        sb_mux_size2_4_sram_inv), .out(n22) );
  sb_0__sb_mux_size2 mux_top_track_14 ( .in({
        top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_right_in[8]}), .sram(sb_mux_size2_5_sram), .sram_inv(
        sb_mux_size2_5_sram_inv), .out(n24) );
  sb_0__sb_mux_size2 mux_top_track_16 ( .in({
        top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_right_in[9]}), .sram(sb_mux_size2_6_sram), .sram_inv(
        sb_mux_size2_6_sram_inv), .out(chany_top_out[8]) );
  sb_0__sb_mux_size2 mux_top_track_18 ( .in({
        top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_right_in[10]}), .sram(sb_mux_size2_7_sram), .sram_inv(
        sb_mux_size2_7_sram_inv), .out(chany_top_out[9]) );
  sb_0__sb_mux_size2 mux_top_track_20 ( .in({
        top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_right_in[11]}), .sram(sb_mux_size2_8_sram), .sram_inv(
        sb_mux_size2_8_sram_inv), .out(chany_top_out[10]) );
  sb_0__sb_mux_size2 mux_top_track_22 ( .in({
        top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_right_in[12]}), .sram(sb_mux_size2_9_sram), .sram_inv(
        sb_mux_size2_9_sram_inv), .out(chany_top_out[11]) );
  sb_0__sb_mux_size2 mux_top_track_24 ( .in({
        top_left_grid_right_width_0_height_0_subtile_0__pin_a2f_o_0_[0], 
        chanx_right_in[13]}), .sram(sb_mux_size2_10_sram), .sram_inv(
        sb_mux_size2_10_sram_inv), .out(chany_top_out[12]) );
  sb_0__sb_mux_size2 mux_top_track_26 ( .in({
        top_left_grid_right_width_0_height_0_subtile_1__pin_a2f_o_0_[0], 
        chanx_right_in[14]}), .sram(sb_mux_size2_11_sram), .sram_inv(
        sb_mux_size2_11_sram_inv), .out(chany_top_out[13]) );
  sb_0__sb_mux_size2 mux_top_track_28 ( .in({
        top_left_grid_right_width_0_height_0_subtile_2__pin_a2f_o_0_[0], 
        chanx_right_in[15]}), .sram(sb_mux_size2_12_sram), .sram_inv(
        sb_mux_size2_12_sram_inv), .out(chany_top_out[14]) );
  sb_0__sb_mux_size2 mux_top_track_30 ( .in({
        top_left_grid_right_width_0_height_0_subtile_3__pin_a2f_o_0_[0], 
        chanx_right_in[16]}), .sram(sb_mux_size2_13_sram), .sram_inv(
        sb_mux_size2_13_sram_inv), .out(chany_top_out[15]) );
  sb_0__sb_mux_size2 mux_top_track_32 ( .in({
        top_left_grid_right_width_0_height_0_subtile_4__pin_a2f_o_0_[0], 
        chanx_right_in[17]}), .sram(sb_mux_size2_14_sram), .sram_inv(
        sb_mux_size2_14_sram_inv), .out(n25) );
  sb_0__sb_mux_size2 mux_top_track_34 ( .in({
        top_left_grid_right_width_0_height_0_subtile_5__pin_a2f_o_0_[0], 
        chanx_right_in[18]}), .sram(sb_mux_size2_15_sram), .sram_inv(
        sb_mux_size2_15_sram_inv), .out(chany_top_out[17]) );
  sb_0__sb_mux_size2 mux_top_track_36 ( .in({
        top_left_grid_right_width_0_height_0_subtile_6__pin_a2f_o_0_[0], 
        chanx_right_in[19]}), .sram(sb_mux_size2_16_sram), .sram_inv(
        sb_mux_size2_16_sram_inv), .out(chany_top_out[18]) );
  sb_0__sb_mux_size2 mux_right_track_0 ( .in({chany_top_in[31], 
        right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_17_sram), .sram_inv(sb_mux_size2_17_sram_inv), 
        .out(n26) );
  sb_0__sb_mux_size2 mux_right_track_2 ( .in({chany_top_in[0], 
        right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_18_sram), .sram_inv(sb_mux_size2_18_sram_inv), 
        .out(n27) );
  sb_0__sb_mux_size2 mux_right_track_4 ( .in({chany_top_in[1], 
        right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_19_sram), .sram_inv(sb_mux_size2_19_sram_inv), 
        .out(n28) );
  sb_0__sb_mux_size2 mux_right_track_6 ( .in({chany_top_in[2], 
        right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_20_sram), .sram_inv(sb_mux_size2_20_sram_inv), 
        .out(n29) );
  sb_0__sb_mux_size2 mux_right_track_12 ( .in({chany_top_in[5], 
        right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_21_sram), .sram_inv(sb_mux_size2_21_sram_inv), 
        .out(n30) );
  sb_0__sb_mux_size2 mux_right_track_14 ( .in({chany_top_in[6], 
        right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_22_sram), .sram_inv(sb_mux_size2_22_sram_inv), 
        .out(n31) );
  sb_0__sb_mux_size2 mux_right_track_16 ( .in({chany_top_in[7], 
        right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_23_sram), .sram_inv(sb_mux_size2_23_sram_inv), 
        .out(chanx_right_out[8]) );
  sb_0__sb_mux_size2 mux_right_track_18 ( .in({chany_top_in[8], 
        right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_24_sram), .sram_inv(sb_mux_size2_24_sram_inv), 
        .out(chanx_right_out[9]) );
  sb_0__sb_mux_size2 mux_right_track_24 ( .in({chany_top_in[11], 
        right_bottom_grid_top_width_0_height_0_subtile_0__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_25_sram), .sram_inv(sb_mux_size2_25_sram_inv), 
        .out(chanx_right_out[12]) );
  sb_0__sb_mux_size2 mux_right_track_26 ( .in({chany_top_in[12], 
        right_bottom_grid_top_width_0_height_0_subtile_1__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_26_sram), .sram_inv(sb_mux_size2_26_sram_inv), 
        .out(chanx_right_out[13]) );
  sb_0__sb_mux_size2 mux_right_track_28 ( .in({chany_top_in[13], 
        right_bottom_grid_top_width_0_height_0_subtile_2__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_27_sram), .sram_inv(sb_mux_size2_27_sram_inv), 
        .out(chanx_right_out[14]) );
  sb_0__sb_mux_size2 mux_right_track_30 ( .in({chany_top_in[14], 
        right_bottom_grid_top_width_0_height_0_subtile_3__pin_a2f_o_0_[0]}), 
        .sram(sb_mux_size2_28_sram), .sram_inv(sb_mux_size2_28_sram_inv), 
        .out(chanx_right_out[15]) );
  sb_0__config_group_mem_size62 sb_0__config_group_mem_size62 ( 
        .config_enable(config_enable[0]), .prog_reset(prog_reset[0]), 
        .prog_clk(prog_clk[0]), .ccff_head(ccff_head[0]), .mem_out({
        sb_mux_size3_0_sram, sb_mux_size2_0_sram, sb_mux_size2_1_sram, 
        sb_mux_size2_2_sram, sb_mux_size2_3_sram, sb_mux_size2_4_sram, 
        sb_mux_size3_1_sram, sb_mux_size2_5_sram, sb_mux_size2_6_sram, 
        sb_mux_size2_7_sram, sb_mux_size2_8_sram, sb_mux_size2_9_sram, 
        sb_mux_size2_10_sram, sb_mux_size2_11_sram, sb_mux_size2_12_sram, 
        sb_mux_size2_13_sram, sb_mux_size2_14_sram, sb_mux_size2_15_sram, 
        sb_mux_size2_16_sram, sb_mux_size2_17_sram, sb_mux_size2_18_sram, 
        sb_mux_size2_19_sram, sb_mux_size2_20_sram, sb_mux_size2_21_sram, 
        sb_mux_size2_22_sram, sb_mux_size2_23_sram, sb_mux_size2_24_sram, 
        sb_mux_size2_25_sram, sb_mux_size2_26_sram, sb_mux_size2_27_sram, 
        sb_mux_size2_28_sram}), .mem_outb({sb_mux_size3_0_sram_inv, 
        sb_mux_size2_0_sram_inv, sb_mux_size2_1_sram_inv, 
        sb_mux_size2_2_sram_inv, sb_mux_size2_3_sram_inv, 
        sb_mux_size2_4_sram_inv, sb_mux_size3_1_sram_inv, 
        sb_mux_size2_5_sram_inv, sb_mux_size2_6_sram_inv, 
        sb_mux_size2_7_sram_inv, sb_mux_size2_8_sram_inv, 
        sb_mux_size2_9_sram_inv, sb_mux_size2_10_sram_inv, 
        sb_mux_size2_11_sram_inv, sb_mux_size2_12_sram_inv, 
        sb_mux_size2_13_sram_inv, sb_mux_size2_14_sram_inv, 
        sb_mux_size2_15_sram_inv, sb_mux_size2_16_sram_inv, 
        sb_mux_size2_17_sram_inv, sb_mux_size2_18_sram_inv, 
        sb_mux_size2_19_sram_inv, sb_mux_size2_20_sram_inv, 
        sb_mux_size2_21_sram_inv, sb_mux_size2_22_sram_inv, 
        sb_mux_size2_23_sram_inv, sb_mux_size2_24_sram_inv, 
        sb_mux_size2_25_sram_inv, sb_mux_size2_26_sram_inv, 
        sb_mux_size2_27_sram_inv, sb_mux_size2_28_sram_inv}), .ccff_tail(
        ccff_tail[0]) );
  CKBD2BWP30P140HVT U1 ( .I(n31), .Z(chanx_right_out[7]) );
  CKBD2BWP30P140HVT U2 ( .I(n30), .Z(chanx_right_out[6]) );
  CKBD2BWP30P140HVT U3 ( .I(n29), .Z(chanx_right_out[3]) );
  CKBD2BWP30P140HVT U4 ( .I(n28), .Z(chanx_right_out[2]) );
  CKBD2BWP30P140HVT U5 ( .I(n27), .Z(chanx_right_out[1]) );
  CKBD2BWP30P140HVT U6 ( .I(n26), .Z(chanx_right_out[0]) );
  CKBD2BWP30P140HVT U7 ( .I(n25), .Z(chany_top_out[16]) );
  CKBD2BWP30P140HVT U8 ( .I(n18), .Z(chany_top_out[1]) );
  CKBD2BWP30P140HVT U9 ( .I(n20), .Z(chany_top_out[3]) );
  CKBD2BWP30P140HVT U10 ( .I(n21), .Z(chany_top_out[4]) );
  CKBD2BWP30P140HVT U11 ( .I(n19), .Z(chany_top_out[2]) );
  CKBD2BWP30P140HVT U12 ( .I(n22), .Z(chany_top_out[5]) );
  CKBD2BWP30P140HVT U13 ( .I(n24), .Z(chany_top_out[7]) );
  CKBD2BWP30P140HVT U14 ( .I(n17), .Z(chany_top_out[0]) );
  CKBD2BWP30P140HVT U15 ( .I(n23), .Z(chany_top_out[6]) );
endmodule

