//Generated from netlist by SpyDrNet
//netlist name: SDN_VERILOG_NETLIST_const0
module fpga_top
(
    clk0,
    clk1,
    clk2,
    clk3,
    clk4,
    clk5,
    clk6,
    clk7,
    reset,
    prog_clk,
    config_enable,
    prog_reset,
    SE0,
    SE1,
    SC0,
    SC1,
    SR,
    SE2,
    gfpga_pad_pinput_A2F,
    gfpga_pad_poutput_F2A,
    ccff_head,
    ccff_tail,
    clk0_fto_0,
    clk0_fto_1,
    clk2_fto_0,
    clk2_fto_1,
    SI,
    SO
);

    input clk0;
    input clk1;
    input clk2;
    input clk3;
    input clk4;
    input clk5;
    input clk6;
    input clk7;
    input reset;
    input [0:7]prog_clk;
    input config_enable;
    input prog_reset;
    input SE0;
    input SE1;
    input SC0;
    input SC1;
    input SR;
    input SE2;
    input [0:137]gfpga_pad_pinput_A2F;
    output [0:99]gfpga_pad_poutput_F2A;
    input [0:7]ccff_head;
    output [0:7]ccff_tail;
    output clk0_fto_0;
    output clk0_fto_1;
    output clk2_fto_0;
    output clk2_fto_1;
    input SI;
    output SO;

    wire clk0;
    wire clk1;
    wire clk2;
    wire clk3;
    wire clk4;
    wire clk5;
    wire clk6;
    wire clk7;
    wire reset;
    wire [0:7]prog_clk;
    wire config_enable;
    wire prog_reset;
    wire SE0;
    wire SE1;
    wire SC0;
    wire SC1;
    wire SR;
    wire SE2;
    wire [0:137]gfpga_pad_pinput_A2F;
    wire [0:99]gfpga_pad_poutput_F2A;
    wire [0:7]ccff_head;
    wire [0:7]ccff_tail;
    wire clk0_fto_0;
    wire clk0_fto_1;
    wire clk2_fto_0;
    wire clk2_fto_1;
    wire SI;
    wire SO;

    fpga_core fpga_core_inst
    (
        .clk0(clk0),
        .clk1(clk1),
        .clk2(clk2),
        .clk3(clk3),
        .clk4(clk4),
        .clk5(clk5),
        .clk6(clk6),
        .clk7(clk7),
        .reset(reset),
        .prog_clk(prog_clk),
        .config_enable(config_enable),
        .prog_reset(prog_reset),
        .SE0(SE0),
        .SE1(SE1),
        .SC0(SC0),
        .SC1(SC1),
        .SR(SR),
        .SE2(SE2),
        .gfpga_pad_pinput_A2F(gfpga_pad_pinput_A2F),
        .gfpga_pad_poutput_F2A(gfpga_pad_poutput_F2A),
        .ccff_head(ccff_head),
        .ccff_tail(ccff_tail),
        .clk0_fto_0(clk0_fto_0),
        .clk0_fto_1(clk0_fto_1),
        .clk2_fto_0(clk2_fto_0),
        .clk2_fto_1(clk2_fto_1),
        .SI(SI),
        .SO(SO)
    );
endmodule

