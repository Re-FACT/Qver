//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Verilog modules for primitive pb_type: iopad
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Wed Sep 30 09:18:18 2026
//-------------------------------------------
//----- Default net type -----
`default_nettype none

// ----- Verilog module for logical_tile_io_mode_physical__iopad -----
module logical_tile_io_mode_physical__iopad(prog_clk,
                                            gfpga_pad_EMBEDDED_IO_SOC_IN,
                                            gfpga_pad_EMBEDDED_IO_SOC_OUT,
                                            gfpga_pad_EMBEDDED_IO_SOC_DIR,
                                            iopad_outpad,
                                            ccff_head,
                                            iopad_inpad,
                                            ccff_tail);
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- GPIN PORTS -----
input [0:0] gfpga_pad_EMBEDDED_IO_SOC_IN;
//----- GPOUT PORTS -----
output [0:0] gfpga_pad_EMBEDDED_IO_SOC_OUT;
//----- GPOUT PORTS -----
output [0:0] gfpga_pad_EMBEDDED_IO_SOC_DIR;
//----- INPUT PORTS -----
input [0:0] iopad_outpad;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:0] iopad_inpad;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;

//----- BEGIN wire-connection ports -----
wire [0:0] iopad_outpad;
wire [0:0] iopad_inpad;
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----


wire [0:0] EMBEDDED_IO_0_en;

// ----- BEGIN Local short connections -----
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
// ----- END Local output short connections -----

	EMBEDDED_IO EMBEDDED_IO_0_ (
		.SOC_IN(gfpga_pad_EMBEDDED_IO_SOC_IN),
		.SOC_OUT(gfpga_pad_EMBEDDED_IO_SOC_OUT),
		.SOC_DIR(gfpga_pad_EMBEDDED_IO_SOC_DIR),
		.FPGA_OUT(iopad_outpad),
		.FPGA_DIR(EMBEDDED_IO_0_en),
		.FPGA_IN(iopad_inpad));

	EMBEDDED_IO_DFFQ_mem EMBEDDED_IO_DFFQ_mem (
		.prog_clk(prog_clk),
		.ccff_head(ccff_head),
		.ccff_tail(ccff_tail),
		.mem_out(EMBEDDED_IO_0_en));

endmodule
// ----- END Verilog module for logical_tile_io_mode_physical__iopad -----

//----- Default net type -----
`default_nettype wire



