//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Shift register banks used in FPGA
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Sep 28 20:39:55 2026
//-------------------------------------------
