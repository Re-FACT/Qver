//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Local Decoders for Multiplexers
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Sep 28 20:39:55 2026
//-------------------------------------------
