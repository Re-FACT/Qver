//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Preprocessing flags to enable/disable features in FPGA Verilog modules
//	Author: Xifan TANG
//	Organization: University of Utah
//	Date: Mon Sep 28 20:39:55 2026
//-------------------------------------------
`define ENABLE_TIMING 1

